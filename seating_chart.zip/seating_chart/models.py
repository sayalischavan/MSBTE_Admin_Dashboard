from django.db import models

# Models for eligibility module
# ElgTaskExecution model has been moved to data_prepration.eligibility_admin.models
