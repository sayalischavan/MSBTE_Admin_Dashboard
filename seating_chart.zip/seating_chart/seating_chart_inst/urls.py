from django.urls import path
from . import views

app_name = 'seating_chart_inst'

urlpatterns = [
    path('inst_seating_chart_coursewise_s13/', views.inst_seating_chart_coursewise_s13, name='inst_seating_chart_coursewise_s13'),
    path('inst_seating_chart_s13/', views.inst_seating_chart_s13, name='inst_seating_chart_s13'),
    path('inst_seating_chart_appwise_s13/', views.inst_seating_chart_appwise_s13, name='inst_seating_chart_appwise_s13'),
    path('inst_seat_chart/', views.inst_seat_chart, name='inst_seat_chart'),
    path('inst_seat_chart_next/', views.inst_seat_chart_next, name='inst_seat_chart_next'),
    path('inst_seat_chart_conf/', views.inst_seat_chart_conf, name='inst_seat_chart_conf'),
    path('inst_seat_chart_final_conf/', views.inst_seat_chart_final_conf, name='inst_seat_chart_final_conf'),
    path('inst_seat_chart_nil_conf/', views.inst_seat_chart_nil_conf, name='inst_seat_chart_nil_conf'),
    path('inst_seat_chart_rep/', views.inst_seat_chart_rep, name='inst_seat_chart_rep'),
    path('inst_seat_chart_rep_nil/', views.inst_seat_chart_rep_nil, name='inst_seat_chart_rep_nil'),
    path('inst_seat_chart_rep_next/', views.inst_seat_chart_rep_next, name='inst_seat_chart_rep_next'),
    path('seatingchart_arrangement_ec/', views.seatingchart_arrangement_ec, name='seatingchart_arrangement_ec'),
    path('seat_chart_ec_next/', views.seat_chart_ec_next, name='seat_chart_ec_next'),
    path('seatingchart_arrangement_ec_cand_list/', views.seatingchart_arrangement_ec_cand_list, name='seatingchart_arrangement_ec_cand_list'),
    path('seat_chart_ec_list_cands/', views.seat_chart_ec_list_cands, name='seat_chart_ec_list_cands'),
    path('inst_attendance_sheet_s13/', views.inst_attendance_sheet_s13, name='inst_attendance_sheet_s13'),
    path('attendance_sheet_next1_s13/', views.attendance_sheet_next1_s13, name='attendance_sheet_next1_s13'),
]