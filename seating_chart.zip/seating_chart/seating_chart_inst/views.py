import base64
import logging
from functools import lru_cache
import pandas as pd
from django.shortcuts import render, redirect
from django.contrib import messages
from django.urls import reverse
from django.contrib.auth.decorators import login_required
from dashboard.decorators import jwt_report_authorized

import config.msbte_config as msbte_config
from dashboard.utils import (
    get_auth_context,
    get_user_control_info,
    get_db_connection,
    get_city_name,
    get_inst_name,
    get_region_inst,
    get_region_name,
)

logger = logging.getLogger(__name__)

# Appear codes allowed per status (from PHP)
APPEAR_CODE_R = ('Y', 'E', 'O', 'A', 'D', 'S', 'M', 'C', 'T', 'F', 'H', 'J', 'K', 'L', 'N', 'P', 'Q')
APPEAR_CODE_X = ('Y', 'I', 'R')

# GPDL institutes get extra course options (CC, EC, MC)
GPDL_EXAM_ARRAY = ('0002', '0006', '0011', '0015', '0018', '0026', '0066')

APPEAR_CODE_LABELS = {
    'D': '(Direct Second Year Candidate)',
    'E': '(Exemption Candidate)',
    'Y': '(Already Exist, All Subjects)',
    'A': '(Additional Candidate)',
    'I': '(Improvement Candidate)',
    'R': '(Reappearing Candidate)',
    'S': '(Double Diploma Candidate)',
    'C': '(Course Change)',
    'T': '(Institute Change)',
    'M': '(Scheme Change)',
    'F': '(Scheme with Course Change)',
    'H': '(Scheme with Institute Change)',
    'K': '(Course with Institute Change)',
    'J': '(Scheme with Course with Institute Change)',
    'L': '(Readmission)',
    'X': '(Deleted Candidate)',
    'O': '(OTO Candidate)',
    '': '(Total Candidates)',
}

@jwt_report_authorized(allowed_roles=['INSTITUTE', 'ADMIN'])
def inst_seating_chart_coursewise_s13(request):
    """
    Seating chart form (course-wise) for current exam.
    Role handling (aligned with stat_inst):
    - INSTITUTE: access only to their institute; inst_code from JWT token (required) or session uid.
    - ADMIN: access to all institutes; inst_code optional — if missing, show institute selection form.
    GET: Show form with Status, Course, Semester, Master; stats and appear-code counts.
    POST: Validate and redirect to inst_seating_chart_s13 with encoded params (opens in new tab).
    """
    auth, error = get_auth_context(
        request,
        redirect_url='dashboard:seating_chart:seating_chart_home',
        require_institute=False,
    )
    if error:
        return error

    user_info, error = get_user_control_info(
        request,
        auth,
        allowed_roles=['INSTITUTE', 'RBTE', 'ADMIN'],
        require_institute_code=False,
        redirect_url='dashboard:seating_chart:seating_chart_home',
        error_message='You are not authorised to view this report',
    )
    if error:
        return error

    uid = user_info.get('uid')
    user_role = (user_info.get('user_role') or auth.get('role') or '').upper()
    is_admin = user_info.get('is_admin', False)
    inst_code = None

    # Resolve inst_code by role (same pattern as stat_inst)
    if not is_admin and user_role == 'INSTITUTE':
        # INSTITUTE: access only to their institute; inst_code from JWT (required) or session uid
        if auth.get('is_jwt'):
            inst_code = auth.get('institute_code')
            if inst_code:
                inst_code = str(inst_code).strip()
            if not inst_code:
                current_exam_label = getattr(msbte_config, 'ACA_NAME_EXAM_S', 'Summer 2026')
                return render(request, 'seating_chart_inst/inst_seating_chart_coursewise_s13.html', {
                    'error_message': 'You are not authorised to view this report. Institute code is required in the token.',
                    'current_exam_label': current_exam_label,
                    'user_info': user_info,
                })
            try:
                int(str(inst_code).lstrip('0'))
            except (ValueError, TypeError):
                return render(request, 'seating_chart_inst/inst_seating_chart_coursewise_s13.html', {
                    'error_message': 'You are not authorised to view this report.',
                    'current_exam_label': getattr(msbte_config, 'ACA_NAME_EXAM_S', 'Summer 2026'),
                    'user_info': user_info,
                })
        else:
            # Session: derive from uid (PHP: len 7 → last 5, else last 4)
            if not uid:
                return render(request, 'seating_chart_inst/inst_seating_chart_coursewise_s13.html', {
                    'error_message': 'You are not authorised to view this report.',
                    'current_exam_label': getattr(msbte_config, 'ACA_NAME_EXAM_S', 'Summer 2026'),
                    'user_info': user_info,
                })
            uid_str = str(uid).strip()
            if len(uid_str) == 7:
                inst_code = uid_str[-5:]
            elif len(uid_str) >= 4:
                inst_code = uid_str[-4:]
            else:
                inst_code = uid_str
    elif is_admin or user_role == 'RBTE':
        # ADMIN/RBTE: access to all institutes; inst_code from GET instid (after institute selection) or JWT
        instid_get = (request.GET.get('instid') or '').strip()
        if instid_get:
            inst_code = str(instid_get).lstrip('0') or instid_get
        if not inst_code and auth.get('is_jwt'):
            inst_code = auth.get('institute_code')
        if not inst_code:
            inst_code = user_info.get('inst_code')
        if inst_code is not None:
            inst_code = str(inst_code).strip() or None

    # Admin/RBTE without inst_code: show institute selection form (access to all institutes)
    if is_admin and not inst_code:
        conn = get_db_connection()
        exam_centers_query = f"""
            SELECT DISTINCT inst_code from {msbte_config.SEATING_CHART}
            WHERE inst_code IS NOT NULL AND inst_code != '' AND inst_code != '0000'
            ORDER BY inst_code
        """
        try:
            df_ec = pd.read_sql(exam_centers_query, conn)
            exam_centers = []
            for _, r in df_ec.iterrows():
                ic = r['inst_code']
                if ic is None:
                    continue
                try:
                    ic_int = int(ic)
                except (ValueError, TypeError):
                    ic_int = ic
                inst_name = get_inst_name(ic_int) or get_city_name(ic_int) or f"Institute {ic_int}"
                exam_centers.append({
                    'inst_id': ic_int,
                    'inst_name': inst_name,
                })
        except Exception as e:
            logger.exception("Exam centers query failed: %s", e)
            exam_centers = []
        return render(request, 'seating_chart_inst/inst_seating_chart_coursewise_s13.html', {
            'exam_centers': exam_centers,
            'current_exam_label': getattr(msbte_config, 'ACA_NAME_EXAM_S', 'Summer 2026'),
            'user_info': user_info,
            'form_action': reverse('dashboard:seating_chart:seating_chart_inst:inst_seating_chart_coursewise_s13'),
        })

    # INSTITUTE must have inst_code at this point
    if not is_admin and not inst_code:
        messages.error(request, 'Institute code is required.')
        return redirect(reverse('dashboard:seating_chart:seating_chart_home'))

    # POST: validate and redirect to report
    if request.method == 'POST':
        flg = request.POST.get('flg')
        if flg == '1':
            # Preserve inst_code from hidden field when admin submitted the form
            if not inst_code:
                inst_code = (request.POST.get('instid') or '').strip() or None
            st = (request.POST.get('st') or '').strip()
            course = (request.POST.get('course') or '').strip()
            semester = (request.POST.get('semester') or '').strip()
            master = (request.POST.get('master') or '').strip()

            if not st:
                messages.error(request, 'Please Select Status.')
                return _render_form(request, inst_code, is_admin, user_info, None)
            if not course:
                messages.error(request, 'Please Select Course Name.')
                return _render_form(request, inst_code, is_admin, user_info, None)
            if not semester:
                messages.error(request, 'Please Select Year / Semester.')
                return _render_form(request, inst_code, is_admin, user_info, None)

            course_id = base64.b64encode(course.encode()).decode()
            sem_id = base64.b64encode(semester.encode()).decode()
            master_id = base64.b64encode(master.encode()).decode()
            st_id = base64.b64encode(st.encode()).decode()

            report_url = reverse(
                'dashboard:seating_chart:seating_chart_inst:inst_seating_chart_s13'
            )
            redirect_to = f"{report_url}?cs_id={course_id}&sem={sem_id}&master={master_id}&st={st_id}"
            if inst_code:
                redirect_to += f"&instid={inst_code}"
            return redirect(redirect_to)

    return _render_form(request, inst_code, is_admin, user_info, None)


def _render_form(request, inst_code, is_admin, user_info, error_message):
    """Load form data and render inst_seating_chart_coursewise_s13 template."""
    if not inst_code and not is_admin:
        messages.error(request, 'Institute code is required.')
        return redirect(reverse('dashboard:seating_chart:seating_chart_home'))

    conn = get_db_connection()
    courses = []
    ex_form_stat = None
    appear_code_rows = []
    gpdl_num = 0
    gpdl_appear_code_rows = []
    is_gpdl_inst = False
    show_gpdl = inst_code and str(inst_code).zfill(4) in GPDL_EXAM_ARRAY

    if inst_code:
        # Courses for institute
        sql_courses = f"""
            SELECT c.course_id, c.course_name, c.course_code
            FROM {msbte_config.COURSES1} c
            INNER JOIN {msbte_config.INST_COURSES} ic ON ic.course_id = c.course_id
            WHERE ic.inst_code = %s
        """
        try:
            df_c = pd.read_sql(sql_courses, conn, params=[inst_code])
            courses = df_c.to_dict('records')
        except Exception as e:
            logger.exception("Seating chart courses query failed: %s", e)

        # Exam form stats
        sql_stat = f"""
            SELECT
                SUM(IF(cand_conf = 'Y', 1, 0)) AS cand_conf,
                SUM(IF(inst_conf = 'Y', 1, 0)) AS inst_conf,
                SUM(IF(rbte_conf = 'Y', 1, 0)) AS rbte_conf,
                SUM(IF(cand_conf = 'Y' AND (inst_conf IS NULL OR inst_conf != 'Y'), 1, 0)) AS inst_not_conf,
                SUM(IF(inst_conf = 'Y' AND (rbte_conf IS NULL OR rbte_conf != 'Y'), 1, 0)) AS rbte_not_conf
            FROM {msbte_config.EXAM_CONFIRM}
            WHERE inst_id = %s
        """
        try:
            logger.info(sql_stat)
            logger.info(inst_code)
            df_stat = pd.read_sql(sql_stat, conn, params=[inst_code])
            logger.info(df_stat)
            if not df_stat.empty:
                raw = df_stat.iloc[0].to_dict()
                # Ensure counts display as whole numbers (not 695.0)
                ex_form_stat = {}
                for k, v in raw.items():
                    if v is not None and pd.notna(v):
                        try:
                            ex_form_stat[k] = int(float(v))
                        except (ValueError, TypeError):
                            ex_form_stat[k] = v
                    else:
                        ex_form_stat[k] = 0
        except Exception as e:
            logger.exception("Seating chart ex form stat query failed: %s", e)

        # Appear code counts (block not in Y, D) - regular table for this institute
        sql_appear = f"""
            SELECT appear_code AS app_code, COUNT(DISTINCT seatno) AS cnt
            FROM {msbte_config.SEATING_CHART}
            WHERE inst_code = %s AND (block IS NULL OR block NOT IN ('Y', 'D'))
            GROUP BY appear_code
        """
        try:
            df_appear = pd.read_sql(sql_appear, conn, params=[inst_code])
            appear_code_rows = []
            for _, r in df_appear.iterrows():
                app_code = r.get('app_code')
                if pd.isna(app_code):
                    app_code = ''
                else:
                    app_code = str(app_code).strip()
                cnt = r.get('cnt', 0)
                label = APPEAR_CODE_LABELS.get(app_code, '')
                if app_code == '':
                    label = '(Total Candidates)'
                    app_code_b64 = base64.b64encode('AL'.encode()).decode()
                else:
                    app_code_b64 = base64.b64encode(app_code.encode()).decode()
                appear_code_rows.append({
                    'app_code': app_code,
                    'cnt': cnt,
                    'label': label or app_code,
                    'app_code_b64': app_code_b64,
                })
        except Exception as e:
            logger.exception("Seating chart appear code query failed: %s", e)

        # GPDL appear code table: only when inst_code is 0234 (PHP: if inst_code=='0234')
        gpdl_appear_code_rows = []
        is_gpdl_inst = (str(inst_code).strip() == '0234' or str(inst_code).lstrip('0') == '234')
        if is_gpdl_inst:
            sql_gpdl = f"""
                SELECT appear_code AS app_code, COUNT(DISTINCT seatno) AS cnt
                FROM {msbte_config.SEATING_CHART}
                WHERE inst_code = '0234' AND (block IS NULL OR block NOT IN ('Y', 'D'))
                GROUP BY appear_code
            """
            try:
                df_gpdl = pd.read_sql(sql_gpdl, conn)
                for _, r in df_gpdl.iterrows():
                    app_code = r.get('app_code')
                    if pd.isna(app_code):
                        app_code = ''
                    else:
                        app_code = str(app_code).strip()
                    cnt = r.get('cnt', 0)
                    label = APPEAR_CODE_LABELS.get(app_code, '')
                    if app_code == '':
                        label = '(Total Candidates)'
                        app_code_b64 = base64.b64encode('AL'.encode()).decode()
                    else:
                        app_code_b64 = base64.b64encode(app_code.encode()).decode()
                    gpdl_appear_code_rows.append({
                        'app_code': app_code,
                        'cnt': cnt,
                        'label': label or app_code,
                        'app_code_b64': app_code_b64,
                    })
                gpdl_num = len(gpdl_appear_code_rows)
            except Exception as e:
                logger.exception("Seating chart GPDL appear code query failed: %s", e)

    context = {
        'current_exam_label': getattr(msbte_config, 'ACA_NAME_EXAM_S', 'Summer 2026'),
        'courses': courses,
        'ex_form_stat': ex_form_stat,
        'appear_code_rows': appear_code_rows,
        'appear_code_labels': APPEAR_CODE_LABELS,
        'inst_code': inst_code,
        'is_admin': is_admin,
        'user_info': user_info,
        'show_gpdl': show_gpdl,
        'gpdl_num': gpdl_num,
        'is_gpdl_inst': is_gpdl_inst,
        'gpdl_appear_code_rows': gpdl_appear_code_rows,
    }
    return render(
        request,
        'seating_chart_inst/inst_seating_chart_coursewise_s13.html',
        context,
    )


REGION_MAP = {
    '1': 'MUMBAI',
    '2': 'PUNE',
    '3': 'NAGPUR',
    '4': 'CHHATRAPATI SAMBHAJI NAGAR',
}


@jwt_report_authorized(allowed_roles=['INSTITUTE', 'ADMIN'])
def inst_seating_chart_s13(request):
    """
    Seating chart report (opens after Proceed from inst_seating_chart_coursewise_s13).
    GET params: cs_id, sem, master, st (base64), instid (optional for admin).
    Mirrors PHP inst_seating_chart_s13: list of candidates by course/sem/master/status for institute.
    """
    auth, error = get_auth_context(
        request,
        redirect_url='dashboard:seating_chart:seating_chart_home',
        require_institute=False,
    )
    if error:
        return error

    user_info, error = get_user_control_info(
        request,
        auth,
        allowed_roles=['INSTITUTE', 'RBTE', 'ADMIN'],
        require_institute_code=False,
        redirect_url='dashboard:seating_chart:seating_chart_home',
        error_message='You are not authorised to view this report',
    )
    if error:
        return error

    def _decode(val):
        if not val:
            return ''
        s = (val or '').strip()
        if not s:
            return ''
        # Add padding so length is multiple of 4 (required for b64decode)
        pad = 4 - (len(s) % 4)
        if pad and pad != 4:
            s = s + ('=' * pad)
        try:
            return base64.b64decode(s.encode()).decode()
        except Exception:
            try:
                return base64.urlsafe_b64decode(s.encode()).decode()
            except Exception:
                return val

    course_code = _decode(request.GET.get('cs_id', '')).strip()
    sem = _decode(request.GET.get('sem', '')).strip()
    master = _decode(request.GET.get('master', '')).strip()
    st = _decode(request.GET.get('st', '')).strip()
    instid_param = (request.GET.get('instid') or '').strip()

    if not course_code:
        return render(request, 'seating_chart_inst/inst_seating_chart_s13.html', {
            'error_message': 'Please Select Course',
            'current_exam_label': getattr(msbte_config, 'ACA_NAME_EXAM_S', 'Summer 2026'),
        })
    if not sem:
        return render(request, 'seating_chart_inst/inst_seating_chart_s13.html', {
            'error_message': 'Please Select Year',
            'current_exam_label': getattr(msbte_config, 'ACA_NAME_EXAM_S', 'Summer 2026'),
        })
    if not st:
        return render(request, 'seating_chart_inst/inst_seating_chart_s13.html', {
            'error_message': 'Please Select Status',
            'current_exam_label': getattr(msbte_config, 'ACA_NAME_EXAM_S', 'Summer 2026'),
        })

    user_role = (user_info.get('user_role') or '').upper()
    is_admin = user_info.get('is_admin', False)
    uid = user_info.get('uid')

    if user_role == 'INSTITUTE' and uid:
        uid_str = str(uid).strip()
        if len(uid_str) == 7:
            inst_code = uid_str[-5:]
        else:
            inst_code = uid_str
            #[-4:] if len(uid_str) >= 4 else uid_str
    elif instid_param:
        inst_code = str(instid_param).lstrip('0') or instid_param
    else:
        inst_code = user_info.get('inst_code')
        if inst_code is not None:
            inst_code = str(inst_code).strip()

    if not inst_code:
        return render(request, 'seating_chart_inst/inst_seating_chart_s13.html', {
            'error_message': 'Institute code is required. Please open this report from Seating Chart Course-wise and select institute if you are Admin.',
            'current_exam_label': getattr(msbte_config, 'ACA_NAME_EXAM_S', 'Summer 2026'),
        })

    try:
        inst_code_int = int(str(inst_code).lstrip('0'))
    except (ValueError, TypeError):
        inst_code_int = inst_code

    master_str = ''
    inst_code_z = str(inst_code_int).zfill(4)
    params = [course_code, sem, inst_code_int, inst_code_z, st]
    if master:
        master = master.upper()
        master_str = ' AND master_code = %s'
        params.insert(2, master)

    conn = get_db_connection()
    tbl = msbte_config.SEATING_CHART
    # Match inst_code whether stored as integer or zero-padded string (e.g. 27 or "0027")
    query = f"""
        SELECT enroll_no, course_code, year_code, master_code, region_code, inst_code, status, center_code, name, seatno,
               last_exam_no, last_exam_seatno, appear_code,
               GROUP_CONCAT(CONCAT(COALESCE(sub_abbr,''), '-', COALESCE(thpr,''), '-', COALESCE(subthpr,'')) ORDER BY sr_no) AS sub_abbr
        FROM {tbl}
        WHERE course_code = %s AND (block IS NULL OR block NOT IN ('Y', 'D')) AND year_code = %s
        {master_str}
        AND (inst_code = %s OR inst_code = %s) AND status = %s
        GROUP BY enroll_no, course_code, year_code, master_code, status, appear_code, seatno, region_code, inst_code, center_code, name, last_exam_no, last_exam_seatno
        ORDER BY seatno, course_code, year_code, master_code, status
    """
    try:
        df = pd.read_sql(query, conn, params=params)
    except Exception as e:
        logger.exception("Seating chart s13 query failed: %s", e)
        return render(request, 'seating_chart_inst/inst_seating_chart_s13.html', {
            'error_message': 'Report query failed. Table or columns may differ.',
            'current_exam_label': getattr(msbte_config, 'ACA_NAME_EXAM_S', 'Summer 2026'),
        })

    if df.empty:
        from datetime import datetime
        # Region & institute name from INSTITUTES table even when there is no seating data
        reg_code_empty = get_region_inst(inst_code_int if isinstance(inst_code_int, int) else inst_code)
        region_empty = get_region_name(reg_code_empty) if reg_code_empty else '-'
        inst_name_empty = get_inst_name(inst_code_int) if isinstance(inst_code_int, int) else (
            get_inst_name(int(inst_code)) if str(inst_code).isdigit() else ''
        ) or f'Institute {inst_code}'
        # Zero‑padded institute code
        try:
            inst_code_display_empty = str(int(str(inst_code).lstrip('0'))).zfill(5)
        except (ValueError, TypeError):
            inst_code_display_empty = str(inst_code)
        return render(request, 'seating_chart_inst/inst_seating_chart_s13.html', {
            'report_rows': [],
            'no_data': True,
            'current_exam_label': getattr(msbte_config, 'ACA_NAME_EXAM_S', 'Summer 2026'),
            'inst_code': inst_code_display_empty,
            'inst_name': inst_name_empty,
            'region': region_empty,
            'print_date': datetime.now().strftime('%d/%m/%Y'),
            'printed_by': str(uid)[-4:].zfill(4) if uid and len(str(uid)) >= 4 else (str(uid) or '-'),
            'user_name': user_info.get('user_name', ''),
        })
     

    rows = []
    for _, r in df.iterrows():
        seatno = r.get('seatno')
        if pd.isna(seatno):
            seatno = ''
        else:
            seatno = str(seatno).strip()
        rows.append({
            'enroll_no': r.get('enroll_no'),
            'course_code': r.get('course_code'),
            'year_code': r.get('year_code'),
            'master_code': r.get('master_code'),
            'region_code': str(r.get('region_code') or ''),
            'name': r.get('name') or '',
            'seatno': 'N/A' if seatno == '000000' else seatno,
            'center_code': r.get('center_code') or '',
            'status': r.get('status') or '',
            'appear_code': r.get('appear_code') or '',
            'sub_abbr': r.get('sub_abbr') or '',
        })

    # Prefer region from INSTITUTES table to keep in sync with latest mappings
    reg_code = get_region_inst(inst_code_int if isinstance(inst_code_int, int) else inst_code)
    region = get_region_name(reg_code) if reg_code else '-'
    inst_name = get_inst_name(inst_code_int) if isinstance(inst_code_int, int) else (
        get_inst_name(int(inst_code)) if str(inst_code).isdigit() else ''
    )
    # Display inst_code as zero-padded (e.g. 00018) similar to legacy PHP
    try:
        inst_code_display = str(int(str(inst_code).lstrip('0'))).zfill(5)
    except (ValueError, TypeError):
        inst_code_display = str(inst_code)

    from datetime import datetime
    current_exam = getattr(msbte_config, 'ACA_NAME_EXAM_S', 'Summer 2026')
    print_date = datetime.now().strftime('%d/%m/%Y')
    printed_by = str(uid)[-4:].zfill(4) if uid and len(str(uid)) >= 4 else (str(uid) or '-')

    return render(request, 'seating_chart_inst/inst_seating_chart_s13.html', {
        'report_rows': rows,
        'current_exam_label': current_exam,
        'inst_code': inst_code_display,
        'inst_name': inst_name or f'Institute {inst_code}',
        'region': region,
        'print_date': print_date,
        'printed_by': printed_by,
        'user_name': user_info.get('user_name', ''),
        'is_appwise': False,
    })

@jwt_report_authorized(allowed_roles=['INSTITUTE', 'ADMIN'])
def inst_seating_chart_appwise_s13(request):
    """
    Seating chart report filtered by appear code (linked from coursewise page).
    GET: a (base64 appear_code), instid (optional), gpdl (optional).
    """
    auth, error = get_auth_context(request, redirect_url='dashboard:seating_chart:seating_chart_home', require_institute=False)
    if error:
        return error
    user_info, error = get_user_control_info(
        request, auth, allowed_roles=['INSTITUTE', 'RBTE', 'ADMIN'],
        require_institute_code=False, redirect_url='dashboard:seating_chart:seating_chart_home',
        error_message='You are not authorised to view this report',
    )
    if error:
        return error

    def _decode(val):
        if not val:
            return ''
        try:
            return base64.b64decode(val.encode()).decode()
        except Exception:
            return val

    a_param = (request.GET.get('a') or '').strip()
    instid_param = (request.GET.get('instid') or '').strip()
    gpdl = request.GET.get('gpdl') == '1'
    raw_appear = _decode(a_param).strip().upper()
    is_total = (raw_appear == '' or raw_appear == 'AL')
    appear_code = '' if is_total else raw_appear
    if is_total:
        appear_code_label = APPEAR_CODE_LABELS.get('', '(Total Candidates)')
    else:
        appear_code_label = APPEAR_CODE_LABELS.get(appear_code, f'({appear_code})')

    user_role = (user_info.get('user_role') or '').upper()
    uid = user_info.get('uid')
    is_jwt = user_info.get('is_jwt', False)
    # Resolve inst_code: URL instid first; then for INSTITUTE use JWT institute_code (not uid); session INSTITUTE from uid
    if instid_param:
        inst_code = str(instid_param).lstrip('0') or instid_param
    elif user_role == 'INSTITUTE':
        if is_jwt and user_info.get('inst_code'):
            inst_code = str(user_info['inst_code']).strip()
        elif uid and not is_jwt:
            uid_str = str(uid).strip()
            inst_code = uid_str[-5:] if len(uid_str) == 7 else (uid_str[-4:] if len(uid_str) >= 4 else uid_str)
        else:
            inst_code = user_info.get('inst_code')
            inst_code = str(inst_code).strip() if inst_code is not None else None
    else:
        inst_code = user_info.get('inst_code')
        inst_code = str(inst_code).strip() if inst_code is not None else None

    if not inst_code:
        return render(request, 'seating_chart_inst/inst_seating_chart_s13.html', {
            'error_message': 'Institute code is required.',
            'current_exam_label': getattr(msbte_config, 'ACA_NAME_EXAM_S', 'Summer 2026'),
        })

    try:
        inst_code_int = int(str(inst_code).lstrip('0'))
    except (ValueError, TypeError):
        inst_code_int = inst_code

    conn = get_db_connection()
    tbl = msbte_config.SEATING_CHART

    # Base WHERE clause (mirrors PHP: block NOT IN ('Y','D') and inst_code match)
    where_clauses = ["(block IS NULL OR block NOT IN ('Y', 'D'))", "inst_code = %s"]
    params = [inst_code_int]

    # GPDL filter: course_code in ('CC','EC','MC') when gpdl=1
    if gpdl:
        where_clauses.append("course_code IN ('CC','EC','MC')")

    # Appear code filter (empty/AL = total). For 'Y' (Already Exist) also match NULL/empty (legacy data).
    if is_total:
        where_clauses.append("(appear_code IS NULL OR appear_code = '')")
    elif appear_code == 'Y':
        where_clauses.append("(appear_code IS NULL OR appear_code = '' OR appear_code = 'Y')")
    else:
        where_clauses.append("appear_code = %s")
        params.append(appear_code)

    # RBTE region filter: region_code = last digit of uid (PHP: substr($uid,-1,1))
    if user_role == 'RBTE' and uid:
        uid_str = str(uid).strip()
        if uid_str:
            region_digit = uid_str[-1]
            if region_digit.isdigit():
                where_clauses.append("region_code = %s")
                params.append(region_digit)

    where_sql = " AND ".join(where_clauses)

    query = f"""
        SELECT enroll_no, course_code, year_code, master_code, region_code, inst_code, status, center_code, name, seatno,
               last_exam_no, last_exam_seatno, appear_code,
               GROUP_CONCAT(CONCAT(COALESCE(sub_abbr,''), '-', COALESCE(thpr,''), '-', COALESCE(subthpr,'')) ORDER BY sr_no) AS sub_abbr
        FROM {tbl}
        WHERE {where_sql}
        GROUP BY enroll_no, course_code, year_code, master_code, status, appear_code, seatno, region_code, inst_code, center_code, name, last_exam_no, last_exam_seatno
        ORDER BY seatno, course_code, year_code, master_code, status
    """
    try:
        df = pd.read_sql(query, conn, params=params)
    except Exception as e:
        logger.exception("Seating chart appwise query failed: %s", e)
        return render(request, 'seating_chart_inst/inst_seating_chart_s13.html', {
            'error_message': 'Report query failed.',
            'current_exam_label': getattr(msbte_config, 'ACA_NAME_EXAM_S', 'Summer 2026'),
        })

    rows = []
    for _, r in df.iterrows():
        seatno = r.get('seatno')
        seatno = '' if pd.isna(seatno) else str(seatno).strip()
        rows.append({
            'enroll_no': r.get('enroll_no'),
            'course_code': r.get('course_code'),
            'year_code': r.get('year_code'),
            'master_code': r.get('master_code'),
            'region_code': str(r.get('region_code') or ''),
            'name': r.get('name') or '',
            'seatno': 'N/A' if seatno == '000000' else seatno,
            'center_code': r.get('center_code') or '',
            'status': r.get('status') or '',
            'appear_code': r.get('appear_code') or '',
            'sub_abbr': r.get('sub_abbr') or '',
        })

    # Get region and institute name from INSTITUTES metadata (matches main report)
    reg_code = get_region_inst(inst_code_int if isinstance(inst_code_int, int) else inst_code)
    region = get_region_name(reg_code) if reg_code else '-'
    inst_name = get_inst_name(inst_code_int) if isinstance(inst_code_int, int) else (
        get_inst_name(int(inst_code)) if str(inst_code).isdigit() else ''
    )
    # Zero‑padded institute code like PHP (e.g. 00018)
    try:
        inst_code_display = str(int(str(inst_code).lstrip('0'))).zfill(5)
    except (ValueError, TypeError):
        inst_code_display = str(inst_code)
    from datetime import datetime
    current_exam = getattr(msbte_config, 'ACA_NAME_EXAM_S', 'Summer 2026')
    print_date = datetime.now().strftime('%d/%m/%Y')
    printed_by = str(uid)[-4:].zfill(4) if uid and len(str(uid)) >= 4 else (str(uid) or '-')

    return render(request, 'seating_chart_inst/inst_seating_chart_s13.html', {
        'report_rows': rows,
        'current_exam_label': current_exam,
        'inst_code': inst_code_display,
        'inst_name': inst_name or f'Institute {inst_code}',
        'region': region,
        'print_date': print_date,
        'printed_by': printed_by,
        'user_name': user_info.get('user_name', ''),
        'appear_code_label': appear_code_label,
        'is_appwise': True,
    })

from django.views.decorators.http import require_http_methods

@jwt_report_authorized(allowed_roles=['INSTITUTE', 'RBTE', 'ADMIN'])
def inst_seat_chart(request):
    """
    Seating Chart Correction. Role handling (stationary stat_inst style):
    ADMIN: all institutes (inst_code from JWT or GET instid; no instid => institute selection form).
    INSTITUTE: own institute (inst_code from JWT or session uid).
    RBTE: their region (inst_code from JWT or GET instid).
    - GET: show instructions + stats + enrollment search form.
    - POST: validate enrollment and show candidate rows.
    """
    # 1. Auth + role check
    auth, error = get_auth_context(
        request,
        redirect_url='dashboard:seating_chart:seating_chart_home',
        require_institute=False,
    )
    if error:
        return error

    user_info, error = get_user_control_info(
        request,
        auth,
        allowed_roles=['INSTITUTE', 'RBTE', 'ADMIN'],
        require_institute_code=False,
        redirect_url='dashboard:seating_chart:seating_chart_home',
        error_message='You are not authorised to view this report',
    )
    if error:
        return error

    user_role = (user_info.get('user_role') or auth.get('role') or '').upper()
    uid = user_info.get('uid')
    is_admin = user_info.get('is_admin', False)
    current_exam_label = getattr(msbte_config, 'ACA_NAME_EXAM_S', 'Summer 2026')

    # Optional institute carried in query string (after NIL confirmation) so we can
    # build a NIL Report link that targets the same institute.
    instid_param = (request.GET.get('instid') or request.POST.get('instid') or '').strip()
    instid_for_nil = None

    # Resolve inst_code by role (same pattern as inst_seating_chart_coursewise_s13)
    inst_code = None
    if not is_admin and user_role == 'INSTITUTE':
        if auth.get('is_jwt'):
            inst_code = auth.get('institute_code')
            if inst_code:
                inst_code = str(inst_code).strip()
            if not inst_code:
                current_exam_label = getattr(msbte_config, 'ACA_NAME_EXAM_S', 'Summer 2026')
                default_stats = {
                    'corrected_cands': 0, 'cand_conf': 0, 'cand_pending': 0,
                    'inst_conf': 0, 'inst_not_conf': 0, 'rbte_conf': 0, 'rbte_not_conf': 0,
                    'candidate_conf': None, 'institute_conf': None,
                }
                return render(request, 'seating_chart_inst/inst_seat_chart.html', {
                    'error_message': 'You are not authorised to view this report. Institute code is required in the token.',
                    'current_exam_label': current_exam_label,
                    'stats': default_stats,
                    'candidate_conf': None,
                    'institute_conf': None,
                    'enrollment_no': '',
                    'result_rows': [],
                    'search_performed': False,
                    'rbte_status': 0,
                    'user_info': user_info,
                })
            try:
                int(str(inst_code).lstrip('0'))
            except (ValueError, TypeError):
                current_exam_label = getattr(msbte_config, 'ACA_NAME_EXAM_S', 'Summer 2026')
                default_stats = {
                    'corrected_cands': 0, 'cand_conf': 0, 'cand_pending': 0,
                    'inst_conf': 0, 'inst_not_conf': 0, 'rbte_conf': 0, 'rbte_not_conf': 0,
                    'candidate_conf': None, 'institute_conf': None,
                }
                return render(request, 'seating_chart_inst/inst_seat_chart.html', {
                    'error_message': 'You are not authorised to view this report.',
                    'current_exam_label': current_exam_label,
                    'stats': default_stats,
                    'candidate_conf': None,
                    'institute_conf': None,
                    'enrollment_no': '',
                    'result_rows': [],
                    'search_performed': False,
                    'rbte_status': 0,
                    'user_info': user_info,
                })
        else:
            if not uid:
                current_exam_label = getattr(msbte_config, 'ACA_NAME_EXAM_S', 'Summer 2026')
                default_stats = {
                    'corrected_cands': 0, 'cand_conf': 0, 'cand_pending': 0,
                    'inst_conf': 0, 'inst_not_conf': 0, 'rbte_conf': 0, 'rbte_not_conf': 0,
                    'candidate_conf': None, 'institute_conf': None,
                }
                return render(request, 'seating_chart_inst/inst_seat_chart.html', {
                    'error_message': 'You are not authorised to view this report.',
                    'current_exam_label': current_exam_label,
                    'stats': default_stats,
                    'candidate_conf': None,
                    'institute_conf': None,
                    'enrollment_no': '',
                    'result_rows': [],
                    'search_performed': False,
                    'rbte_status': 0,
                    'user_info': user_info,
                })
            uid_str = str(uid).strip()
            if len(uid_str) == 7:
                inst_code = uid_str[-5:]
            elif len(uid_str) >= 4:
                inst_code = uid_str[-4:]
            else:
                inst_code = uid_str
    elif is_admin or user_role == 'RBTE':
        # For ADMIN/RBTE we’ll still restrict correction feature to institute accounts
        # (legacy PHP only allowed INSTITUTE)
        if auth.get('is_jwt'):
            inst_code = auth.get('institute_code')
        if not inst_code:
            instid_get = (request.GET.get('instid') or request.POST.get('instid') or '').strip()
            if instid_get:
                inst_code = str(instid_get).lstrip('0') or instid_get
        if not inst_code:
            inst_code = user_info.get('inst_code')
        if inst_code is not None:
            inst_code = str(inst_code).strip() or None
    elif user_role == 'RBTE':
        if auth.get('is_jwt'):
            inst_code = auth.get('institute_code')
        if not inst_code:
            instid_get = (request.GET.get('instid') or request.POST.get('instid') or '').strip()
            if instid_get:
                inst_code = str(instid_get).lstrip('0') or instid_get
        if not inst_code:
            inst_code = user_info.get('inst_code')
        if inst_code is not None:
            inst_code = str(inst_code).strip() or None

    # Fallback: use inst_code from get_user_control_info if INSTITUTE and we did not set it (e.g. session derivation)
    if user_role == 'INSTITUTE' and not inst_code:
        inst_code = user_info.get('inst_code')
        if inst_code is not None:
            inst_code = str(inst_code).strip() or None

    # Admin without inst_code: show institute selection form (like stationary stat_inst)
    if is_admin and not inst_code:
        conn = get_db_connection()
        exam_centers_query = f"""
            SELECT DISTINCT r.exam_center, i.inst_name
            FROM {msbte_config.W25_RAC_DC_DETAILS} r
            INNER JOIN {msbte_config.INSTITUTES} i ON i.inst_id = r.exam_center
            ORDER BY r.exam_center
        """
        try:
            df_ec = pd.read_sql(exam_centers_query, conn)
            exam_centers = [
                {'inst_id': int(r['exam_center']), 'inst_name': r['inst_name'] if pd.notna(r['inst_name']) else f"Institute {int(r['exam_center'])}"}
                for _, r in df_ec.iterrows()
            ]
        except Exception as e:
            logger.exception("Exam centers query failed: %s", e)
            exam_centers = []
        return render(request, 'seating_chart_inst/inst_seat_chart.html', {
            'exam_centers': exam_centers,
            'current_exam_label': current_exam_label,
            'user_info': user_info,
            'form_action': reverse('dashboard:seating_chart:seating_chart_inst:inst_seat_chart'),
        })

    # INSTITUTE or RBTE without inst_code: show error with full layout
    if not inst_code:
        default_stats = {
            'corrected_cands': 0, 'cand_conf': 0, 'cand_pending': 0,
            'inst_conf': 0, 'inst_not_conf': 0, 'rbte_conf': 0, 'rbte_not_conf': 0,
            'candidate_conf': None, 'institute_conf': None,
        }
        return render(request, 'seating_chart_inst/inst_seat_chart.html', {
            'error_message': 'You are not authorised to view this report. Institute code is required.',
            'current_exam_label': current_exam_label,
            'stats': default_stats,
            'candidate_conf': None,
            'institute_conf': None,
            'enrollment_no': '',
            'result_rows': [],
            'search_performed': False,
            'rbte_status': 0,
            'user_info': user_info,
        })

    # Try to convert inst_code to int for queries
    try:
        inst_code_int = int(str(inst_code).lstrip('0'))
    except (ValueError, TypeError):
        inst_code_int = inst_code

    conn = get_db_connection()
    current_exam_label = getattr(msbte_config, 'ACA_NAME_EXAM_S', 'Summer 2026')

    # 3. Load statistics (CORRECTION_TYPE)
    stat_query = f"""
        SELECT
            SUM(1) AS corrected_cands,
            SUM(IF(cand_conf = 'Y', 1, 0)) AS cand_conf,
            SUM(IF(cand_conf != 'Y', 1, 0)) AS cand_pending,
            SUM(IF(inst_conf = 'Y', 1, 0)) AS inst_conf,
            SUM(IF(inst_conf != 'Y', 1, 0)) AS inst_not_conf,
            SUM(IF(rbte_conf = 'Y', 1, 0)) AS rbte_conf,
            SUM(IF(rbte_conf != 'Y', 1, 0)) AS rbte_not_conf,
            MAX(cand_conf) AS candidate_conf,
            MAX(inst_conf) AS institute_conf
        FROM {msbte_config.CORRECTION_TYPE}
        WHERE inst_code = %s
    """
    from pandas import read_sql
    try:
        df_stat = read_sql(stat_query, conn, params=[inst_code_int])
        if df_stat.empty:
            stats = None
        else:
            raw = df_stat.iloc[0].to_dict()
            # Normalize numeric fields to int
            stats = {}
            for k, v in raw.items():
                if v is None:
                    stats[k] = 0
                else:
                    try:
                        stats[k] = int(float(v))
                    except (ValueError, TypeError):
                        stats[k] = v
    except Exception as e:
        logger.exception("Seating chart correction stats query failed: %s", e)
        stats = None

    candidate_conf = (stats or {}).get('candidate_conf')
    institute_conf = (stats or {}).get('institute_conf')
    # PHP: show "NIL REPORT SUBMITTED" when no correction records
    if not stats or (stats.get('corrected_cands') or 0) == 0:
        candidate_conf = 'E'
        institute_conf = 'E'

    # Success flag from redirect after correction submit (PHP: sflg A/U)
    success_flg = (request.GET.get('f') or request.POST.get('f') or '').strip().upper()

    # 4. Handle form submit (enrollment search)
    result_rows = []
    enrollment_no = (request.POST.get('en_no') or request.GET.get('en_no') or '').strip()
    rbte_conf_count = (stats or {}).get('rbte_conf', 0)
    search_performed = False
    error_message = None

    if request.method == 'POST':
        search_performed = True
        # Client‑side JS validate() already checks empty, but repeat server‑side
        if not enrollment_no:
            error_message = 'Please enter Candidate Enrollment Number.'
        elif rbte_conf_count:
            # In PHP: if($rbte_status!='') → "Seating Chart Already Confirmed By RBTE."
            error_message = 'Seating Chart Already Confirmed By RBTE.'
        else:
            # Check if record already confirmed by institute
            conf_query = f"""
                SELECT COUNT(*) AS cnt
                FROM {msbte_config.CORRECTION_TYPE}
                WHERE en_no = %s
                  AND course_code NOT IN ('CC','EC','MC')
                  AND inst_conf = 'Y'
            """
            try:
                df_conf = read_sql(conf_query, conn, params=[enrollment_no])
                already_conf = int(df_conf.iloc[0]['cnt']) > 0 if not df_conf.empty else False
            except Exception as e:
                logger.exception("Seating chart inst_conf check failed: %s", e)
                already_conf = False

            if already_conf:
                error_message = 'Record already confirmed by Institute.'
            else:
                # Fetch candidate rows from seating chart
                main_tbl = msbte_config.SEATING_CHART
                data_query = f"""
                    SELECT
                        enroll_no, name, course_code, year_code, master_code,
                        region_code, inst_code, status, last_exam_no, last_exam_seatno,
                        appear_code,
                        GROUP_CONCAT(
                            CONCAT(
                                COALESCE(sub_abbr, ''), '-', COALESCE(thpr, ''), '-', COALESCE(subthpr, '')
                            )
                            ORDER BY sr_no
                        ) AS sub_abbr
                    FROM {main_tbl}
                    WHERE enroll_no = %s
                      AND (block IS NULL OR block NOT IN ('Y','D'))
                      AND inst_code = %s
                      AND course_code NOT IN ('CC','EC','MC')
                    GROUP BY course_code, year_code, master_code, enroll_no, name,
                             region_code, inst_code, status, last_exam_no, last_exam_seatno, appear_code
                    ORDER BY year_code
                """
                try:
                    df_cand = read_sql(data_query, conn, params=[enrollment_no, inst_code_int])
                except Exception as e:
                    logger.exception("Seating chart correction candidate query failed: %s", e)
                    df_cand = None

                if df_cand is None or df_cand.empty:
                    error_message = 'Invalid Candidate.'
                else:
                    # For each row, we optionally re‑load sub_abbr when master_code == 'I'
                    rows = []
                    for _, r in df_cand.iterrows():
                        en_no_row = r.get('enroll_no')
                        course_code = r.get('course_code')
                        year_code = r.get('year_code')
                        master_code = (r.get('master_code') or '').strip()
                        base_sub_abbr = r.get('sub_abbr') or ''
                        last_exam_no = r.get('last_exam_no')
                        last_exam_seatno = r.get('last_exam_seatno')

                        # Recompute sub_abbr for master_code == 'I'
                        if master_code == 'I':
                            sub_q = f"""
                                SELECT
                                    master_code,
                                    GROUP_CONCAT(
                                        CONCAT(
                                            COALESCE(sub_abbr, ''), '-', COALESCE(thpr, ''), '-', COALESCE(subthpr, '')
                                        )
                                        ORDER BY sr_no
                                    ) AS sub_abbr
                                FROM {main_tbl}
                                WHERE enroll_no = %s
                                  AND course_code = %s
                                  AND year_code = %s
                                  AND master_code = %s
                            """
                            try:
                                df_sub = read_sql(sub_q, conn, params=[en_no_row, course_code, year_code, master_code])
                                sub_row = df_sub.iloc[0] if not df_sub.empty else None
                                sub_abbr_i = (sub_row['sub_abbr'] or '') if sub_row is not None else ''
                            except Exception as e:
                                logger.exception("Seating chart correction sub_abbr(I) query failed: %s", e)
                                sub_abbr_i = base_sub_abbr
                            final_sub_abbr = sub_abbr_i
                        else:
                            final_sub_abbr = base_sub_abbr

                        # Last exam label (PHP: get_exam_s_w)
                        last_exam_label = last_exam_no if last_exam_no else 'NA'
                        if not last_exam_no:
                            last_exam_label = 'NA'

                        # Last seat no: 'NA' if empty or 000000
                        last_seat_display = last_exam_seatno
                        if not last_seat_display or str(last_seat_display) == '000000':
                            last_seat_display = 'NA'

                        # Region name
                        region_code = str(r.get('region_code') or '')
                        region_name = REGION_MAP.get(region_code, '')

                        rows.append({
                            'enroll_no': en_no_row,
                            'name': r.get('name') or '',
                            'course_code': course_code,
                            'year_code': year_code,
                            'master_code': master_code,
                            'status': r.get('status') or '',
                            'region_name': region_name,
                            'inst_code': r.get('inst_code'),
                            'last_exam_label': last_exam_label,
                            'last_exam_seatno': last_seat_display,
                            'sub_abbr': final_sub_abbr,
                        })

                    result_rows = rows

    # When opening via link with en_no in GET (e.g. click on enrollment no in Candidate Details), load that candidate
    elif request.method == 'GET' and enrollment_no:
        if rbte_conf_count:
            error_message = 'Seating Chart Already Confirmed By RBTE.'
        else:
            main_tbl = msbte_config.SEATING_CHART
            data_query = f"""
                SELECT
                    enroll_no, name, course_code, year_code, master_code,
                    region_code, inst_code, status, last_exam_no, last_exam_seatno,
                    appear_code,
                    GROUP_CONCAT(
                        CONCAT(
                            COALESCE(sub_abbr, ''), '-', COALESCE(thpr, ''), '-', COALESCE(subthpr, '')
                        )
                        ORDER BY sr_no
                    ) AS sub_abbr
                FROM {main_tbl}
                WHERE enroll_no = %s
                  AND (block IS NULL OR block NOT IN ('Y','D'))
                  AND inst_code = %s
                  AND course_code NOT IN ('CC','EC','MC')
                GROUP BY course_code, year_code, master_code, enroll_no, name,
                         region_code, inst_code, status, last_exam_no, last_exam_seatno, appear_code
                ORDER BY year_code
            """
            try:
                df_cand = read_sql(data_query, conn, params=[enrollment_no, inst_code_int])
            except Exception as e:
                logger.exception("Seating chart correction candidate query (GET) failed: %s", e)
                df_cand = None
            if df_cand is None or df_cand.empty:
                search_performed = True
                error_message = 'Invalid Candidate.'
            else:
                rows = []
                for _, r in df_cand.iterrows():
                    en_no_row = r.get('enroll_no')
                    course_code = r.get('course_code')
                    year_code = r.get('year_code')
                    master_code = (r.get('master_code') or '').strip()
                    base_sub_abbr = r.get('sub_abbr') or ''
                    last_exam_no = r.get('last_exam_no')
                    last_exam_seatno = r.get('last_exam_seatno')
                    if master_code == 'I':
                        sub_q = f"""
                            SELECT GROUP_CONCAT(
                                CONCAT(COALESCE(sub_abbr,''), '-', COALESCE(thpr,''), '-', COALESCE(subthpr,''))
                                ORDER BY sr_no
                            ) AS sub_abbr
                            FROM {main_tbl}
                            WHERE enroll_no = %s AND course_code = %s AND year_code = %s AND master_code = %s
                        """
                        try:
                            df_sub = read_sql(sub_q, conn, params=[en_no_row, course_code, year_code, master_code])
                            sub_row = df_sub.iloc[0] if not df_sub.empty else None
                            final_sub_abbr = (sub_row['sub_abbr'] or '') if sub_row is not None else base_sub_abbr
                        except Exception as e:
                            logger.exception("Seating chart correction sub_abbr(I) query (GET) failed: %s", e)
                            final_sub_abbr = base_sub_abbr
                    else:
                        final_sub_abbr = base_sub_abbr
                    last_exam_label = last_exam_no if last_exam_no else 'NA'
                    last_seat_display = last_exam_seatno
                    if not last_seat_display or str(last_seat_display) == '000000':
                        last_seat_display = 'NA'
                    region_code = str(r.get('region_code') or '')
                    region_name = REGION_MAP.get(region_code, '')
                    rows.append({
                        'enroll_no': en_no_row,
                        'name': r.get('name') or '',
                        'course_code': course_code,
                        'year_code': year_code,
                        'master_code': master_code,
                        'status': r.get('status') or '',
                        'region_name': region_name,
                        'inst_code': r.get('inst_code'),
                        'last_exam_label': last_exam_label,
                        'last_exam_seatno': last_seat_display,
                        'sub_abbr': final_sub_abbr,
                    })
                result_rows = rows
                search_performed = True

    context = {
        'current_exam_label': current_exam_label,
        'stats': stats,
        'candidate_conf': candidate_conf,
        'institute_conf': institute_conf,
        'enrollment_no': enrollment_no,
        'result_rows': result_rows,
        'search_performed': search_performed,
        'error_message': error_message,
        'user_info': user_info,
        'rbte_status': (stats or {}).get('rbte_conf', 0),
        'inst_code': inst_code,
        'success_flg': success_flg,
    }
    return render(request, 'seating_chart_inst/inst_seat_chart.html', context)




# Remark dropdown options per correction type (value, label) for seating chart correction form.
# PHP: remark must not be '' or '0'; so "Other" uses '99'.
def _seat_chart_remark_invalid(remark):
    """Return True if remark is empty or '0' (PHP: $remark=='' || $remark=='0')."""
    if not remark or not str(remark).strip():
        return True
    return str(remark).strip() == '0'



SEATING_CHART_REMARK_OPTIONS = {
    # Course Code correction (PHP: course_remark) - [Must attach COB for change of course]
    'course_remark': [
        ('', '----Select Remark----'),
        ('1', 'Change of course (COB attached)'),
        ('2', 'As per COB certificate'),
        ('99', 'Other'),
    ],
    # Master Code correction (PHP: master_remark) - [Must attach COB for change of scheme]
    'master_remark': [
        ('', '----Select Remark----'),
        ('1', 'Change of scheme (COB attached)'),
        ('2', 'As per COB certificate'),
        ('99', 'Other'),
    ],
    # Institute Code correction (PHP: instcode_remark) - [Must attach COB for change of inst code]
    'instcode_remark': [
        ('', '----Select Remark----'),
        ('1', 'Change of institute (COB attached)'),
        ('2', 'As per COB certificate'),
        ('99', 'Other'),
    ],
    # Status Code correction (PHP: status_remark)
    'status_remark': [
        ('', '----Select Remark----'),
        ('1', 'Correction as per record'),
        ('2', 'As per gazette'),
        ('99', 'Other'),
    ],
    # Appear Code correction (PHP: appear_remark)
    'appear_remark': [
        ('', '----Select Remark----'),
        ('1', 'Correction as per appear code'),
        ('2', 'As per gazette'),
        ('99', 'Other'),
    ],
    # Last Exam correction (PHP: lastexam_remark) - [recent]
    'lastexam_remark': [
        ('', '----Select Remark----'),
        ('1', 'As per recent gazette'),
        ('2', 'Correction as per record'),
        ('99', 'Other'),
    ],
    # Last Seat correction (PHP: lastseat_remark) - [recent]
    'lastseat_remark': [
        ('', '----Select Remark----'),
        ('1', 'As per recent gazette'),
        ('2', 'Correction as per record'),
        ('99', 'Other'),
    ],
    # Subjects want to Appear - Add/Delete subjects (PHP: addsub_remark) - [Refer recent Gazette & COB; exemption case]
    'addsub_remark': [
        ('', '----Select Remark----'),
        ('1', 'Exemption - subject removed'),
        ('2', 'Subject added as per COB/Gazette'),
        ('3', 'Subject deleted - not appearing'),
        ('99', 'Other'),
    ],
    # Update Elective G1 (PHP: update_elective_remark)
    'update_elective_remark': [
        ('', '----Select Remark----'),
        ('1', 'Change of elective G1'),
        ('2', 'As per COB/Gazette'),
        ('99', 'Other'),
    ],
    # Update Elective G2 (PHP: update_elective_remark_g2)
    'update_elective_remark_g2': [
        ('', '----Select Remark----'),
        ('1', 'Change of elective G2'),
        ('2', 'As per COB/Gazette'),
        ('99', 'Other'),
    ],
    # Deleted (PHP: deleted_remark) - [either passed in all subjects or does not want to appear]
    'deleted_remark': [
        ('', '----Select Remark----'),
        ('1', 'Candidate passed in all subjects'),
        ('2', 'Candidate does not want to appear'),
        ('99', 'Other'),
    ],
}


def _inst_seat_chart_next_render(request, candidate, current_exam_label, user_info, inst_code,
                                  en_year_str, check_ele_scheme, check_ele_group, error_message):
    """Re-render inst_seat_chart_next template with error and full context."""
    return render(request, 'seating_chart_inst/inst_seat_chart_next.html', {
        'error_message': error_message,
        'candidate': candidate,
        'current_exam_label': current_exam_label,
        'user_info': user_info,
        'inst_code': inst_code,
        'appear_code_r': APPEAR_CODE_R,
        'appear_code_x': APPEAR_CODE_X,
        'en_year': en_year_str,
        'check_ele_scheme': check_ele_scheme,
        'check_ele_group': check_ele_group,
        'remark_options': SEATING_CHART_REMARK_OPTIONS,
    })


@jwt_report_authorized(allowed_roles=['INSTITUTE', 'RBTE', 'ADMIN'])
def inst_seat_chart_next(request):
    """
    Seating chart correction form for one candidate (PHP: inst_seat_chart_update).
    GET params: en_no, course_code, year_code, master_code, status, instid (optional).
    Shows candidate details and correction type checkboxes; POST saves to CORRECTION_TYPE.
    """
    auth, error = get_auth_context(
        request,
        redirect_url='dashboard:seating_chart:seating_chart_home',
        require_institute=False,
    )
    if error:
        return error

    user_info, error = get_user_control_info(
        request,
        auth,
        allowed_roles=['INSTITUTE', 'RBTE', 'ADMIN'],
        require_institute_code=False,
        redirect_url='dashboard:seating_chart:seating_chart_home',
        error_message='You are not authorised to view this report',
    )
    if error:
        return error

    user_role = (user_info.get('user_role') or auth.get('role') or '').upper()
    uid = user_info.get('uid')
    is_admin = user_info.get('is_admin', False)
    current_exam_label = getattr(msbte_config, 'ACA_NAME_EXAM_S', 'Summer 2026')
    inst_code = None

    # Resolve inst_code (same as inst_seat_chart)
    if not is_admin and user_role == 'INSTITUTE':
        if auth.get('is_jwt'):
            inst_code = auth.get('institute_code')
            if inst_code:
                inst_code = str(inst_code).strip()
        if not inst_code and uid:
            uid_str = str(uid).strip()
            if len(uid_str) == 7:
                inst_code = uid_str[-5:]
            elif len(uid_str) >= 4:
                inst_code = uid_str[-4:]
            else:
                inst_code = uid_str
    elif is_admin:
        if auth.get('is_jwt'):
            inst_code = auth.get('institute_code')
        if not inst_code:
            inst_code = (request.GET.get('instid') or request.POST.get('instid') or '').strip()
        if not inst_code:
            inst_code = user_info.get('inst_code')
        if inst_code is not None:
            inst_code = str(inst_code).strip() or None
    elif user_role == 'RBTE':
        inst_code = (request.GET.get('instid') or request.POST.get('instid') or '').strip()
        if not inst_code and auth.get('is_jwt'):
            inst_code = auth.get('institute_code')
        if not inst_code:
            inst_code = user_info.get('inst_code')
        if inst_code is not None:
            inst_code = str(inst_code).strip() or None

    if user_role == 'INSTITUTE' and not inst_code:
        inst_code = user_info.get('inst_code')
        if inst_code is not None:
            inst_code = str(inst_code).strip() or None

    if not inst_code:
        return render(request, 'seating_chart_inst/inst_seat_chart_next.html', {
            'error_message': 'Institute code is required.',
            'current_exam_label': current_exam_label,
            'user_info': user_info,
        })

    try:
        inst_code_int = int(str(inst_code).lstrip('0'))
    except (ValueError, TypeError):
        inst_code_int = inst_code

    en_no = (request.GET.get('en_no') or request.POST.get('en_no') or '').strip()
    course_code = (request.GET.get('course_code') or request.POST.get('course_code') or '').strip()
    year_code = (request.GET.get('year_code') or request.POST.get('year_code') or '').strip()
    master_code = (request.GET.get('master_code') or request.POST.get('master_code') or '').strip()
    # Candidate status: from GET or from hidden stat_code on POST (POST 'status' is correction type 6 when checkbox checked)
    status = (request.GET.get('status') or request.POST.get('stat_code') or '').strip().upper()

    if not en_no or not course_code or not year_code or not master_code or not status:
        return render(request, 'seating_chart_inst/inst_seat_chart_next.html', {
            'error_message': 'Missing parameters. Open this page from Seating Chart Correction by clicking enrollment number.',
            'current_exam_label': current_exam_label,
            'user_info': user_info,
        })

    conn = get_db_connection()
    read_sql = pd.read_sql

    # Check if already confirmed (any row for this candidate with inst_conf or rbte_conf = 'Y')
    chk_query = f"""
        SELECT MAX(inst_conf) AS inst_conf, MAX(rbte_conf) AS rbte_conf FROM {msbte_config.CORRECTION_TYPE}
        WHERE en_no = %s AND course_code = %s AND year_code = %s AND master_code = %s
          AND inst_code = %s AND course_code NOT IN ('CC','EC','MC')
    """
    try:
        df_chk = read_sql(chk_query, conn, params=[en_no, course_code, year_code, master_code, inst_code_int])
        if not df_chk.empty:
            row = df_chk.iloc[0]
            if str(row.get('inst_conf') or '') == 'Y' or str(row.get('rbte_conf') or '') == 'Y':
                return render(request, 'seating_chart_inst/inst_seat_chart_next.html', {
                    'error_message': 'Record already confirmed by Institute.',
                    'current_exam_label': current_exam_label,
                    'user_info': user_info,
                })
    except Exception as e:
        logger.exception("Correction type check failed: %s", e)

    # Load one candidate from seating chart
    main_tbl = msbte_config.SEATING_CHART
    if master_code.upper() == 'I':
        qry = f"""
            SELECT a.enroll_no, a.course_code, a.year_code, a.master_code, a.region_code, a.inst_code, a.status,
                   a.name, a.seatno, a.last_exam_no, a.last_exam_seatno, a.appear_code,
                   GROUP_CONCAT(CONCAT(COALESCE(b.subject_abbr,''), '-', COALESCE(b.subject_thpr,''), '-', COALESCE(b.subject_subthpr,'')) ORDER BY a.sr_no) AS sub_abbr
            FROM {main_tbl} a
            INNER JOIN {msbte_config.COURSE_SUB_MARKS} b ON a.course_code=b.course_code AND a.year_code=b.year_code AND a.master_code=b.master_code AND a.sr_no=b.sr_no
            WHERE a.enroll_no = %s AND a.course_code = %s AND a.year_code = %s AND a.master_code = %s
              AND a.inst_code = %s AND (a.block IS NULL OR a.block NOT IN ('Y','D')) AND a.course_code NOT IN ('CC','EC','MC')
            GROUP BY a.enroll_no, a.course_code, a.year_code, a.master_code, a.region_code, a.inst_code, a.status, a.name, a.seatno, a.last_exam_no, a.last_exam_seatno, a.appear_code
        """
    else:
        qry = f"""
            SELECT enroll_no, course_code, year_code, master_code, region_code, inst_code, status,
                   name, seatno, last_exam_no, last_exam_seatno, appear_code,
                   GROUP_CONCAT(CONCAT(COALESCE(sub_abbr,''), '-', COALESCE(thpr,''), '-', COALESCE(subthpr,'')) ORDER BY sr_no) AS sub_abbr
            FROM {main_tbl}
            WHERE enroll_no = %s AND course_code = %s AND year_code = %s AND master_code = %s
              AND inst_code = %s AND (block IS NULL OR block NOT IN ('Y','D')) AND course_code NOT IN ('CC','EC','MC')
            GROUP BY enroll_no, course_code, year_code, master_code, region_code, inst_code, status, name, seatno, last_exam_no, last_exam_seatno, appear_code
        """
    try:
        df_seat = read_sql(qry, conn, params=[en_no, course_code, year_code, master_code, inst_code_int])
    except Exception as e:
        logger.exception("Seating chart next query failed: %s", e)
        return render(request, 'seating_chart_inst/inst_seat_chart_next.html', {
            'error_message': 'Failed to load candidate.',
            'current_exam_label': current_exam_label,
            'user_info': user_info,
        })

    if df_seat.empty:
        return render(request, 'seating_chart_inst/inst_seat_chart_next.html', {
            'error_message': 'Invalid candidate or record not found.',
            'current_exam_label': current_exam_label,
            'user_info': user_info,
        })

    r = df_seat.iloc[0]
    region_code = str(r.get('region_code') or '')
    region_name = REGION_MAP.get(region_code, get_region_name(region_code) if region_code else '')
    last_exam_no = r.get('last_exam_no')
    last_exam_seatno = r.get('last_exam_seatno')
    last_exam_label = last_exam_no if last_exam_no else 'NA'
    last_seat_display = last_exam_seatno if (last_exam_seatno and str(last_exam_seatno) != '000000') else 'NA'
    # en_year: first 2 chars of enrollment (PHP: SUBSTR(en_no_req,0,2)); used for file upload / attach rules
    en_year_str = str(en_no)[:2] if en_no else '99'
    try:
        en_year_int = int(en_year_str)
    except ValueError:
        en_year_int = 99

    # Elective scheme: PHP checks CSM_EL and COURSE_SUB_MARKS group_flag G1/G2
    check_ele_scheme = 'N'
    check_ele_group = 'N'
    try:
        ele_q = f"SELECT 1 FROM {msbte_config.CSM_EL} WHERE course_code = %s AND year_code = %s AND master_code = %s LIMIT 1"
        df_ele = read_sql(ele_q, conn, params=[course_code, year_code, master_code])
        if not df_ele.empty:
            check_ele_scheme = 'Y'
            grp_q = f"SELECT 1 FROM {msbte_config.COURSE_SUB_MARKS} WHERE course_code = %s AND year_code = %s AND master_code = %s AND group_flag IN ('G1','G2') LIMIT 1"
            df_grp = read_sql(grp_q, conn, params=[course_code, year_code, master_code])
            if not df_grp.empty:
                check_ele_group = 'Y'
    except Exception as e:
        logger.exception("Elective check failed: %s", e)

    # Default sr_no for this candidate (one row per scheme in seating chart)
    sr_no_default = 0
    try:
        sr_q = f"SELECT sr_no FROM {main_tbl} WHERE enroll_no = %s AND course_code = %s AND year_code = %s AND master_code = %s AND inst_code = %s LIMIT 1"
        df_sr = read_sql(sr_q, conn, params=[en_no, course_code, year_code, master_code, inst_code_int])
        if not df_sr.empty:
            sr_no_default = int(df_sr.iloc[0]['sr_no'])
    except Exception as e:
        logger.exception("sr_no query failed: %s", e)

    candidate = {
        'enroll_no': r.get('enroll_no'),
        'name': r.get('name') or '',
        'course_code': r.get('course_code'),
        'year_code': r.get('year_code'),
        'master_code': r.get('master_code'),
        'region_code': region_code,
        'region_name': region_name,
        'inst_code': r.get('inst_code'),
        'status': r.get('status'),
        'last_exam_label': last_exam_label,
        'last_exam_seatno': last_seat_display,
        'last_exam_no': last_exam_no,
        'sub_abbr': r.get('sub_abbr') or '',
        'appear_code': (r.get('appear_code') or '').strip(),
        'seatno': r.get('seatno'),
    }

    # POST: save correction
    if request.method == 'POST' and request.POST.get('hid1') == '1':
        other_remark = (request.POST.get('other_remark') or '').strip()
        check_remark = request.POST.get('check_remark')
        if not check_remark or not other_remark:
            return _inst_seat_chart_next_render(request, candidate, current_exam_label, user_info, inst_code,
                en_year_str, check_ele_scheme, check_ele_group, 'Please tick Any Other Remark and enter remark.')

        entry_by = uid or (getattr(request.user, 'id', None) if hasattr(request, 'user') and getattr(request.user, 'is_authenticated', False) else 0)
        seat_no = candidate.get('seatno') or 0
        sr_no = sr_no_default
        reg_code = candidate.get('region_code', '')

        # Build one INSERT per selected correction type (PHP: valstr)
        insert_q = f"""
            INSERT INTO {msbte_config.CORRECTION_TYPE}
            (en_no, seat_no, course_code, year_code, master_code, sr_no, correction_type, inst_code, region_code, remark_id, before_corr, after_corr, add_del, remark, entry_on, entry_by)
            VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, NOW(), %s)
        """
        rows_to_insert = []

        def add_row(corr_type, remark_id, before_corr, after_corr, add_del='', sr_no_row=None):
            sn = sr_no_row if sr_no_row is not None else sr_no
            rows_to_insert.append((
                en_no, seat_no, course_code, year_code, master_code, sn, str(corr_type),
                inst_code_int, reg_code, str(remark_id or '0'), str(before_corr or '')[:500], str(after_corr or '')[:500], str(add_del or ''),
                other_remark[:500], entry_by
            ))

        def _subj_str(sr_no_val):
            """Return subject_abbr-subject_thpr-subject_subthpr for given sr_no from COURSE_SUB_MARKS."""
            try:
                q = f"""SELECT subject_abbr, subject_thpr, subject_subthpr FROM {msbte_config.COURSE_SUB_MARKS}
                       WHERE course_code = %s AND year_code = %s AND master_code = %s AND sr_no = %s LIMIT 1"""
                df = read_sql(q, conn, params=[course_code, year_code, master_code, sr_no_val])
                if df.empty:
                    return ''
                r = df.iloc[0]
                a = str(r.get('subject_abbr') or '')
                t = str(r.get('subject_thpr') or '')
                s = str(r.get('subject_subthpr') or '')
                return f"{a}-{t}-{s}".rstrip('-')
            except Exception as e:
                logger.exception("_subj_str failed: %s", e)
                return ''

        if request.POST.get('course'):
            c_code = (request.POST.get('c_code') or '').strip()
            course_remark = (request.POST.get('course_remark') or '').strip()
            if not c_code:
                return _inst_seat_chart_next_render(request, candidate, current_exam_label, user_info, inst_code,
                    en_year_str, check_ele_scheme, check_ele_group, 'Please enter corrected course code.')
            if _seat_chart_remark_invalid(course_remark):
                return _inst_seat_chart_next_render(request, candidate, current_exam_label, user_info, inst_code,
                    en_year_str, check_ele_scheme, check_ele_group, 'Please select Course Remark.')
            add_row('2', course_remark, candidate.get('course_code'), c_code)

        if request.POST.get('master'):
            m_code = (request.POST.get('m_code') or '').strip()
            master_remark = (request.POST.get('master_remark') or '').strip()
            if not m_code:
                return _inst_seat_chart_next_render(request, candidate, current_exam_label, user_info, inst_code,
                    en_year_str, check_ele_scheme, check_ele_group, 'Please enter corrected master code.')
            if _seat_chart_remark_invalid(master_remark):
                return _inst_seat_chart_next_render(request, candidate, current_exam_label, user_info, inst_code,
                    en_year_str, check_ele_scheme, check_ele_group, 'Please select Master Remark.')
            add_row('4', master_remark, candidate.get('master_code'), m_code)

        if request.POST.get('inst'):
            i_code = (request.POST.get('i_code') or '').strip()
            instcode_remark = (request.POST.get('instcode_remark') or '').strip()
            if not i_code:
                return _inst_seat_chart_next_render(request, candidate, current_exam_label, user_info, inst_code,
                    en_year_str, check_ele_scheme, check_ele_group, 'Please enter corrected institute code.')
            if _seat_chart_remark_invalid(instcode_remark):
                return _inst_seat_chart_next_render(request, candidate, current_exam_label, user_info, inst_code,
                    en_year_str, check_ele_scheme, check_ele_group, 'Please select Institute Code Remark.')
            add_row('5', instcode_remark, candidate.get('inst_code'), i_code)

        if request.POST.get('status'):
            s_code = (request.POST.get('s_code') or '').strip().upper()
            status_remark = (request.POST.get('status_remark') or '').strip()
            if not s_code:
                return _inst_seat_chart_next_render(request, candidate, current_exam_label, user_info, inst_code,
                    en_year_str, check_ele_scheme, check_ele_group, 'Please enter corrected status code.')
            if _seat_chart_remark_invalid(status_remark):
                return _inst_seat_chart_next_render(request, candidate, current_exam_label, user_info, inst_code,
                    en_year_str, check_ele_scheme, check_ele_group, 'Please select Status Remark.')
            add_row('6', status_remark, candidate.get('status'), s_code)

        if request.POST.get('appcode'):
            a_code = (request.POST.get('a_code') or '').strip().upper()
            appear_remark = (request.POST.get('appear_remark') or '').strip()
            if status == 'R' and a_code not in APPEAR_CODE_R:
                return _inst_seat_chart_next_render(request, candidate, current_exam_label, user_info, inst_code,
                    en_year_str, check_ele_scheme, check_ele_group, 'Please enter correct appear code for status R.')
            if status == 'X' and a_code not in APPEAR_CODE_X:
                return _inst_seat_chart_next_render(request, candidate, current_exam_label, user_info, inst_code,
                    en_year_str, check_ele_scheme, check_ele_group, 'Please enter correct appear code for status X.')
            if _seat_chart_remark_invalid(appear_remark):
                return _inst_seat_chart_next_render(request, candidate, current_exam_label, user_info, inst_code,
                    en_year_str, check_ele_scheme, check_ele_group, 'Please select Appear Remark.')
            add_row('7', appear_remark, candidate.get('appear_code'), a_code)

        if request.POST.get('lastexam'):
            l_exam = (request.POST.get('l_exam') or '').strip()
            lastexam_remark = (request.POST.get('lastexam_remark') or '').strip()
            if not l_exam:
                return _inst_seat_chart_next_render(request, candidate, current_exam_label, user_info, inst_code,
                    en_year_str, check_ele_scheme, check_ele_group, 'Please enter corrected last exam.')
            if _seat_chart_remark_invalid(lastexam_remark):
                return _inst_seat_chart_next_render(request, candidate, current_exam_label, user_info, inst_code,
                    en_year_str, check_ele_scheme, check_ele_group, 'Please select Last Exam Remark.')
            add_row('8', lastexam_remark, str(candidate.get('last_exam_no') or ''), l_exam)

        if request.POST.get('lastseat'):
            l_seat = (request.POST.get('l_seat') or '').strip()
            lastseat_remark = (request.POST.get('lastseat_remark') or '').strip()
            if not l_seat:
                return _inst_seat_chart_next_render(request, candidate, current_exam_label, user_info, inst_code,
                    en_year_str, check_ele_scheme, check_ele_group, 'Please enter corrected last seat.')
            if _seat_chart_remark_invalid(lastseat_remark):
                return _inst_seat_chart_next_render(request, candidate, current_exam_label, user_info, inst_code,
                    en_year_str, check_ele_scheme, check_ele_group, 'Please select Last Seat Remark.')
            add_row('9', lastseat_remark, str(candidate.get('last_exam_seatno') or ''), l_seat)

        if request.POST.get('deleted'):
            del_code = (request.POST.get('del_code') or '').strip()
            deleted_remark = (request.POST.get('deleted_remark') or '').strip()
            if del_code != '405':
                return _inst_seat_chart_next_render(request, candidate, current_exam_label, user_info, inst_code,
                    en_year_str, check_ele_scheme, check_ele_group, 'Please enter proper code for deleted (405).')
            if _seat_chart_remark_invalid(deleted_remark):
                return _inst_seat_chart_next_render(request, candidate, current_exam_label, user_info, inst_code,
                    en_year_str, check_ele_scheme, check_ele_group, 'Please select Deleted Remark.')
            add_row('11', deleted_remark, '', '405')

        # Subjects want to Appear (correction type 10): add and/or delete subjects
        if request.POST.get('subapp'):
            addsub_remark = (request.POST.get('addsub_remark') or '').strip()
            if _seat_chart_remark_invalid(addsub_remark):
                return _inst_seat_chart_next_render(request, candidate, current_exam_label, user_info, inst_code,
                    en_year_str, check_ele_scheme, check_ele_group, 'Please select Appearing Subject Remark.')
            bef_addsub = (request.POST.get('bef_addsub') or candidate.get('sub_abbr') or '').strip()
            bef_delsub = (request.POST.get('bef_delsub') or candidate.get('sub_abbr') or '').strip()
            add_list = [x.strip() for x in request.POST.getlist('add_sub') if x and str(x).strip() and str(x).strip() != '0']
            del_list = [x.strip() for x in request.POST.getlist('del_sub') if x and str(x).strip() and str(x).strip() != '0']
            if not add_list and not del_list:
                return _inst_seat_chart_next_render(request, candidate, current_exam_label, user_info, inst_code,
                    en_year_str, check_ele_scheme, check_ele_group, 'Please select Add or Delete Subject(s).')
            for sr in add_list:
                try:
                    sn = int(sr)
                except (ValueError, TypeError):
                    continue
                after_s = _subj_str(sn)
                add_row('10', addsub_remark, bef_delsub, after_s, '1', sr_no_row=sn)
            for sr in del_list:
                try:
                    sn = int(sr)
                except (ValueError, TypeError):
                    continue
                after_s = _subj_str(sn)
                add_row('10', addsub_remark, bef_addsub, after_s, '2', sr_no_row=sn)

        # Update Elective G1 (correction type 12)
        if request.POST.get('update_elective'):
            update_elective_remark = (request.POST.get('update_elective_remark') or '').strip()
            if _seat_chart_remark_invalid(update_elective_remark):
                return _inst_seat_chart_next_render(request, candidate, current_exam_label, user_info, inst_code,
                    en_year_str, check_ele_scheme, check_ele_group, 'Please select Elective Subject Remark.')
            bef_ele_sub = (request.POST.get('bef_ele_sub') or '').strip().rstrip(',')
            after_ele_srno = (request.POST.get('update_ele_sub1') or '').strip()
            if not after_ele_srno or after_ele_srno == '0':
                return _inst_seat_chart_next_render(request, candidate, current_exam_label, user_info, inst_code,
                    en_year_str, check_ele_scheme, check_ele_group, 'Please select Elective Subject.')
            after_parts = [p.strip() for p in after_ele_srno.replace('#', ',').split(',') if p.strip()]
            after_ele_sub = ','.join(_subj_str(int(p)) for p in after_parts if p.isdigit())
            for p in after_parts:
                try:
                    sn = int(p)
                except (ValueError, TypeError):
                    continue
                add_row('12', update_elective_remark, bef_ele_sub, after_ele_sub, '', sr_no_row=sn)

        # Update Elective G2 (correction type 12)
        if request.POST.get('update_elective_g2'):
            update_elective_remark_g2 = (request.POST.get('update_elective_remark_g2') or '').strip()
            if _seat_chart_remark_invalid(update_elective_remark_g2):
                return _inst_seat_chart_next_render(request, candidate, current_exam_label, user_info, inst_code,
                    en_year_str, check_ele_scheme, check_ele_group, 'Please select Elective Subject Remark G2.')
            bef_ele_sub_2 = (request.POST.get('bef_ele_sub_2') or '').strip().rstrip(',')
            after_ele_srno_2 = (request.POST.get('update_ele_sub2') or '').strip()
            if not after_ele_srno_2 or after_ele_srno_2 == '0':
                return _inst_seat_chart_next_render(request, candidate, current_exam_label, user_info, inst_code,
                    en_year_str, check_ele_scheme, check_ele_group, 'Please select Elective Subject for G2.')
            after_parts_2 = [p.strip() for p in after_ele_srno_2.replace('#', ',').split(',') if p.strip()]
            after_ele_sub_g2 = ','.join(_subj_str(int(p)) for p in after_parts_2 if p.isdigit())
            for p in after_parts_2:
                try:
                    sn = int(p)
                except (ValueError, TypeError):
                    continue
                add_row('12', update_elective_remark_g2, bef_ele_sub_2, after_ele_sub_g2, '', sr_no_row=sn)

        # Always add one "Any Other Remark" row (correction_type 99) so at least one row is inserted
        add_row('99', '0', '', '')

        try:
            conn_w = get_db_connection()
            with conn_w.cursor() as cursor:
                for row in rows_to_insert:
                    cursor.execute(insert_q, row)
            try:
                conn_w.commit()
            except Exception:
                pass
            messages.success(request, 'Correction submitted successfully.')
            return redirect(reverse('dashboard:seating_chart:seating_chart_inst:inst_seat_chart') + f'?en_no={en_no}&instid={inst_code}&f=A')
        except Exception as e:
            logger.exception("Correction insert failed: %s", e)
            return _inst_seat_chart_next_render(request, candidate, current_exam_label, user_info, inst_code,
                en_year_str, check_ele_scheme, check_ele_group, 'Correction could not be saved. Please try again.')

    return render(request, 'seating_chart_inst/inst_seat_chart_next.html', {
        'candidate': candidate,
        'current_exam_label': current_exam_label,
        'user_info': user_info,
        'inst_code': inst_code,
        'appear_code_r': APPEAR_CODE_R,
        'appear_code_x': APPEAR_CODE_X,
        'en_year': en_year_str,
        'check_ele_scheme': check_ele_scheme,
        'check_ele_group': check_ele_group,
        'sr_no_default': sr_no_default,
        'remark_options': SEATING_CHART_REMARK_OPTIONS,
    })

# Correction type id -> display name (PHP: CORRECTION_MASTER table)
CORRECTION_TYPE_NAMES = {
    '1': 'Name', '2': 'Course Code', '3': 'Year Code', '4': 'Master Code',
    '5': 'Institute Code', '6': 'Status Code', '7': 'Appear Code', '8': 'Last Exam',
    '9': 'Last Seat', '10': 'Subjects want to Appear', '11': 'Deleted',
    '12': 'Update Elective', '99': 'Any Other Remark',
}


@jwt_report_authorized(allowed_roles=['INSTITUTE', 'RBTE', 'ADMIN'])
def inst_seat_chart_conf(request):
    """
    Seating chart correction confirmation (PHP: inst_seat_chart_conf).
    GET: List correction records for institute (entry_by=uid, cand_conf!='Y', inst_conf!='Y', rbte_conf!='Y').
    POST: Confirm selected records (set cand_conf='Y', cand_conf_by, cand_conf_on); redirect with f=C.
    """
    auth, error = get_auth_context(
        request,
        redirect_url='dashboard:seating_chart:seating_chart_home',
        require_institute=False,
    )
    if error:
        return error

    user_info, err = get_user_control_info(
        request,
        auth,
        allowed_roles=['INSTITUTE', 'RBTE', 'ADMIN'],
        require_institute_code=False,
        redirect_url='dashboard:seating_chart:seating_chart_home',
        error_message='You are not authorised.',
    )
    if err:
        return err

    uid = user_info.get('uid')
    # For legacy PHP, entry_by stored institute id derived from USER_ID.
    # If uid is missing (e.g. some admin/RBTE contexts), just use 0 so we
    # show an empty list instead of redirecting to home.
    if uid:
        try:
            entry_by_int = int(str(uid).strip())
        except (ValueError, TypeError):
            entry_by_int = uid
    else:
        entry_by_int = 0

    current_exam_label = getattr(msbte_config, 'ACA_NAME_EXAM_S', 'Summer 2026')
    conn = get_db_connection()
    read_sql = pd.read_sql

    if request.method == 'POST' and request.POST.get('hid') == '1':
        chk_num = (request.POST.get('num') or '').strip()
        if not chk_num:
            return render(request, 'seating_chart_inst/inst_seat_chart_conf.html', {
                'error_message': 'Please check the checkbox to confirm candidates.',
                'current_exam_label': current_exam_label,
                'user_info': user_info,
                'records': [],
                'num': 0,
            })
        try:
            n = int(chk_num)
        except ValueError:
            n = 0
        for j in range(1, n + 1):
            val = (request.POST.get(f'chk{j}') or '').strip()
            if not val:
                continue
            parts = val.split('-')
            if len(parts) < 7:
                continue
            seat_no_i, en_no, correction_type, course_code, year_code, master_code, id_val = (
                parts[0], parts[1], parts[2], parts[3], parts[4], parts[5], parts[6]
            )
            if not seat_no_i:
                continue
            upd_sql = f"""
                UPDATE {msbte_config.CORRECTION_TYPE}
                SET cand_conf = 'Y', cand_conf_by = %s, cand_conf_on = NOW()
                WHERE seat_no = %s AND course_code = %s AND year_code = %s AND master_code = %s
                  AND correction_type = %s AND id = %s AND course_code NOT IN ('CC','EC','MC')
                LIMIT 1
            """
            try:
                with conn.cursor() as cursor:
                    cursor.execute(upd_sql, [
                        entry_by_int, seat_no_i, course_code, year_code, master_code, correction_type, id_val,
                    ])
            except Exception as e:
                logger.exception("Confirmation update failed for chk%s: %s", j, e)
        try:
            conn.commit()
        except Exception:
            pass
        return redirect(reverse('dashboard:seating_chart:seating_chart_inst:inst_seat_chart_conf') + '?f=C')

    selconf = f"""
        SELECT id, en_no, seat_no, course_code, year_code, master_code, correction_type, inst_code, region_code
        FROM {msbte_config.CORRECTION_TYPE}
        WHERE entry_by = %s AND (cand_conf IS NULL OR cand_conf != 'Y')
          AND (inst_conf IS NULL OR inst_conf != 'Y') AND (rbte_conf IS NULL OR rbte_conf != 'Y')
          AND course_code NOT IN ('CC','EC','MC')
        ORDER BY id
    """
    try:
        df_conf = read_sql(selconf, conn, params=[entry_by_int])
    except Exception as e:
        logger.exception("Seating chart conf list query failed: %s", e)
        df_conf = pd.DataFrame()

    if df_conf.empty:
        return render(request, 'seating_chart_inst/inst_seat_chart_conf.html', {
            'current_exam_label': current_exam_label,
            'user_info': user_info,
            'records': [],
            'num': 0,
            'success_f': request.GET.get('f', ''),
        })

    main_tbl = msbte_config.SEATING_CHART
    unique_keys = df_conf[['en_no', 'course_code', 'year_code', 'master_code', 'inst_code']].drop_duplicates()
    seat_info = {}
    for _, r in unique_keys.iterrows():
        en_no, cc, yc, mc, inst_c = r['en_no'], r['course_code'], r['year_code'], r['master_code'], r['inst_code']
        try:
            inst_c_int = int(str(inst_c).lstrip('0'))
        except (ValueError, TypeError):
            inst_c_int = inst_c
        q = f"""
            SELECT name, status, last_exam_no, last_exam_seatno,
                   GROUP_CONCAT(CONCAT(COALESCE(sub_abbr,''), '-', COALESCE(thpr,''), '-', COALESCE(subthpr,'')) ORDER BY sr_no) AS sub_abbr
            FROM {main_tbl}
            WHERE enroll_no = %s AND course_code = %s AND year_code = %s AND master_code = %s AND inst_code = %s
              AND (block IS NULL OR block NOT IN ('Y','D'))
            GROUP BY name, status, last_exam_no, last_exam_seatno
        """
        try:
            df_seat = read_sql(q, conn, params=[en_no, cc, yc, mc, inst_c_int])
            if not df_seat.empty:
                row = df_seat.iloc[0]
                key = (en_no, cc, yc, mc, inst_c)
                seat_info[key] = {
                    'name': row.get('name') or '',
                    'status': row.get('status') or '',
                    'sub_abbr': row.get('sub_abbr') or '',
                    'last_exam_no': row.get('last_exam_no'),
                    'last_exam_seatno': row.get('last_exam_seatno'),
                }
        except Exception as e:
            logger.exception("Seat info for %s failed: %s", (en_no, cc, yc, mc), e)

    records = []
    for idx, r in df_conf.iterrows():
        key = (r['en_no'], r['course_code'], r['year_code'], r['master_code'], r['inst_code'])
        info = seat_info.get(key, {})
        last_exam_seatno = info.get('last_exam_seatno')
        if not last_exam_seatno or str(last_exam_seatno) == '000000':
            last_seatno_display = 'NA'
        else:
            last_seatno_display = last_exam_seatno
        region_code = str(r.get('region_code') or '')
        region_code_short = region_code.lstrip('0') or region_code
        region_name = REGION_MAP.get(region_code_short, get_region_name(region_code) if region_code else '') or '-'
        records.append({
            'id': r['id'],
            'seat_no': r['seat_no'],
            'en_no': r['en_no'],
            'name': info.get('name', ''),
            'sub_abbr': info.get('sub_abbr', ''),
            'correction_type': r['correction_type'],
            'correction_type_name': CORRECTION_TYPE_NAMES.get(str(r['correction_type']), str(r['correction_type'])),
            'course_code': r['course_code'],
            'year_code': r['year_code'],
            'master_code': r['master_code'],
            'scheme': f"{r['course_code']}-{r['year_code']}-{r['master_code']}",
            'status': info.get('status', ''),
            'region_name': region_name,
            'inst_code': r['inst_code'],
            'last_exam_no': info.get('last_exam_no'),
            'last_exam_seatno': last_seatno_display,
            'chk_value': f"{r['seat_no']}-{r['en_no']}-{r['correction_type']}-{r['course_code']}-{r['year_code']}-{r['master_code']}-{r['id']}",
        })

    return render(request, 'seating_chart_inst/inst_seat_chart_conf.html', {
        'current_exam_label': current_exam_label,
        'user_info': user_info,
        'records': records,
        'num': len(records),
        'success_f': request.GET.get('f', ''),
        'seat_no': request.GET.get('s_no', ''),
    })


@jwt_report_authorized(allowed_roles=['INSTITUTE', 'RBTE', 'ADMIN'])
def inst_seat_chart_final_conf(request):
    """
    Seating Chart Correction Final Confirmation (PHP: inst_seat_chart_conf with different flow).
    Lists candidates where cand_conf='Y', inst_conf!='Y', rbte_conf!='Y' for institute.
    On confirm: sets inst_conf='Y', inst_conf_by, inst_conf_on.
    """
    auth, error = get_auth_context(
        request,
        redirect_url='dashboard:seating_chart:seating_chart_home',
        require_institute=False,
    )
    if error:
        return error

    user_info, err = get_user_control_info(
        request,
        auth,
        allowed_roles=['INSTITUTE', 'RBTE', 'ADMIN'],
        require_institute_code=False,
        redirect_url='dashboard:seating_chart:seating_chart_home',
        error_message='You are not authorised.',
    )
    if err:
        return err

    user_role = (user_info.get('user_role') or auth.get('role') or '').upper()
    uid = user_info.get('uid')
    is_admin = user_info.get('is_admin', False)

    # Capture any explicit instid passed in (e.g. after NIL confirmation under ADMIN/RBTE)
    # so we can propagate it to the NIL report URL.
    instid_param = (request.GET.get('instid') or request.POST.get('instid') or '').strip()
    instid_for_nil = None
    current_exam_label = getattr(msbte_config, 'ACA_NAME_EXAM_S', 'Summer 2026')

    # Resolve inst_code (same pattern as inst_seat_chart / inst_seating_chart_coursewise_s13)
    inst_code = None
    if not is_admin and user_role == 'INSTITUTE':
        if auth.get('is_jwt'):
            inst_code = auth.get('institute_code')
            if inst_code:
                inst_code = str(inst_code).strip()
        if not inst_code and uid:
            uid_str = str(uid).strip()
            if len(uid_str) == 7:
                inst_code = uid_str[-5:]
            elif len(uid_str) >= 4:
                inst_code = uid_str[-4:]
            else:
                inst_code = uid_str
    elif is_admin or user_role == 'RBTE':
        instid_get = (request.GET.get('instid') or request.POST.get('instid') or '').strip()
        if instid_get:
            inst_code = str(instid_get).lstrip('0') or instid_get
        if not inst_code and auth.get('is_jwt'):
            inst_code = auth.get('institute_code')
            if inst_code:
                inst_code = str(inst_code).strip()
        if not inst_code:
            inst_code = user_info.get('inst_code')
        if inst_code is not None:
            inst_code = str(inst_code).strip() or None

    # Fallback: INSTITUTE may get inst_code from user_info
    if user_role == 'INSTITUTE' and not inst_code:
        inst_code = user_info.get('inst_code')
        if inst_code is not None:
            inst_code = str(inst_code).strip() or None

    # Admin without inst_code: show institute selection form (like inst_seat_chart)
    if is_admin and not inst_code:
        conn = get_db_connection()
        exam_centers_query = f"""
            SELECT DISTINCT r.exam_center, i.inst_name
            FROM {msbte_config.W25_RAC_DC_DETAILS} r
            INNER JOIN {msbte_config.INSTITUTES} i ON i.inst_id = r.exam_center
            ORDER BY r.exam_center
        """
        try:
            df_ec = pd.read_sql(exam_centers_query, conn)
            exam_centers = [
                {'inst_id': int(r['exam_center']), 'inst_name': r['inst_name'] if pd.notna(r['inst_name']) else f"Institute {int(r['exam_center'])}"}
                for _, r in df_ec.iterrows()
            ]
        except Exception as e:
            logger.exception("Exam centers query failed: %s", e)
            exam_centers = []
        return render(request, 'seating_chart_inst/inst_seat_chart_final_conf.html', {
            'exam_centers': exam_centers,
            'current_exam_label': current_exam_label,
            'user_info': user_info,
            'form_action': reverse('dashboard:seating_chart:seating_chart_inst:inst_seat_chart_final_conf'),
            'records': [],
            'num': 0,
            'success_f': '',
        })

    if not inst_code:
        return render(request, 'seating_chart_inst/inst_seat_chart_final_conf.html', {
            'error_message': 'Institute code is required. You are not authorised to view this report.',
            'current_exam_label': current_exam_label,
            'user_info': user_info,
            'records': [],
            'num': 0,
            'success_f': '',
        })

    try:
        inst_code_int = int(str(inst_code).lstrip('0'))
    except (ValueError, TypeError):
        inst_code_int = inst_code

    conn = get_db_connection()
    read_sql = pd.read_sql

    # POST: confirm selected records (set inst_conf='Y')
    if request.method == 'POST' and request.POST.get('hid') == '1':
        chk_num = (request.POST.get('num') or '').strip()
        if not chk_num:
            return render(request, 'seating_chart_inst/inst_seat_chart_final_conf.html', {
                'error_message': 'Please check the checkbox to confirm candidates.',
                'current_exam_label': current_exam_label,
                'user_info': user_info,
                'records': [],
                'num': 0,
                'success_f': '',
            })
        try:
            n = int(chk_num)
        except ValueError:
            n = 0
        for j in range(1, n + 1):
            val = (request.POST.get(f'chk{j}') or '').strip()
            if not val:
                continue
            parts = val.split('-')
            # PHP format: seat_no-en_no-correction_type-id-course_code-year_code-master_code
            if len(parts) < 7:
                continue
            seat_no_i, en_no, correction_type, id_val, course_code, year_code, master_code = (
                parts[0], parts[1], parts[2], parts[3], parts[4], parts[5], parts[6]
            )
            if not seat_no_i:
                continue
            upd_sql = f"""
                UPDATE {msbte_config.CORRECTION_TYPE}
                SET inst_conf = 'Y', inst_conf_by = %s, inst_conf_on = NOW()
                WHERE en_no = %s AND course_code = %s AND year_code = %s AND master_code = %s
                  AND id = %s AND correction_type = %s
                  AND course_code NOT IN ('CC','EC','MC')
                LIMIT 1
            """
            try:
                with conn.cursor() as cursor:
                    cursor.execute(upd_sql, [
                        inst_code_int, en_no, course_code, year_code, master_code, id_val, correction_type,
                    ])
            except Exception as e:
                logger.exception("Final confirmation update failed for chk%s: %s", j, e)
        try:
            conn.commit()
        except Exception:
            pass
        # PHP redirects to inst_seat_chart_rep?f=F; redirect to same page with success flag
        return redirect(reverse('dashboard:seating_chart:seating_chart_inst:inst_seat_chart_final_conf') + '?f=F')

    # GET: list candidates (cand_conf='Y', inst_conf!='Y', rbte_conf!='Y')
    selfinal = f"""
        SELECT id, en_no, seat_no, course_code, year_code, master_code, correction_type, inst_code, region_code,
               inst_conf, rbte_conf
        FROM {msbte_config.CORRECTION_TYPE}
        WHERE inst_code = %s AND cand_conf = 'Y'
          AND (inst_conf IS NULL OR inst_conf != 'Y')
          AND (rbte_conf IS NULL OR rbte_conf != 'Y')
          AND course_code NOT IN ('CC','EC','MC')
        ORDER BY id
    """
    try:
        df_final = read_sql(selfinal, conn, params=[inst_code_int])
    except Exception as e:
        logger.exception("Final conf list query failed: %s", e)
        df_final = pd.DataFrame()

    if df_final.empty:
        return render(request, 'seating_chart_inst/inst_seat_chart_final_conf.html', {
            'error_message': 'Candidate not found to confirm.',
            'current_exam_label': current_exam_label,
            'user_info': user_info,
            'records': [],
            'num': 0,
            'success_f': request.GET.get('f', ''),
        })

    # Check for Nil Report (inst_conf='E' or rbte_conf='E')
    nil_conf = df_final[(df_final['inst_conf'].astype(str).str.upper() == 'E') |
                        (df_final['rbte_conf'].astype(str).str.upper() == 'E')]
    if 'inst_conf' in df_final.columns and 'rbte_conf' in df_final.columns and not nil_conf.empty:
        return render(request, 'seating_chart_inst/inst_seat_chart_final_conf.html', {
            'error_message': 'Nil Report Confirmed. Please submit to your respective RBTE.',
            'current_exam_label': current_exam_label,
            'user_info': user_info,
            'records': [],
            'num': 0,
            'success_f': '',
        })

    main_tbl = msbte_config.SEATING_CHART
    records = []
    for idx, r in df_final.iterrows():
        en_no = r['en_no']
        course_code = r['course_code']
        year_code = r['year_code']
        master_code = r['master_code']
        inst_c = r.get('inst_code')
        try:
            inst_c_int = int(str(inst_c).lstrip('0')) if inst_c else inst_code_int
        except (ValueError, TypeError):
            inst_c_int = inst_code_int
        q = f"""
            SELECT name, status, last_exam_no, last_exam_seatno,
                   GROUP_CONCAT(CONCAT(COALESCE(sub_abbr,''), '-', COALESCE(thpr,''), '-', COALESCE(subthpr,'')) ORDER BY sr_no) AS sub_abbr
            FROM {main_tbl}
            WHERE enroll_no = %s AND course_code = %s AND year_code = %s AND master_code = %s AND inst_code = %s
              AND (block IS NULL OR block NOT IN ('Y','D'))
            GROUP BY name, status, last_exam_no, last_exam_seatno
        """
        try:
            df_seat = read_sql(q, conn, params=[en_no, course_code, year_code, master_code, inst_c_int])
            if df_seat.empty:
                row = {'name': '', 'status': '', 'sub_abbr': '', 'last_exam_no': None, 'last_exam_seatno': None}
            else:
                row = df_seat.iloc[0].to_dict()
        except Exception as e:
            logger.exception("Seat info for %s failed: %s", (en_no, course_code, year_code, master_code), e)
            row = {'name': '', 'status': '', 'sub_abbr': '', 'last_exam_no': None, 'last_exam_seatno': None}

        last_seatno = row.get('last_exam_seatno')
        if not last_seatno or str(last_seatno) == '000000':
            last_seatno_display = 'NA'
        else:
            last_seatno_display = last_seatno

        last_exam_no = row.get('last_exam_no')
        lexam = last_exam_no if last_exam_no else 'NA'

        region_code = str(r.get('region_code') or '')
        region_code_short = region_code.lstrip('0') or region_code
        region_name = REGION_MAP.get(region_code_short, get_region_name(region_code) if region_code else '') or '-'

        seat_no = r.get('seat_no', '')
        correction_type = r.get('correction_type', '')
        id_val = r.get('id', '')
        # PHP checkbox value: seat_no-en_no-correction_type-id-course_code-year_code-master_code
        chk_value = f"{seat_no}-{en_no}-{correction_type}-{id_val}-{course_code}-{year_code}-{master_code}"

        records.append({
            'id': id_val,
            'seat_no': seat_no,
            'en_no': en_no,
            'name': row.get('name', ''),
            'sub_abbr': row.get('sub_abbr', ''),
            'correction_type': correction_type,
            'correction_type_name': CORRECTION_TYPE_NAMES.get(str(correction_type), str(correction_type)),
            'course_code': course_code,
            'year_code': year_code,
            'master_code': master_code,
            'scheme': f"{course_code}-{year_code}-{master_code}",
            'status': row.get('status', ''),
            'region_name': region_name,
            'inst_code': r.get('inst_code'),
            'last_exam_no': lexam,
            'last_exam_seatno': last_seatno_display,
            'chk_value': chk_value,
        })

    return render(request, 'seating_chart_inst/inst_seat_chart_final_conf.html', {
        'current_exam_label': current_exam_label,
        'user_info': user_info,
        'records': records,
        'num': len(records),
        'success_f': request.GET.get('f', ''),
    })


@jwt_report_authorized(allowed_roles=['INSTITUTE', 'RBTE', 'ADMIN'])
def inst_seat_chart_nil_conf(request):
    """
    Nil Confirmation of Seating Chart Correction (PHP: inst_seat_chart_nil_conf).
    When institute has NO corrections, they confirm nil with checkbox and remark.
    """
    auth, error = get_auth_context(
        request,
        redirect_url='dashboard:seating_chart:seating_chart_home',
        require_institute=False,
    )
    if error:
        return error

    user_info, err = get_user_control_info(
        request,
        auth,
        allowed_roles=['INSTITUTE', 'RBTE', 'ADMIN'],
        require_institute_code=False,
        redirect_url='dashboard:seating_chart:seating_chart_home',
        error_message='You are not authorised.',
    )
    if err:
        return err

    user_role = (user_info.get('user_role') or auth.get('role') or '').upper()
    uid = user_info.get('uid')
    is_admin = user_info.get('is_admin', False)
    current_exam_label = getattr(msbte_config, 'ACA_NAME_EXAM_S', 'Summer 2026')

    # Resolve inst_code (same pattern as inst_seat_chart / inst_seat_chart_final_conf)
    inst_code = None
    if not is_admin and user_role == 'INSTITUTE':
        if auth.get('is_jwt'):
            inst_code = auth.get('institute_code')
            if inst_code:
                inst_code = str(inst_code).strip()
        if not inst_code and uid:
            uid_str = str(uid).strip()
            if len(uid_str) == 7:
                inst_code = uid_str[-5:]
            elif len(uid_str) >= 4:
                inst_code = uid_str[-4:]
            else:
                inst_code = uid_str
    elif is_admin or user_role == 'RBTE':
        instid_get = (request.GET.get('instid') or request.POST.get('instid') or '').strip()
        if instid_get:
            inst_code = str(instid_get).lstrip('0') or instid_get
        if not inst_code and auth.get('is_jwt'):
            inst_code = auth.get('institute_code')
            if inst_code:
                inst_code = str(inst_code).strip()
        if not inst_code:
            inst_code = user_info.get('inst_code')
        if inst_code is not None:
            inst_code = str(inst_code).strip() or None

    if user_role == 'INSTITUTE' and not inst_code:
        inst_code = user_info.get('inst_code')
        if inst_code is not None:
            inst_code = str(inst_code).strip() or None

    # Admin without inst_code: show institute selection form
    if is_admin and not inst_code:
        conn = get_db_connection()
        exam_centers_query = f"""
            SELECT DISTINCT r.exam_center, i.inst_name
            FROM {msbte_config.W25_RAC_DC_DETAILS} r
            INNER JOIN {msbte_config.INSTITUTES} i ON i.inst_id = r.exam_center
            ORDER BY r.exam_center
        """
        try:
            df_ec = pd.read_sql(exam_centers_query, conn)
            exam_centers = [
                {'inst_id': int(r['exam_center']), 'inst_name': r['inst_name'] if pd.notna(r['inst_name']) else f"Institute {int(r['exam_center'])}"}
                for _, r in df_ec.iterrows()
            ]
        except Exception as e:
            logger.exception("Exam centers query failed: %s", e)
            exam_centers = []
        return render(request, 'seating_chart_inst/inst_seat_chart_nil_conf.html', {
            'exam_centers': exam_centers,
            'current_exam_label': current_exam_label,
            'user_info': user_info,
            'form_action': reverse('dashboard:seating_chart:seating_chart_inst:inst_seat_chart_nil_conf'),
        })

    if not inst_code:
        return render(request, 'seating_chart_inst/inst_seat_chart_nil_conf.html', {
            'error_message': 'Institute code is required. You are not authorised to view this report.',
            'current_exam_label': current_exam_label,
            'user_info': user_info,
        })

    try:
        inst_code_int = int(str(inst_code).lstrip('0'))
    except (ValueError, TypeError):
        inst_code_int = inst_code

    conn = get_db_connection()

    # POST: submit nil confirmation
    if request.method == 'POST' and request.POST.get('hid') == '1':
        priconf = (request.POST.get('priconf') or '').strip()
        pri_remark = (request.POST.get('pri_remark') or '').strip()
        if priconf != 'Y':
            return render(request, 'seating_chart_inst/inst_seat_chart_nil_conf.html', {
                'error_message': 'Please check the checkbox to confirm nil seating chart correction.',
                'current_exam_label': current_exam_label,
                'user_info': user_info,
            })
        if not pri_remark:
            return render(request, 'seating_chart_inst/inst_seat_chart_nil_conf.html', {
                'error_message': 'Please enter remark.',
                'current_exam_label': current_exam_label,
                'user_info': user_info,
            })
        reg_code = get_region_inst(inst_code_int)
        region_code = str(reg_code)[-3:] if reg_code else ''
        insnil = f"""
            INSERT INTO {msbte_config.CORRECTION_TYPE}
            (en_no, inst_code, region_code, entry_on, entry_by, cand_conf, inst_conf, rbte_conf, remark)
            VALUES (%s, %s, %s, NOW(), %s, 'E', 'E', 'E', %s)
        """
        try:
            with conn.cursor() as cursor:
                cursor.execute(insnil, [inst_code_int, inst_code_int, region_code, inst_code_int, pri_remark])
            conn.commit()
        except Exception as e:
            logger.exception("Nil conf insert failed: %s", e)
            return render(request, 'seating_chart_inst/inst_seat_chart_nil_conf.html', {
                'error_message': 'Failed to save nil confirmation. Please try again.',
                'current_exam_label': current_exam_label,
                'user_info': user_info,
            })
        # After successful NIL confirmation, go back to the main correction reports
        # page with flag f=N, and ensure the institute code is carried forward.
        # If the form posted an explicit instid, prefer that; otherwise fall back
        # to the resolved inst_code_int.
        posted_instid = (request.POST.get('instid') or '').strip()
        instid_for_redirect = posted_instid or inst_code_int
        redirect_url = reverse('dashboard:seating_chart:seating_chart_inst:inst_seat_chart_rep')
        qs = '?f=N'
        if instid_for_redirect:
            qs += f'&instid={instid_for_redirect}'
        return redirect(redirect_url + qs)

    # GET: check eligibility and show form
    # PHP: if cand_conf='E' or inst_conf='E' -> nil already confirmed; else if chk_num>0 -> already applied
    chk_query = f"""
        SELECT cand_conf, inst_conf FROM {msbte_config.CORRECTION_TYPE}
        WHERE inst_code = %s
    """
    try:
        df_chk = pd.read_sql(chk_query, conn, params=[inst_code_int])
    except Exception as e:
        logger.exception("Nil conf check query failed: %s", e)
        df_chk = pd.DataFrame()

    if not df_chk.empty:
        for _, row in df_chk.iterrows():
            cand_conf = str(row.get('cand_conf') or '').strip().upper()
            inst_conf = str(row.get('inst_conf') or '').strip().upper()
            if cand_conf == 'E' or inst_conf == 'E':
                return render(request, 'seating_chart_inst/inst_seat_chart_nil_conf.html', {
                    'error_message': 'NIL Report Already Confirmed. Please go to your respective RBTE for Confirmation of NIL Report',
                    'current_exam_label': current_exam_label,
                    'user_info': user_info,
                })
        return render(request, 'seating_chart_inst/inst_seat_chart_nil_conf.html', {
            'error_message': 'Already Applied for Seating Chart Correction',
            'current_exam_label': current_exam_label,
            'user_info': user_info,
        })

    # Show nil confirmation form (include institute code so it can be posted forward)
    return render(request, 'seating_chart_inst/inst_seat_chart_nil_conf.html', {
        'current_exam_label': current_exam_label,
        'user_info': user_info,
        'success_f': request.GET.get('f', ''),
        'inst_code_int': inst_code_int,
        'inst_code': inst_code,
    })


@jwt_report_authorized(allowed_roles=['INSTITUTE', 'RBTE', 'ADMIN'])
def inst_seat_chart_rep(request):
    """
    Seating Chart Correction Reports landing page (PHP: inst_seat_chart_rep).
    Shows report links based on role and correction stats.
    """
    auth, error = get_auth_context(
        request,
        redirect_url='dashboard:seating_chart:seating_chart_home',
        require_institute=False,
    )
    if error:
        return error

    user_info, err = get_user_control_info(
        request,
        auth,
        allowed_roles=['INSTITUTE', 'RBTE', 'ADMIN'],
        require_institute_code=False,
        redirect_url='dashboard:seating_chart:seating_chart_home',
        error_message='You are not authorised.',
    )
    if err:
        return err

    user_role = (user_info.get('user_role') or auth.get('role') or '').upper()
    uid = user_info.get('uid')
    is_admin = user_info.get('is_admin', False)
    current_exam_label = getattr(msbte_config, 'ACA_NAME_EXAM_S', 'Summer 2026')

    # Capture any explicit instid passed in (e.g. after NIL confirmation under ADMIN/RBTE)
    # so we can propagate it to the NIL report URL.
    instid_param = (request.GET.get('instid') or request.POST.get('instid') or '').strip()
    instid_for_nil = None

    # Allow ADMIN (is_admin) even if user_role is empty; match other seating chart views
    if user_role not in ('INSTITUTE', 'RBTE', 'ADMIN') and not is_admin:
        return render(request, 'seating_chart_inst/inst_seat_chart_rep.html', {
            'error_message': 'Invalid User',
            'current_exam_label': current_exam_label,
            'user_info': user_info,
            'stats': None,
        })

    # Treat admin as ADMIN role for WHERE clause
    if is_admin and user_role not in ('INSTITUTE', 'RBTE'):
        user_role = 'ADMIN'

    conn = get_db_connection()

    # Build WHERE clause by role (PHP pattern)
    where_parts = ["course_code NOT IN ('CC','EC','MC')"]
    params = []
    if user_role == 'INSTITUTE':
        is_jwt = user_info.get('is_jwt', False)
        # For JWT institute users, ALWAYS use institute_code from token/user_info (not uid)
        if is_jwt and (user_info.get('inst_code') or auth.get('institute_code')):
            inst_id = str(user_info.get('inst_code') or auth.get('institute_code')).strip()
        elif uid and not is_jwt:
            uid_str = str(uid).strip()
            inst_id = uid_str[-5:] if len(uid_str) == 7 else (uid_str[-4:] if len(uid_str) >= 4 else uid_str)
        else:
            inst_id = user_info.get('inst_code') or auth.get('institute_code')
        if not inst_id:
            return render(request, 'seating_chart_inst/inst_seat_chart_rep.html', {
                'error_message': 'Institute code is required.',
                'current_exam_label': current_exam_label,
                'user_info': user_info,
                'stats': None,
            })
        try:
            inst_id_int = int(str(inst_id).lstrip('0'))
        except (ValueError, TypeError):
            inst_id_int = inst_id
        where_parts.append("inst_code = %s")
        params.append(inst_id_int)
        instid_for_nil = inst_id_int
    elif user_role == 'RBTE':
        if uid:
            reg_id = str(uid).strip()[-3:]
        else:
            reg_id = ''
        if not reg_id:
            return render(request, 'seating_chart_inst/inst_seat_chart_rep.html', {
                'error_message': 'Region code could not be determined.',
                'current_exam_label': current_exam_label,
                'user_info': user_info,
                'stats': None,
            })
        where_parts.append("region_code = %s")
        params.append(reg_id)
        # For RBTE, if a specific institute was carried in the query string (e.g. after
        # NIL confirmation), keep it for NIL report navigation.
        if instid_param:
            try:
                instid_for_nil = int(str(instid_param).lstrip('0'))
            except (ValueError, TypeError):
                instid_for_nil = instid_param
    else:
        # ADMIN: no extra filter; if an instid was carried in, keep it for NIL report
        # navigation so ADMIN also sees the same institute's NIL report.
        if instid_param:
            try:
                instid_for_nil = int(str(instid_param).lstrip('0'))
            except (ValueError, TypeError):
                instid_for_nil = instid_param

    where_sql = ' AND '.join(where_parts)
    selpricorr = f"""
        SELECT
            SUM(IF(cand_conf != 'Y' OR cand_conf IS NULL, 1, 0)) AS cand_not_conf,
            SUM(IF(cand_conf = 'Y', 1, 0)) AS cand_conf,
            SUM(IF(inst_conf = 'Y', 1, 0)) AS inst_conf,
            SUM(IF(rbte_conf = 'Y', 1, 0)) AS rbte_conf,
            MAX(cand_conf) AS candidate_conf,
            MAX(inst_conf) AS institute_conf
        FROM {msbte_config.CORRECTION_TYPE}
        WHERE {where_sql}
    """
    try:
        df = pd.read_sql(selpricorr, conn, params=params)
    except Exception as e:
        logger.exception("Seating chart rep stats query failed: %s", e)
        df = pd.DataFrame()

    stats = {}
    if not df.empty and df.iloc[0] is not None:
        row = df.iloc[0].to_dict()
        for k, v in row.items():
            if v is not None and isinstance(v, (int, float)):
                try:
                    stats[k] = int(float(v))
                except (ValueError, TypeError):
                    stats[k] = v
            else:
                stats[k] = v if v is not None else 0
    else:
        stats = {
            'cand_not_conf': 0, 'cand_conf': 0, 'inst_conf': 0, 'rbte_conf': 0,
            'candidate_conf': None, 'institute_conf': None,
        }

    # Separate NIL flag: if institute has submitted a NIL confirmation
    # (cand_conf='E' or inst_conf='E' on any row with entry_by/inst_code = inst_id),
    # we will show only the NIL Report link.
    has_nil = False
    if user_role == 'INSTITUTE':
        try:
            inst_for_nil = inst_id_int if 'inst_id_int' in locals() else None
        except NameError:
            inst_for_nil = None
        if inst_for_nil is not None:
            nil_check_query = f"""
                SELECT 1
                FROM {msbte_config.CORRECTION_TYPE}
                WHERE (entry_by = %s OR inst_code = %s)
                  AND (cand_conf = 'E' OR inst_conf = 'E')
                LIMIT 1
            """
            try:
                df_nil = pd.read_sql(nil_check_query, conn, params=[inst_for_nil, inst_for_nil])
            except Exception as e:
                logger.exception("NIL check in inst_seat_chart_rep failed: %s", e)
                df_nil = pd.DataFrame()
            if not df_nil.empty:
                has_nil = True

    sflg = (request.GET.get('f') or request.POST.get('f') or '').strip().upper()

    return render(request, 'seating_chart_inst/inst_seat_chart_rep.html', {
        'current_exam_label': current_exam_label,
        'user_info': user_info,
        'stats': stats,
        'success_flg': sflg,
        'has_nil': has_nil,
        'instid_for_nil': instid_for_nil,
    })

@jwt_report_authorized(allowed_roles=['INSTITUTE', 'RBTE', 'ADMIN'])
def inst_seat_chart_rep_nil(request):
    """
    Seating Chart Correction NIL Report (PHP: inst_seat_chart_rep_nil).
    Role handling should mirror seatingchart_arrangement_ec:
    - INSTITUTE: own institute only (from JWT / uid / user_info)
    - ADMIN/RBTE: optional instid; if missing, show institute selection form
    Shows NIL confirmation details when cand_conf='E' or inst_conf='E'.
    """
    auth, error = get_auth_context(
        request,
        redirect_url='dashboard:seating_chart:seating_chart_home',
        require_institute=False,
    )
    if error:
        return error

    user_info, err = get_user_control_info(
        request,
        auth,
        allowed_roles=['INSTITUTE', 'RBTE', 'ADMIN'],
        require_institute_code=False,
        redirect_url='dashboard:seating_chart:seating_chart_home',
        error_message='You are not authorised.',
    )
    if err:
        return err

    current_exam_label = getattr(msbte_config, 'ACA_NAME_EXAM_S', 'Summer 2026')
    user_role = (user_info.get('user_role') or auth.get('role') or '').upper()
    uid = user_info.get('uid')
    is_admin = user_info.get('is_admin', False)

    # ADMIN/RBTE without instid: show institute selection (same pattern as seatingchart_arrangement_ec)
    if is_admin or user_role == 'RBTE':
        jwt_inst_code = auth.get('institute_code') if auth.get('is_jwt') else None
        instid_param = (request.GET.get('instid') or request.POST.get('instid') or '').strip()

        if not jwt_inst_code and not instid_param:
            conn = get_db_connection()
            exam_centers_query = f"""
                SELECT DISTINCT r.exam_center, i.inst_name
                FROM {msbte_config.W25_RAC_DC_DETAILS} r
                INNER JOIN {msbte_config.INSTITUTES} i ON i.inst_id = r.exam_center
                ORDER BY r.exam_center
            """
            try:
                df_ec = pd.read_sql(exam_centers_query, conn)
                exam_centers = [
                    {
                        'inst_id': int(r['exam_center']),
                        'inst_name': r['inst_name'] if pd.notna(r['inst_name']) else f"Institute {int(r['exam_center'])}",
                    }
                    for _, r in df_ec.iterrows()
                ]
            except Exception as e:
                logger.exception("Exam centers query failed (NIL Report): %s", e)
                exam_centers = []
            return render(request, 'seating_chart_inst/inst_seat_chart_rep_nil.html', {
                'exam_centers': exam_centers,
                'current_exam_label': current_exam_label,
                'user_info': user_info,
                'form_action': reverse('dashboard:seating_chart:seating_chart_inst:inst_seat_chart_rep_nil'),
            })

    # Resolve institute code
    inst_code = None
    inst_code_int = None

    if not is_admin and user_role == 'INSTITUTE':
        # INSTITUTE: prefer JWT institute_code, then UID-derived, then stored inst_code
        if auth.get('is_jwt') and (user_info.get('inst_code') or auth.get('institute_code')):
            inst_code = str(user_info.get('inst_code') or auth.get('institute_code')).strip()
        elif uid and not auth.get('is_jwt'):
            uid_str = str(uid).strip()
            if len(uid_str) == 7:
                inst_code = uid_str[-5:]
            elif len(uid_str) >= 4:
                inst_code = uid_str[-4:]
            else:
                inst_code = uid_str
        else:
            inst_code = user_info.get('inst_code') or auth.get('institute_code')
    else:
        # ADMIN/RBTE with explicit instid or JWT/user_info inst_code
        instid_get = (request.GET.get('instid') or request.POST.get('instid') or '').strip()
        if instid_get:
            inst_code = str(instid_get).lstrip('0') or instid_get
        elif auth.get('is_jwt') and (user_info.get('inst_code') or auth.get('institute_code')):
            inst_code = str(user_info.get('inst_code') or auth.get('institute_code')).strip()
        else:
            inst_code = user_info.get('inst_code') or auth.get('institute_code')

    if not inst_code:
        return render(request, 'seating_chart_inst/inst_seat_chart_rep_nil.html', {
            'current_exam_label': current_exam_label,
            'error_message': 'Institute code is required for NIL Report.',
        })

    try:
        inst_code_int = int(str(inst_code).lstrip('0'))
    except (ValueError, TypeError):
        inst_code_int = inst_code

    conn = get_db_connection()
    tbl_ct = msbte_config.CORRECTION_TYPE

    # PHP: SELECT * FROM W18_CORRECTION_TYPE WHERE entry_by = ? AND (cand_conf='E' || inst_conf='E')
    # For safety with legacy data, also allow match on inst_code.
    query = f"""
        SELECT *
        FROM {tbl_ct}
        WHERE (entry_by = %s OR inst_code = %s)
          AND (cand_conf = 'E' OR inst_conf = 'E')
        LIMIT 1
    """
    try:
        df = pd.read_sql(query, conn, params=[inst_code_int, inst_code_int])
    except Exception as e:
        logger.exception("NIL report query failed: %s", e)
        return render(request, 'seating_chart_inst/inst_seat_chart_rep_nil.html', {
            'current_exam_label': current_exam_label,
            'error_message': 'Report query failed for NIL Report.',
        })

    if df.empty:
        return render(request, 'seating_chart_inst/inst_seat_chart_rep_nil.html', {
            'current_exam_label': current_exam_label,
            'error_message': 'Record Not Found for NIL Report.',
        })

    row = df.iloc[0].to_dict()
    conf_by = row.get('entry_by')
    conf_on = row.get('entry_on')
    raw_rbt_conf = row.get('rbte_conf')
    if raw_rbt_conf is None:
        rbte_conf = ''
    else:
        # Safely normalise to upper-case string without assuming a .strip() method exists
        rbte_conf = str(raw_rbt_conf).strip()
    rbte_conf_by = row.get('rbte_conf_by')
    rbte_conf_on = row.get('rbte_conf_on')
    pri_remark = row.get('remark') or ''
    raw_region = row.get('region_code')
    if raw_region is None:
        region_code = ''
    else:
        region_code = str(raw_region).strip()

    # Region name – prefer REGION_MAP (gives Mumbai/Pune/Nagpur names), then helper
    region_code_short = region_code.lstrip('0') or region_code
    region_name = REGION_MAP.get(
        region_code_short,
        get_region_name(region_code) if region_code else '',
    ) or '-'

    # Institute display (code-name)
    inst_name = ''
    try:
        if isinstance(inst_code_int, int):
            inst_name = get_inst_name(inst_code_int) or ''
        elif str(inst_code).isdigit():
            inst_name = get_inst_name(int(inst_code)) or ''
    except Exception:
        inst_name = ''
    inst_name = inst_name or f'Institute {inst_code}'

    try:
        inst_code_display = str(int(str(inst_code).lstrip('0'))).zfill(5)
    except (ValueError, TypeError):
        inst_code_display = str(inst_code)

    # Confirmation by / on strings (match PHP behavior)
    if conf_by:
        try:
            conf_by_code = str(int(str(conf_by).lstrip('0'))).zfill(5)
        except (ValueError, TypeError):
            conf_by_code = str(conf_by)
        conf_by_name = get_inst_name(int(conf_by)) if str(conf_by).isdigit() else ''
        conf_by_display = f"{conf_by_code}-{conf_by_name or inst_name}"
    else:
        conf_by_display = "Not Confirmed by Institute."

    if conf_on and str(conf_on).strip() not in ('', '0'):
        try:
            # Let pandas/datetime handle if it's a timestamp; fall back to raw string
            conf_on_display = pd.to_datetime(conf_on).strftime('%d/%m/%Y %H:%M')  # similar to changedatetimeformat
        except Exception:
            conf_on_display = str(conf_on)
    else:
        conf_on_display = "Not Confirmed by Institute."

    # RBTE confirmation text
    if rbte_conf != 'Y':
        rbte_conf_display = "RBTE Confirmation Pending."
    else:
        if rbte_conf_on and str(rbte_conf_on).strip() not in ('', '0'):
            try:
                rbte_conf_on_display = pd.to_datetime(rbte_conf_on).strftime('%d/%m/%Y %H:%M')
            except Exception:
                rbte_conf_on_display = str(rbte_conf_on)
        else:
            rbte_conf_on_display = ''
        rbte_conf_display = f"Confirm By, RBTE {region_name}"
        if rbte_conf_on_display:
            rbte_conf_display += f"<br><strong>Confirm On:- </strong>{rbte_conf_on_display}"

    from datetime import datetime
    printed_date = datetime.now().strftime('%d/%m/%Y')
    printed_by = ''
    if uid:
        uid_str = str(uid).strip()
        printed_by = uid_str[-4:].zfill(4) if len(uid_str) >= 4 else uid_str

    # URL without query string (rough equivalent of geturlprint())
    try:
        full_url = request.build_absolute_uri()
        print_url = full_url.split('?', 1)[0]
    except Exception:
        print_url = ''

    context = {
        'current_exam_label': current_exam_label,
        'region': region_name,
        'inst_code': inst_code_display,
        'inst_name': inst_name,
        'conf_by_display': conf_by_display,
        'conf_on_display': conf_on_display,
        'pri_remark': pri_remark,
        'rbte_conf_display': rbte_conf_display,
        'printed_date': printed_date,
        'printed_by': printed_by,
        'print_url': print_url,
    }

    return render(request, 'seating_chart_inst/inst_seat_chart_rep_nil.html', context)


# Mapping correction_type -> SEATING_CHART_REMARK_OPTIONS key for remark lookup (PHP: get_remark for forms)
REMARK_KEY_BY_CORRECTION_TYPE = {
    2: 'course_remark',
    4: 'master_remark',
    5: 'instcode_remark',
    6: 'status_remark',
    7: 'appear_remark',
    8: 'lastexam_remark',
    9: 'lastseat_remark',
    10: 'addsub_remark',
    11: 'deleted_remark',
    12: 'update_elective_remark',
}


@lru_cache(maxsize=512)
def _get_remark_label_from_master(correction_type, remark_id):
    """
    Fetch remark label from REMARK_MASTER table (PHP: get_remark()).
    Uses (correction_id, remark_id) as key.
    """
    try:
        if correction_type is None:
            return ""
        rid = str(remark_id).strip()
        if not rid or rid in ("0", "00"):
            return ""

        try:
            corr_id = int(correction_type)
        except (ValueError, TypeError):
            corr_id = correction_type

        conn = get_db_connection()
        tbl = msbte_config.REMARK_MASTER
        query = f"SELECT remark FROM {tbl} WHERE correction_id = %s AND remark_id = %s LIMIT 1"
        df = pd.read_sql(query, conn, params=[corr_id, rid])
        if not df.empty and pd.notna(df["remark"].iloc[0]):
            return str(df["remark"].iloc[0])
    except Exception as e:
        logger.exception("Failed to fetch remark label from REMARK_MASTER: %s", e)
    return ""


def _get_remark_label(correction_type, remark_id):
    """Return remark label for (correction_type, remark_id) using REMARK_MASTER (PHP: get_remark())."""
    if not remark_id or str(remark_id).strip() in ("", "0", "00"):
        return "NA"

    # 1) Primary source: REMARK_MASTER table (same as legacy PHP)
    label = _get_remark_label_from_master(correction_type, remark_id)
    if label:
        return label

    # 2) Fallback: static options used for forms (SEATING_CHART_REMARK_OPTIONS)
    try:
        key = REMARK_KEY_BY_CORRECTION_TYPE.get(int(correction_type) if correction_type else 0)
    except (ValueError, TypeError):
        key = None
    if not key or key not in SEATING_CHART_REMARK_OPTIONS:
        return "NA"

    opts = SEATING_CHART_REMARK_OPTIONS[key]
    rid = str(remark_id).strip()
    for val, opt_label in opts:
        if str(val) == rid:
            return opt_label

    return "NA"


@jwt_report_authorized(allowed_roles=['INSTITUTE', 'RBTE', 'ADMIN'])
def inst_seat_chart_rep_next(request):
    """
    Correction report by type (PHP: inst_seat_chart_rep_next).
    d=Y: Corrected Candidates (cand_conf != 'Y')
    d=N: No Correction Candidates (cand_conf != 'Y')
    d=C: Candidates Confirmed (cand_conf = 'Y')
    d=IC: Institute Final Confirmed (inst_conf = 'Y')
    d=R: RBTE Confirmed (rbte_conf = 'Y')
    """
    auth, error = get_auth_context(
        request, redirect_url='dashboard:seating_chart:seating_chart_home', require_institute=False
    )
    if error:
        return error
    user_info, err = get_user_control_info(
        request, auth, allowed_roles=['INSTITUTE', 'RBTE', 'ADMIN'],
        require_institute_code=False, redirect_url='dashboard:seating_chart:seating_chart_home',
        error_message='You are not authorised.',
    )
    if err:
        return err

    user_role = (user_info.get('user_role') or auth.get('role') or '').upper()
    uid = user_info.get('uid')
    is_admin = user_info.get('is_admin', False)
    d_param = (request.GET.get('d') or '').strip().upper()
    current_exam_label = getattr(msbte_config, 'ACA_NAME_EXAM_S', 'Summer 2026')
    conn = get_db_connection()

    # canddispstr (PHP)
    if d_param == 'C':
        canddispstr = "AND ct.cand_conf = 'Y'"
    elif d_param == 'IC':
        canddispstr = "AND ct.inst_conf = 'Y'"
    elif d_param == 'N':
        canddispstr = "AND (ct.cand_conf != 'Y' OR ct.cand_conf IS NULL)"
    elif d_param == 'R':
        canddispstr = "AND ct.rbte_conf = 'Y'"
    elif d_param == 'Y':
        canddispstr = ""  # Corrected Candidates = all (no filter)
    else:
        canddispstr = ""

    # str_inst_code by role (PHP: INSTITUTE uses inst_code, RBTE uses region last 1 char, ADMIN empty).
    # For JWT institute logins, ALWAYS use institute_code from token/user_info (not uid),
    # same pattern as inst_seat_chart_rep so that summary and detail use identical institute filters.
    str_inst_code = ""
    params = []
    inst_code_display = None
    region_name = None

    if user_role == 'INSTITUTE' or (not is_admin and user_role != 'RBTE' and user_role != 'ADMIN'):
        is_jwt = user_info.get('is_jwt', False)
        # INSTITUTE: prefer JWT institute_code, then UID-derived, then stored inst_code
        if is_jwt and (user_info.get('inst_code') or auth.get('institute_code')):
            inst_code = str(user_info.get('inst_code') or auth.get('institute_code')).strip()
        elif uid and not is_jwt:
            uid_str = str(uid).strip()
            inst_code = uid_str[-5:] if len(uid_str) == 7 else (uid_str[-4:] if len(uid_str) >= 4 else uid_str)
        else:
            inst_code = user_info.get('inst_code') or auth.get('institute_code')
        if inst_code:
            try:
                inst_code_int = int(str(inst_code).lstrip('0'))
            except (ValueError, TypeError):
                inst_code_int = inst_code
            str_inst_code = " AND ct.inst_code = %s"
            params.append(inst_code_int)
            inst_code_display = str(inst_code).lstrip('0')
            if inst_code_display:
                try:
                    inst_code_display = str(int(inst_code_display)).zfill(4)
                except (ValueError, TypeError):
                    pass
            reg_code = get_region_inst(inst_code_int) if inst_code_int else ''
            region_name = get_region_name(reg_code) if reg_code else '-'
            if (not region_name or region_name == '-') and reg_code:
                region_name = REGION_MAP.get(str(reg_code).strip(), '-')
            if not region_name:
                region_name = '-'
            inst_name = get_inst_name(inst_code_int) or get_city_name(inst_code_int) if isinstance(inst_code_int, int) else (get_inst_name(int(inst_code)) or get_city_name(int(inst_code)) if str(inst_code).isdigit() else '')
        else:
            inst_name = ''
    elif user_role == 'RBTE' and uid:
        reg_code = str(uid).strip()[-1]  # PHP: SUBSTR($uid,-1)
        str_inst_code = " AND ct.region_code = %s"
        params.append(reg_code)
        rbte_region_code = user_info.get('rbte_code') or uid
        region_name = get_region_name(rbte_region_code) or REGION_MAP.get(reg_code, '-') or '-'
        inst_name = ''
    elif is_admin or user_role == 'ADMIN':
        region_name = '-'
        inst_name = ''

    # Exact same query as PHP: FROM ct, sc WHERE ... GROUP BY ... ORDER BY ...
    query = f"""
        SELECT ct.en_no, sc.name, sc.last_exam_no, sc.last_exam_seatno, sc.status, sc.appear_code,
               ct.add_del, ct.course_code, ct.year_code, ct.master_code, ct.sr_no, ct.correction_type,
               ct.inst_code, ct.region_code, ct.remark_id, ct.seat_no, ct.before_corr, ct.after_corr, ct.remark
        FROM {msbte_config.CORRECTION_TYPE} ct, {msbte_config.SEATING_CHART} sc
        WHERE ct.en_no = sc.enroll_no
          AND sc.block NOT IN ('Y','D')
          AND ct.course_code = sc.course_code
          AND ct.year_code = sc.year_code
          AND ct.master_code = sc.master_code
          AND ct.inst_code = sc.inst_code
          {canddispstr}
          {str_inst_code}
        GROUP BY ct.en_no, ct.course_code, ct.year_code, ct.master_code, ct.correction_type, ct.add_del
        ORDER BY ct.en_no, ct.course_code, ct.year_code, ct.master_code, ct.sr_no
    """
    try:
        df = pd.read_sql(query, conn, params=params)
    except Exception as e:
        logger.exception("inst_seat_chart_rep_next query failed: %s", e)
        return render(request, 'seating_chart_inst/inst_seat_chart_rep_next.html', {
            'current_exam_label': current_exam_label,
            'user_info': user_info,
            'd_param': d_param,
            'report_rows': [],
            'no_data': True,
            'error_message': 'Report query failed.',
        })

    if df.empty:
        return render(request, 'seating_chart_inst/inst_seat_chart_rep_next.html', {
            'current_exam_label': current_exam_label,
            'user_info': user_info,
            'd_param': d_param,
            'report_rows': [],
            'no_data': True,
            'region_name': region_name or '-',
            'inst_code': inst_code_display or '',
            'inst_name': inst_name or '',
        })

    # Resolve region from first row when still missing (e.g. institute has no reg_code in DB)
    if (region_name is None or region_name == '-' or not str(region_name).strip()) and len(df) > 0:
        raw_region = df.iloc[0].get('region_code')
        if raw_region is not None and str(raw_region).strip() != '':
            rcode = str(raw_region).strip()
            region_name = get_region_name(raw_region) or REGION_MAP.get(rcode, '') or (REGION_MAP.get(rcode[-1], '') if rcode else '')
        if not region_name:
            region_name = '-'

    # Exact same as PHP: "select * from W18_CORRECTION_TYPE where en_no = '$en_no_arr' and add_del='$add_del'", then $array_sr_no[] = $arrs['sr_no']; implode
    report_rows = []
    for idx, r in df.iterrows():
        en_no = r.get('en_no')
        add_del = r.get('add_del')
        # PHP: add_del='$add_del' so NULL becomes '' in string interpolation
        add_del_param = '' if (add_del is None or (isinstance(add_del, float) and pd.isna(add_del))) else str(add_del)
        sr_q = f"""SELECT sr_no FROM {msbte_config.CORRECTION_TYPE} WHERE en_no = %s AND add_del = %s ORDER BY sr_no"""
        try:
            df_sr = pd.read_sql(sr_q, conn, params=[en_no, add_del_param])
            sr_list = [str(int(x)) if isinstance(x, float) and x == int(x) else str(x) for x in df_sr['sr_no'].tolist() if pd.notna(x)]
            sr_str = ','.join(sr_list) if sr_list else ''
            if not sr_str or sr_str.strip() == '' or sr_str == '0':
                sr_str = 'NA'
        except Exception:
            sr_str = str(r.get('sr_no') or '') or 'NA'

        cor_type = int(r.get('correction_type') or 0)
        before_corr = r.get('before_corr')
        after_corr = r.get('after_corr')
        if cor_type == 8 and before_corr and after_corr:
            before_display = before_corr  # get_exam_s_w equivalent - use as-is
            after_display = after_corr
        else:
            before_display = before_corr or ''
            after_display = after_corr or ''

        if cor_type == 10 and add_del:
            add_del_val = int(add_del) if str(add_del).isdigit() else 0
            if add_del_val == 1:
                add_del_display = 'Added'
            elif add_del_val == 2:
                add_del_display = 'Deleted'
            else:
                add_del_display = 'NA'
        else:
            add_del_display = 'NA'

        if cor_type == 10 and add_del:
            # Aggregate all correction rows for this candidate/add_del to capture
            # multiple added/deleted subjects (e.g. sr_no = 4,16).
            add_del_str = str(add_del).strip()
            before_all = []
            after_all = []
            try:
                details_q = f"""
                    SELECT before_corr, after_corr
                    FROM {msbte_config.CORRECTION_TYPE}
                    WHERE en_no = %s
                      AND course_code = %s
                      AND year_code = %s
                      AND master_code = %s
                      AND correction_type = 10
                      AND add_del = %s
                    ORDER BY sr_no
                """
                df_details = pd.read_sql(
                    details_q,
                    conn,
                    params=[
                        en_no,
                        r.get('course_code'),
                        r.get('year_code'),
                        r.get('master_code'),
                        add_del_str,
                    ],
                    
                )
                for _, det in df_details.iterrows():
                    b = str(det.get('before_corr') or '')
                    a = str(det.get('after_corr') or '')
                    for s in [x.strip() for x in b.split(',') if x and x.strip()]:
                        if s not in before_all:
                            before_all.append(s)
                    for s in [x.strip() for x in a.split(',') if x and x.strip()]:
                        if s not in after_all:
                            after_all.append(s)
            except Exception:
                # Fallback to the current row values if detail query fails
                before_all = [s.strip() for s in str(before_corr or '').split(',') if s.strip()]
                after_all = [s.strip() for s in str(after_corr or '').split(',') if s.strip()]

            if add_del_str == '1':
                # Added: show only newly added subjects (present after but not before)
                delta_subjects = [s for s in after_all if s and s not in before_all]
            elif add_del_str == '2':
                # Deleted: show subjects stored in after_corr
                delta_subjects = after_all
            else:
                delta_subjects = []

            if delta_subjects:
                after_display = ','.join(delta_subjects)

        last_seat = r.get('last_exam_seatno')
        if last_seat is None or str(last_seat) in ('', '0', '000000'):
            last_seat_display = 'NA'
        else:
            last_seat_display = str(last_seat)

        last_exam = r.get('last_exam_no')
        if cor_type == 8 and before_corr:
            last_exam_display = before_corr  # Last Exam correction: show before value
        else:
            last_exam_display = last_exam if last_exam else 'NA'

        remark_label = _get_remark_label(cor_type, r.get('remark_id'))
        other_remark = (r.get('remark') or '').strip() or 'NA'
        deleted_display = '405' if cor_type == 11 else 'NA'

        inst_c = r.get('inst_code')
        trimmed_code = str(inst_c).lstrip('0') if inst_c else ''

        report_rows.append({
            'en_no': en_no,
            'name': r.get('name') or '',
            'course_code': r.get('course_code') or '',
            'year_code': r.get('year_code') or '',
            'master_code': r.get('master_code') or '',
            'inst_code': trimmed_code,
            'status': r.get('status') or '',
            'appear_code': r.get('appear_code') or '',
            'last_exam': last_exam_display,
            'last_seat': last_seat_display,
            'sr_no_str': sr_str,
            'add_del_display': add_del_display,
            'before_corr': before_display,
            'after_corr': after_display,
            'correction_type': cor_type,
            'remark_label': remark_label,
            'other_remark': other_remark,
            'deleted_display': deleted_display,
        })

    # Merge multiple "Deleted" (type 10, add_del=2) rows for same candidate into one row with all deleted subjects
    merged_rows = []
    pending_deleted = []  # list of rows for current candidate's Deleted group

    def row_key(row):
        return (row['en_no'], row['course_code'], row['year_code'], row['master_code'])

    def flush_pending():
        nonlocal pending_deleted
        if not pending_deleted:
            return
        first = pending_deleted[0].copy()
        first['after_corr'] = ','.join(
            (r.get('after_corr') or '').strip() for r in pending_deleted if (r.get('after_corr') or '').strip()
        ).strip(',').rstrip(',')
        # Sr No: combine all sr_no from merged rows (PHP: implode all sr_no for en_no+add_del)
        all_sr = []
        for r in pending_deleted:
            s = (r.get('sr_no_str') or '').strip()
            if s:
                for part in s.replace(' ', '').split(','):
                    if part and part not in all_sr:
                        all_sr.append(part)
        combined_sr = ','.join(all_sr) if all_sr else (first.get('sr_no_str') or '')
        # PHP: if($value1==0) echo "NA"; else echo $value1;
        first['sr_no_str'] = 'NA' if (not combined_sr or combined_sr.strip() == '' or combined_sr == '0') else combined_sr
        merged_rows.append(first)
        pending_deleted = []

    for row in report_rows:
        is_deleted = row['correction_type'] == 10 and str(row.get('add_del_display')) == 'Deleted'
        if is_deleted:
            if pending_deleted and row_key(row) != row_key(pending_deleted[0]):
                flush_pending()
            pending_deleted.append(row)
        else:
            flush_pending()
            merged_rows.append(row)
    flush_pending()
    report_rows = merged_rows

    # Resolve inst_name from first row when still empty (any role)
    if (not inst_name or not str(inst_name).strip()) and report_rows:
        try:
            ic = report_rows[0].get('inst_code')
            if ic is not None and str(ic).strip() != '':
                ic_int = int(str(ic).lstrip('0') or 0)
                inst_name = get_inst_name(ic_int) or get_city_name(ic_int) or ''
        except (ValueError, TypeError):
            pass

    # Institute code for header: 4-digit display (same as rbte_seat_chart_rep_next)
    inst_code_header = inst_code_display
    if not inst_code_header and report_rows:
        raw = report_rows[0].get('inst_code')
        if raw is not None and str(raw).strip() != '':
            try:
                inst_code_header = str(int(str(raw).lstrip('0') or 0)).zfill(4)
            except (ValueError, TypeError):
                inst_code_header = str(raw)
    inst_code_header = inst_code_header or ''

    return render(request, 'seating_chart_inst/inst_seat_chart_rep_next.html', {
        'current_exam_label': current_exam_label,
        'user_info': user_info,
        'd_param': d_param,
        'report_rows': report_rows,
        'no_data': False,
        'region_name': region_name or '-',
        'inst_code': inst_code_header,
        'inst_name': inst_name or '',
        'user_role': user_role,
    })

@jwt_report_authorized(allowed_roles=['INSTITUTE', 'RBTE', 'ADMIN'])
def seatingchart_arrangement_ec(request):
    """
    Seating Arrangement Statistics of Exam Centers (paper-code-wise count).
    PHP equivalent: exam_form_s with sub=seat_chart_ec.
    Role handling (stat_inst pattern):
    - INSTITUTE: own center only; inst_code from JWT or session uid
    - ADMIN/RBTE: optional instid; if missing, show institute selection form
    """
    auth, error = get_auth_context(
        request,
        redirect_url='dashboard:seating_chart:seating_chart_home',
        require_institute=False,
    )
    if error:
        return error

    user_info, err = get_user_control_info(
        request, auth,
        allowed_roles=['INSTITUTE', 'RBTE', 'ADMIN'],
        require_institute_code=False,
        redirect_url='dashboard:seating_chart:seating_chart_home',
        error_message='You are not authorised to view this report',
    )
    if err:
        return err

    is_admin = user_info.get('is_admin', False)
    user_role = (user_info.get('user_role') or auth.get('role') or '').upper()
    uid = user_info.get('uid')
    current_exam_label = getattr(msbte_config, 'ACA_NAME_EXAM_S', 'Summer 2026')

    # ADMIN/RBTE without instid: show institute selection (stat_inst pattern)
    if is_admin or user_role == 'RBTE':
        jwt_inst_code = auth.get('institute_code') if auth.get('is_jwt') else None
        instid_param = (request.GET.get('instid') or request.POST.get('instid') or '').strip()

        if not jwt_inst_code and not instid_param:
            conn = get_db_connection()
            tbl = getattr(msbte_config, 'S19_INPUT_EXAM_MARKS_TH', None)
            if not tbl:
                return render(request, 'seating_chart_inst/seatingchart_arrangement_ec.html', {
                    'error_message': 'Report configuration not available.',
                    'current_exam_label': current_exam_label,
                    'user_info': user_info,
                    'exam_centers': [],
                    'paper_rows': [],
                })
            # Exam centers from RAC_DC_DETAILS (like stat_inst)
            exam_centers_query = f"""
                SELECT DISTINCT r.exam_center, i.inst_name
                FROM {msbte_config.W25_RAC_DC_DETAILS} r
                INNER JOIN {msbte_config.INSTITUTES} i ON i.inst_id = r.exam_center
                ORDER BY r.exam_center
            """
            try:
                df_ec = pd.read_sql(exam_centers_query, conn)
                exam_centers = [
                    {
                        'inst_id': int(r['exam_center']),
                        'inst_name': r['inst_name'] if pd.notna(r['inst_name']) else f"Institute {int(r['exam_center'])}",
                    }
                    for _, r in df_ec.iterrows()
                ]
            except Exception as e:
                logger.exception("Exam centers query failed: %s", e)
                exam_centers = []
            return render(request, 'seating_chart_inst/seatingchart_arrangement_ec.html', {
                'exam_centers': exam_centers,
                'current_exam_label': current_exam_label,
                'user_info': user_info,
                'form_action': reverse('dashboard:seating_chart:seating_chart_inst:seatingchart_arrangement_ec'),
                'paper_rows': [],
            })

    # Resolve inst_code (PHP pattern: INSTITUTE = substr(uid,-4,4); else = instid from REQUEST)
    inst_code = None
    uname_int = None  # center_code for query (PHP: $uname)
    instid_param = (request.GET.get('instid') or request.POST.get('instid') or '').strip()

    logger.info(
        "seatingchart_arrangement_ec role=%s is_admin=%s req_instid=%s jwt_inst=%s user_inst=%s",
        user_role,
        is_admin,
        instid_param,
        auth.get('institute_code') if auth.get('is_jwt') else None,
        user_info.get('inst_code'),
    )

    if not is_admin and user_role == 'INSTITUTE':
        # INSTITUTE: PHP $inst_code = formatfourdigit1(substr($uid,-4,4))
        if auth.get('is_jwt'):
            inst_code = auth.get('institute_code')
            if inst_code:
                try:
                    uname_int = int(str(inst_code).lstrip('0'))
                except (ValueError, TypeError):
                    return render(request, 'seating_chart_inst/seatingchart_arrangement_ec.html', {
                        'error_message': 'You are not authorised to view this report.',
                        'current_exam_label': current_exam_label,
                        'user_info': user_info,
                        'paper_rows': [],
                    })
            else:
                return render(request, 'seating_chart_inst/seatingchart_arrangement_ec.html', {
                    'error_message': 'Institute code is required.',
                    'current_exam_label': current_exam_label,
                    'user_info': user_info,
                    'paper_rows': [],
                })
        else:
            if uid:
                uid_str = str(uid).strip()
                inst_code = uid_str[-4:] if len(uid_str) >= 4 else uid_str  # PHP: substr($uid,-4,4)
                try:
                    uname_int = int(str(inst_code).lstrip('0'))
                except (ValueError, TypeError):
                    return render(request, 'seating_chart_inst/seatingchart_arrangement_ec.html', {
                        'error_message': 'You are not authorised to view this report.',
                        'current_exam_label': current_exam_label,
                        'user_info': user_info,
                        'paper_rows': [],
                    })
            else:
                return render(request, 'seating_chart_inst/seatingchart_arrangement_ec.html', {
                    'error_message': 'Institute code is required.',
                    'current_exam_label': current_exam_label,
                    'user_info': user_info,
                    'paper_rows': [],
                })
    elif user_role == 'RBTE':
        # RBTE: this report is opened from RBTE index with selected center code as instid.
        if instid_param:
            inst_code = str(instid_param).lstrip('0') or instid_param
        if not inst_code:
            return render(request, 'seating_chart_inst/seatingchart_arrangement_ec.html', {
                'error_message': 'Institute code is required.',
                'current_exam_label': current_exam_label,
                'user_info': user_info,
                'paper_rows': [],
            })
        try:
            uname_int = int(str(inst_code).lstrip('0'))
        except (ValueError, TypeError):
            return render(request, 'seating_chart_inst/seatingchart_arrangement_ec.html', {
                'error_message': 'Invalid institute code.',
                'current_exam_label': current_exam_label,
                'user_info': user_info,
                'paper_rows': [],
            })
    else:
        # ADMIN/RBTE: PHP $uname = formatfourdigit1(ltrim($_REQUEST['instid'],"0"))
        if instid_param:
            inst_code = str(instid_param).lstrip('0') or instid_param
        else:
            inst_code = auth.get('institute_code') if auth.get('is_jwt') else None
        if not inst_code:
            inst_code = user_info.get('inst_code')
        if inst_code:
            try:
                uname_int = int(str(inst_code).lstrip('0'))
            except (ValueError, TypeError):
                return render(request, 'seating_chart_inst/seatingchart_arrangement_ec.html', {
                    'error_message': 'Invalid institute code.',
                    'current_exam_label': current_exam_label,
                    'user_info': user_info,
                    'paper_rows': [],
                })

    if not uname_int:
        logger.warning(
            "seatingchart_arrangement_ec missing uname_int role=%s req_instid=%s resolved_inst=%s",
            user_role,
            instid_param,
            inst_code,
        )
        return render(request, 'seating_chart_inst/seatingchart_arrangement_ec.html', {
            'error_message': 'Institute code is required.',
            'current_exam_label': current_exam_label,
            'user_info': user_info,
            'paper_rows': [],
        })

    # uname_int = center_code for S19_INPUT_EXAM_MARKS_TH (PHP: center_code=$uname)
    tbl = getattr(msbte_config, 'S19_INPUT_EXAM_MARKS_TH', None)
    if not tbl:
        return render(request, 'seating_chart_inst/seatingchart_arrangement_ec.html', {
            'error_message': 'Report configuration not available.',
            'current_exam_label': current_exam_label,
            'user_info': user_info,
            'paper_rows': [],
        })

    conn = get_db_connection()
    # PHP exact: SELECT paper_code,count(*) FROM S19_INPUT_EXAM_MARKS_TH
    #   WHERE center_code='$uname' AND paper_code!='' AND special_code NOT IN('402','405')
    #   GROUP BY paper_code ORDER BY cast(paper_code as unsigned) asc
    uname_for_query = str(uname_int).zfill(4)  # PHP formatfourdigit1
    query_tpl = """
        SELECT paper_code, COUNT(*) AS cnt
        FROM {tbl}
        WHERE center_code = %s AND paper_code != '' AND paper_code IS NOT NULL
          AND (special_code IS NULL OR special_code NOT IN ('402','405'))
        GROUP BY paper_code
        ORDER BY CAST(paper_code AS UNSIGNED) ASC
    """
    df = pd.DataFrame()
    try:
        query = query_tpl.format(tbl=tbl)
        df = pd.read_sql(query, conn, params=[uname_int])
        if df.empty:
            df = pd.read_sql(query, conn, params=[uname_for_query])
        if df.empty:
            # Fallback: config uses md_ems_w25_th_nonaicte but data may be in md_ems_w25_th
            ems_th = getattr(msbte_config, 'EMS_DB_TH', '')
            if ems_th and '_nonaicte' in ems_th:
                tbl_alt = ems_th.replace('_nonaicte', '') + '.w25_th_input'
                q_alt = query_tpl.format(tbl=tbl_alt)
                try:
                    df = pd.read_sql(q_alt, conn, params=[uname_int])
                    if df.empty:
                        df = pd.read_sql(q_alt, conn, params=[uname_for_query])
                except Exception as ex:
                    logger.debug("Alt TH table %s: %s", tbl_alt, ex)
        if df.empty:
            query_pascal = f"""
                SELECT PaperCode AS paper_code, COUNT(*) AS cnt
                FROM {tbl}
                WHERE CenterCode = %s AND PaperCode != '' AND PaperCode IS NOT NULL
                  AND (SpecialCode IS NULL OR SpecialCode NOT IN ('402','405'))
                GROUP BY PaperCode
                ORDER BY CAST(PaperCode AS UNSIGNED) ASC
            """
            df = pd.read_sql(query_pascal, conn, params=[uname_int])
            if df.empty:
                df = pd.read_sql(query_pascal, conn, params=[uname_for_query])
    except Exception as e:
        logger.exception("Seating arrangement EC query failed: %s", e)
        ems_th = getattr(msbte_config, 'EMS_DB_TH', '')
        if ems_th and '_nonaicte' in ems_th:
            try:
                tbl_alt = ems_th.replace('_nonaicte', '') + '.w25_th_input'
                q_alt = query_tpl.format(tbl=tbl_alt)
                df = pd.read_sql(q_alt, conn, params=[uname_int])
                if df.empty:
                    df = pd.read_sql(q_alt, conn, params=[uname_for_query])
            except Exception as e2:
                logger.exception("Seating arrangement EC alt table failed: %s", e2)

    paper_rows = []
    tot_cnt = 0
    for _, r in df.iterrows():
        cnt = int(r['cnt']) if pd.notna(r['cnt']) else 0
        tot_cnt += cnt
        paper_rows.append({'paper_code': r.get('paper_code') or '', 'cnt': cnt})

    inst_name = get_inst_name(uname_int)
    inst_code_display = str(uname_int).zfill(4)  # PHP: formatfourdigit1 for display

    return render(request, 'seating_chart_inst/seatingchart_arrangement_ec.html', {
        'current_exam_label': current_exam_label,
        'user_info': user_info,
        'paper_rows': paper_rows,
        'tot_cnt': tot_cnt,
        'inst_code': inst_code_display,
        'inst_name': inst_name or '',
        'error_message': None,
    })


@jwt_report_authorized(allowed_roles=['INSTITUTE', 'RBTE', 'ADMIN'])
def seat_chart_ec_next(request):
    """
    Candidate details for exam center + paper code (PHP: seat_chart_ec_next).
    GET params: instid, pcode.
    Displays candidates from S19_INPUT_EXAM_MARKS_TH for center_code and paper_code.
    """
    auth, error = get_auth_context(
        request,
        redirect_url='dashboard:seating_chart:seating_chart_home',
        require_institute=False,
    )
    if error:
        return error

    user_info, err = get_user_control_info(
        request, auth,
        allowed_roles=['INSTITUTE', 'RBTE', 'ADMIN'],
        require_institute_code=False,
        redirect_url='dashboard:seating_chart:seating_chart_home',
        error_message='You are not authorised to view this report',
    )
    if err:
        return err

    instid = (request.GET.get('instid') or '').strip()
    pcode = (request.GET.get('pcode') or '').strip()
    current_exam_label = getattr(msbte_config, 'ACA_NAME_EXAM_S', 'Summer 2026')

    if not instid or not pcode:
        return render(request, 'seating_chart_inst/seat_chart_ec_next.html', {
            'error_message': 'Institute and Paper Code are required.',
            'current_exam_label': current_exam_label,
            'report_rows': [],
            'no_data': True,
            'subject_name': '',
        })

    try:
        center_code_int = int(str(instid).lstrip('0'))
    except (ValueError, TypeError):
        center_code_int = instid

    tbl = getattr(msbte_config, 'S19_INPUT_EXAM_MARKS_TH', None)
    if not tbl:
        return render(request, 'seating_chart_inst/seat_chart_ec_next.html', {
            'error_message': 'Report configuration not available.',
            'current_exam_label': current_exam_label,
            'report_rows': [],
            'no_data': True,
            'subject_name': '',
        })

    conn = get_db_connection()
    # Match PHP: inst_code, course_code, year_code, master_code, paper_code, subject_name, seat_no
    query_tpl = """
        SELECT inst_code, course_code, year_code, master_code, paper_code, subject_name, seat_no
        FROM {tbl}
        WHERE center_code = %s AND paper_code = %s
          AND (special_code IS NULL OR special_code NOT IN ('402', '405'))
        ORDER BY seat_no
    """
    df = pd.DataFrame()
    try:
        df = pd.read_sql(query_tpl.format(tbl=tbl), conn, params=[center_code_int, pcode])
        if df.empty:
            ems_th = getattr(msbte_config, 'EMS_DB_TH', '')
            if ems_th and '_nonaicte' in ems_th:
                tbl_alt = ems_th.replace('_nonaicte', '') + '.w25_th_input'
                df = pd.read_sql(query_tpl.format(tbl=tbl_alt), conn, params=[center_code_int, pcode])
    except Exception as e:
        logger.exception("seat_chart_ec_next query failed: %s", e)
        try:
            ems_th = getattr(msbte_config, 'EMS_DB_TH', '')
            if ems_th and '_nonaicte' in ems_th:
                tbl_alt = ems_th.replace('_nonaicte', '') + '.w25_th_input'
                df = pd.read_sql(query_tpl.format(tbl=tbl_alt), conn, params=[center_code_int, pcode])
            if df.empty:
                # Fallback: try PascalCase column names (SeatNo, CourseCode, etc.)
                query_pascal = """
                    SELECT InstCode AS inst_code, CourseCode AS course_code, YearCode AS year_code,
                           MasterCode AS master_code, paper_code, SubjectName AS subject_name,
                           SeatNo AS seat_no
                    FROM {tbl}
                    WHERE center_code = %s AND paper_code = %s
                      AND (special_code IS NULL OR special_code NOT IN ('402', '405'))
                    ORDER BY SeatNo
                """.format(tbl=tbl)
                df = pd.read_sql(query_pascal, conn, params=[center_code_int, pcode])
        except Exception as e2:
            logger.exception("seat_chart_ec_next alt query failed: %s", e2)
            return render(request, 'seating_chart_inst/seat_chart_ec_next.html', {
                'error_message': 'Report query failed. Table columns may differ.',
                'current_exam_label': current_exam_label,
                'report_rows': [],
                'no_data': True,
                'subject_name': '',
            })

    report_rows = []
    subject_name = ''
    for _, r in df.iterrows():
        if not subject_name and r.get('subject_name'):
            subject_name = str(r.get('subject_name') or '').strip()
        # seat_no or seatno for compatibility
        seat_val = r.get('seat_no') or r.get('seatno') or ''
        report_rows.append({
            'seatno': seat_val,
            'course_code': r.get('course_code') or '',
            'year_code': r.get('year_code') or '',
            'master_code': r.get('master_code') or '',
            'inst_code': r.get('inst_code') or '',
        })

    inst_code_display = str(center_code_int).zfill(4)
    inst_name = get_inst_name(center_code_int)

    return render(request, 'seating_chart_inst/seat_chart_ec_next.html', {
        'current_exam_label': current_exam_label,
        'user_info': user_info,
        'report_rows': report_rows,
        'no_data': len(report_rows) == 0,
        'inst_code': inst_code_display,
        'inst_name': inst_name or '',
        'paper_code': pcode,
        'subject_name': subject_name,
        'error_message': None,
    })


@jwt_report_authorized(allowed_roles=['INSTITUTE', 'RBTE', 'ADMIN'])
def seatingchart_arrangement_ec_cand_list(request):
    """
    Seating arrangement for Exam Centers - paper list with Paper Date, Paper Name, Paper Time (PHP: seatingchart_arrangement_ec_cand_list).
    Columns: Sr No, Paper Code, Paper Date, Paper Name, Paper Time, Candidate Count.
    Links to seat_chart_ec_list_cands.
    """
    auth, err = get_auth_context(
        request, redirect_url='dashboard:seating_chart:seating_chart_home', require_institute=False,
    )
    if err:
        return err
    user_info, err = get_user_control_info(
        request, auth,
        allowed_roles=['INSTITUTE', 'RBTE', 'ADMIN'],
        require_institute_code=False,
        redirect_url='dashboard:seating_chart:seating_chart_home',
        error_message='You are not authorised to view this report',
    )
    if err:
        return err

    uid = user_info.get('uid')
    user_role = (user_info.get('user_role') or auth.get('role') or '').upper()
    is_admin = user_info.get('is_admin', False)
    current_exam_label = getattr(msbte_config, 'ACA_NAME_EXAM_S', 'Summer 2026')
    conn = get_db_connection()
    tbl = getattr(msbte_config, 'S19_INPUT_EXAM_MARKS_TH', None)

    if not tbl:
        return render(request, 'seating_chart_inst/seatingchart_arrangement_ec_cand_list.html', {
            'error_message': 'Report configuration not available.',
            'current_exam_label': current_exam_label,
            'paper_rows': [],
            'exam_centers': [],
        })

    inst_code = None
    uname_int = None
    if not is_admin and user_role == 'INSTITUTE':
        uid_str = str(uid or '').strip()
        inst_code = uid_str[-4:] if len(uid_str) >= 4 else uid_str
    else:
        inst_code = auth.get('institute_code') if auth.get('is_jwt') else user_info.get('inst_code')
        inst_code = inst_code or request.GET.get('instid')

    if not inst_code:
        exam_centers = []
        try:
            df_ec = pd.read_sql(
                f"SELECT DISTINCT r.exam_center, i.inst_name FROM {msbte_config.W25_RAC_DC_DETAILS} r "
                f"INNER JOIN {msbte_config.INSTITUTES} i ON i.inst_id = r.exam_center ORDER BY r.exam_center",
                conn,
            )
            exam_centers = [{'inst_id': int(r['exam_center']), 'inst_name': r['inst_name'] or f"Institute {int(r['exam_center'])}"} for _, r in df_ec.iterrows()]
        except Exception:
            exam_centers = []
        return render(request, 'seating_chart_inst/seatingchart_arrangement_ec_cand_list.html', {
            'exam_centers': exam_centers,
            'current_exam_label': current_exam_label,
            'form_action': reverse('dashboard:seating_chart:seating_chart_inst:seatingchart_arrangement_ec_cand_list'),
            'paper_rows': [],
        })

    try:
        uname_int = int(str(inst_code).lstrip('0'))
    except (ValueError, TypeError):
        uname_int = None
    if not uname_int:
        return render(request, 'seating_chart_inst/seatingchart_arrangement_ec_cand_list.html', {
            'error_message': 'Invalid institute code.',
            'current_exam_label': current_exam_label,
            'paper_rows': [],
        })

    # PHP: SELECT paper_date, paper_code, count(*), subject_abbr FROM S19 WHERE center_code=? and paper_code!=''
    #      and paper_day!='' and special_code not in('402','405') GROUP BY paper_code
    #      ORDER BY paper_day, FIELD(daysession,'M','A',''), paper_code asc
    query_main = """
        SELECT paper_code, COUNT(*) AS cnt,
               MAX(paper_date) AS paper_date,
               MAX(subject_abbr) AS subject_abbr,
               MAX(paper_day) AS paper_day,
               CASE
                   WHEN MAX(CASE WHEN daysession='M' THEN 1 ELSE 0 END)=1 THEN 1
                   WHEN MAX(CASE WHEN daysession='A' THEN 1 ELSE 0 END)=1 THEN 2
                   ELSE 3
               END AS day_session_order
        FROM {tbl}
        WHERE center_code = %s AND paper_code != '' AND paper_code IS NOT NULL
          AND paper_day IS NOT NULL AND paper_day != ''
          AND (special_code IS NULL OR special_code NOT IN ('402','405'))
        GROUP BY paper_code
        ORDER BY paper_day, day_session_order, paper_code ASC
    """
    df = pd.DataFrame()
    try:
        df = pd.read_sql(query_main.format(tbl=tbl), conn, params=[uname_int])
    except Exception as ex:
        logger.debug("seatingchart_arrangement_ec_cand_list main query (paper_day/daysession) failed: %s", ex)
        query_fallback = """
            SELECT paper_code, COUNT(*) AS cnt,
                   MAX(paper_date) AS paper_date,
                   MAX(subject_abbr) AS subject_abbr
            FROM {tbl}
            WHERE center_code = %s AND paper_code != '' AND paper_code IS NOT NULL
              AND (special_code IS NULL OR special_code NOT IN ('402','405'))
            GROUP BY paper_code
            ORDER BY paper_code ASC
        """
        try:
            df = pd.read_sql(query_fallback.format(tbl=tbl), conn, params=[uname_int])
        except Exception as ex2:
            logger.exception("seatingchart_arrangement_ec_cand_list query failed: %s", ex2)
            df = pd.DataFrame()

    if df.empty:
        ems_th = getattr(msbte_config, 'EMS_DB_TH', '')
        if ems_th and '_nonaicte' in ems_th:
            tbl_alt = ems_th.replace('_nonaicte', '') + '.w25_th_input'
            try:
                df = pd.read_sql(query_main.format(tbl=tbl_alt), conn, params=[uname_int])
            except Exception:
                try:
                    q_alt = """
                        SELECT paper_code, COUNT(*) AS cnt, MAX(paper_date) AS paper_date, MAX(subject_abbr) AS subject_abbr
                        FROM {t} WHERE center_code=%s AND paper_code!='' AND (special_code IS NULL OR special_code NOT IN ('402','405'))
                        GROUP BY paper_code ORDER BY paper_code
                    """.format(t=tbl_alt)
                    df = pd.read_sql(q_alt, conn, params=[uname_int])
                except Exception:
                    pass

    tbl_timetable = getattr(msbte_config, 'TIMETABLE_SUBJECTS_COURSE_ALL', None)

    paper_rows = []
    tot_cnt = 0
    for _, r in df.iterrows():
        cnt = int(r['cnt']) if pd.notna(r['cnt']) else 0
        tot_cnt += cnt
        pcode = r.get('paper_code') or ''
        subject_abbr = (r.get('subject_abbr') or '').strip()

        # PHP: subject_name from S19 first candidate (ORDER BY seat_no)
        subj = ''
        try:
            q_subj = """
                SELECT subject_name FROM {tbl}
                WHERE center_code = %s AND paper_code = %s
                  AND (special_code IS NULL OR special_code NOT IN ('402','405'))
                ORDER BY seat_no
                LIMIT 1
            """.format(tbl=tbl)
            df_subj = pd.read_sql(q_subj, conn, params=[uname_int, pcode])
            if not df_subj.empty and pd.notna(df_subj.iloc[0].get('subject_name')):
                subj = str(df_subj.iloc[0]['subject_name']).strip()
        except Exception:
            pass

        # PHP: TIMETABLE_SUBJECTS_COURSE_ALL - tentative_date (dd-mm-yyyy), paper_time, subject_name (fallback)
        tdate_str = ''
        paper_date_val = r.get('paper_date')
        if pd.notna(paper_date_val) and paper_date_val:
            if hasattr(paper_date_val, 'strftime'):
                tdate_str = paper_date_val.strftime('%d-%m-%Y')
            else:
                raw_date = str(paper_date_val).strip()
                parts = raw_date.split('-')
                if len(parts) == 3 and len(parts[0]) == 4:
                    tdate_str = f"{parts[2]}-{parts[1]}-{parts[0]}"
                else:
                    tdate_str = raw_date[:10]
        ptime_str = ''
        subj_tt = ''
        if tbl_timetable:
            try:
                q_tt = """
                    SELECT tentative_date, paper_time, subject_name FROM {tbl}
                    WHERE paper_code = %s
                    ORDER BY paper_code, FIELD(master_code,'E','C','A','S','R','N','O','T')
                    LIMIT 1
                """.format(tbl=tbl_timetable)
                df_tt = pd.read_sql(q_tt, conn, params=[pcode])
                if not df_tt.empty:
                    tdate = df_tt.iloc[0].get('tentative_date')
                    if (not tdate_str) and pd.notna(tdate) and tdate:
                        if hasattr(tdate, 'strftime'):
                            tdate_str = tdate.strftime('%d-%m-%Y')
                        else:
                            parts = str(tdate).split('-')
                            if len(parts) == 3:
                                tdate_str = f"{parts[2]}-{parts[1]}-{parts[0]}"
                            else:
                                tdate_str = str(tdate)[:10]
                    pt = df_tt.iloc[0].get('paper_time')
                    ptime_str = str(pt).strip() if pd.notna(pt) and pt else ''
                    st = df_tt.iloc[0].get('subject_name')
                    subj_tt = str(st).strip() if pd.notna(st) and st else ''
            except Exception as ex_tt:
                logger.debug("TIMETABLE_SUBJECTS_COURSE_ALL query failed for paper %s: %s", pcode, ex_tt)

        # Full paper name like CONSTRUCTION MATERIALS[CMA]: subject_name + "[" + subject_abbr + "]"
        subject_display = subj or subj_tt or pcode
        paper_name = f"{subject_display}[{subject_abbr}]" if subject_abbr else subject_display

        paper_rows.append({
            'paper_code': pcode,
            'cnt': cnt,
            'paper_date': tdate_str,
            'paper_name': paper_name,
            'paper_time': ptime_str,
            'subject_name': subj,
        })

    inst_name = get_inst_name(uname_int)
    inst_code_display = str(uname_int).zfill(4)

    return render(request, 'seating_chart_inst/seatingchart_arrangement_ec_cand_list.html', {
        'current_exam_label': current_exam_label,
        'paper_rows': paper_rows,
        'tot_cnt': tot_cnt,
        'inst_code': inst_code_display,
        'inst_name': inst_name or '',
        'exam_centers': None,
        'error_message': None,
    })


@jwt_report_authorized(allowed_roles=['INSTITUTE', 'RBTE', 'ADMIN'])
def seat_chart_ec_list_cands(request):
    """
    Candidate list for seating arrangement (PHP: seat_chart_ec_list_cands).
    GET: instid, pcode, papername, tdate (paper date), ptime (paper time).
    Same data as seat_chart_ec_next but with Paper Time and Paper Date in header.
    """
    auth, err = get_auth_context(
        request, redirect_url='dashboard:seating_chart:seating_chart_home', require_institute=False,
    )
    if err:
        return err
    user_info, err = get_user_control_info(
        request, auth,
        allowed_roles=['INSTITUTE', 'RBTE', 'ADMIN'],
        require_institute_code=False,
        redirect_url='dashboard:seating_chart:seating_chart_home',
        error_message='You are not authorised to view this report',
    )
    if err:
        return err

    instid = (request.GET.get('instid') or '').strip()
    pcode = (request.GET.get('pcode') or '').strip()
    papername = (request.GET.get('papername') or '').strip()
    tdate = (request.GET.get('tdate') or '').strip()
    ptime = (request.GET.get('ptime') or '').strip()
    current_exam_label = getattr(msbte_config, 'ACA_NAME_EXAM_S', 'Summer 2026')

    if not instid or not pcode:
        return render(request, 'seating_chart_inst/seat_chart_ec_list_cands.html', {
            'error_message': 'Institute and Paper Code are required.',
            'current_exam_label': current_exam_label,
            'report_rows': [],
            'no_data': True,
            'subject_name': '',
            'paper_time': '',
            'paper_date': '',
        })

    try:
        center_code_int = int(str(instid).lstrip('0'))
    except (ValueError, TypeError):
        center_code_int = instid

    tbl = getattr(msbte_config, 'S19_INPUT_EXAM_MARKS_TH', None)
    if not tbl:
        return render(request, 'seating_chart_inst/seat_chart_ec_list_cands.html', {
            'error_message': 'Report configuration not available.',
            'current_exam_label': current_exam_label,
            'report_rows': [],
            'no_data': True,
            'subject_name': '',
            'paper_time': '',
            'paper_date': '',
        })

    conn = get_db_connection()
    query_tpl = """
        SELECT inst_code, course_code, year_code, master_code, paper_code, subject_name, seat_no
        FROM {tbl}
        WHERE center_code = %s AND paper_code = %s
          AND (special_code IS NULL OR special_code NOT IN ('402','405'))
        ORDER BY seat_no
    """
    df = pd.DataFrame()
    try:
        df = pd.read_sql(query_tpl.format(tbl=tbl), conn, params=[center_code_int, pcode])
        if df.empty:
            ems_th = getattr(msbte_config, 'EMS_DB_TH', '')
            if ems_th and '_nonaicte' in ems_th:
                tbl_alt = ems_th.replace('_nonaicte', '') + '.w25_th_input'
                df = pd.read_sql(query_tpl.format(tbl=tbl_alt), conn, params=[center_code_int, pcode])
    except Exception as e:
        logger.exception("seat_chart_ec_list_cands query failed: %s", e)
        ems_th = getattr(msbte_config, 'EMS_DB_TH', '')
        if ems_th and '_nonaicte' in ems_th:
            try:
                tbl_alt = ems_th.replace('_nonaicte', '') + '.w25_th_input'
                df = pd.read_sql(query_tpl.format(tbl=tbl_alt), conn, params=[center_code_int, pcode])
            except Exception:
                pass

    report_rows = []
    subject_name = papername or ''
    for _, r in df.iterrows():
        if not subject_name and r.get('subject_name'):
            subject_name = str(r.get('subject_name') or '').strip()
        seat_val = r.get('seat_no') or r.get('seatno') or ''
        report_rows.append({
            'seatno': seat_val,
            'course_code': r.get('course_code') or '',
            'year_code': r.get('year_code') or '',
            'master_code': r.get('master_code') or '',
            'inst_code': r.get('inst_code') or '',
        })

    if not subject_name:
        subject_name = papername or ''

    inst_code_display = str(center_code_int).zfill(4)
    inst_name = get_inst_name(center_code_int)

    return render(request, 'seating_chart_inst/seat_chart_ec_list_cands.html', {
        'current_exam_label': current_exam_label,
        'user_info': user_info,
        'report_rows': report_rows,
        'no_data': len(report_rows) == 0,
        'inst_code': inst_code_display,
        'inst_name': inst_name or '',
        'paper_code': pcode,
        'subject_name': subject_name,
        'paper_time': ptime,
        'paper_date': tdate,
        'error_message': None,
    })


@jwt_report_authorized(allowed_roles=['INSTITUTE', 'RBTE', 'ADMIN'])
def inst_attendance_sheet_s13(request):
    """
    Centre Wise Attendance Sheet (PHP: attendance_sheet).
    Available only for Exam Centers (center_code must exist in SEAT_NO_W25).
    Form: Course, Semester, Master Code, Status (A/R/X), Block (25/30/35/40/45/50).
    On submit: show block list; links to attendance_sheet_next1_s13.
    """
    auth, err = get_auth_context(
        request, redirect_url='dashboard:seating_chart:seating_chart_home', require_institute=False,
    )
    if err:
        return err
    user_info, err = get_user_control_info(
        request, auth,
        allowed_roles=['INSTITUTE', 'RBTE', 'ADMIN'],
        require_institute_code=False,
        redirect_url='dashboard:seating_chart:seating_chart_home',
        error_message='You are not authorised to view this report',
    )
    if err:
        return err

    uid = user_info.get('uid')
    user_role = (user_info.get('user_role') or auth.get('role') or '').upper()
    is_admin = user_info.get('is_admin', False)
    current_exam_label = getattr(msbte_config, 'ACA_NAME_EXAM_S', 'Summer 2026')

    # Resolve inst_code (PHP: INSTITUTE from uid; else instid from request)
    inst_code = None
    if not is_admin and user_role == 'INSTITUTE':
        uid_str = str(uid or '').strip()
        if len(uid_str) == 7:
            inst_code = uid_str[-5:]
        elif len(uid_str) >= 5:
            inst_code = uid_str[-5:5]
        else:
            inst_code = uid_str[-4:] if len(uid_str) >= 4 else uid_str
    else:
        instid = (request.GET.get('instid') or request.POST.get('instid') or '').strip()
        inst_code = instid.lstrip('0') or instid

    if not inst_code:
        exam_centers = []
        try:
            conn = get_db_connection()
            df_ec = pd.read_sql(
                f"SELECT DISTINCT r.exam_center, i.inst_name FROM {msbte_config.W25_RAC_DC_DETAILS} r "
                f"INNER JOIN {msbte_config.INSTITUTES} i ON i.inst_id = r.exam_center ORDER BY r.exam_center",
                conn,
            )
            exam_centers = [{'inst_id': int(r['exam_center']), 'inst_name': r['inst_name'] or f"Institute {int(r['exam_center'])}"} for _, r in df_ec.iterrows()]
        except Exception as ex:
            logger.debug("inst_attendance_sheet_s13 exam centers: %s", ex)
            exam_centers = []
        return render(request, 'seating_chart_inst/inst_attendance_sheet_s13.html', {
            'exam_centers': exam_centers,
            'current_exam_label': current_exam_label,
            'form_action': reverse('dashboard:seating_chart:seating_chart_inst:inst_attendance_sheet_s13'),
            'block_list': None,
            'courses': [],
            'error_message': None,
        })

    try:
        inst_code_int = int(str(inst_code).lstrip('0'))
    except (ValueError, TypeError):
        inst_code_int = 0
    inst_code_4 = str(inst_code_int).zfill(4)

    conn = get_db_connection()
    tbl_seat = getattr(msbte_config, 'SEAT_NO_W25', None)
    tbl_courses = getattr(msbte_config, 'COURSES1', None)
    if not tbl_seat or not tbl_courses:
        return render(request, 'seating_chart_inst/inst_attendance_sheet_s13.html', {
            'error_message': 'Report configuration not available.',
            'current_exam_label': current_exam_label,
            'block_list': None,
            'courses': [],
        })

    # PHP: Check center_code exists - "This link is available only for Exam Centers"
    try:
        chk = pd.read_sql(
            f"SELECT 1 FROM {tbl_seat} WHERE center_code = %s LIMIT 1",
            conn, params=[inst_code_4],
        )
        if chk.empty:
            chk = pd.read_sql(
                f"SELECT 1 FROM {tbl_seat} WHERE center_code = %s LIMIT 1",
                conn, params=[inst_code_int],
            )
        if chk.empty:
            return render(request, 'seating_chart_inst/inst_attendance_sheet_s13.html', {
                'error_message': 'This link is available only for Exam Centers.',
                'current_exam_label': current_exam_label,
                'block_list': None,
                'courses': [],
            })
    except Exception as ex:
        logger.exception("inst_attendance_sheet_s13 center check failed: %s", ex)
        return render(request, 'seating_chart_inst/inst_attendance_sheet_s13.html', {
            'error_message': 'Unable to verify exam center.',
            'current_exam_label': current_exam_label,
            'block_list': None,
            'courses': [],
        })

    typ = (request.GET.get('ty') or request.POST.get('typ') or 'C').strip().upper()
    typ = 'C' if typ not in ('C', 'I') else typ
    type_str_col = 'center_code' if typ == 'C' else 'inst_code'

    # Fetch courses (PHP: SEAT_NO_W25 b, COURSES1 c)
    try:
        q_courses = f"""
            SELECT b.course_code, b.course_name, c.course_id
            FROM {tbl_seat} b, {tbl_courses} c
            WHERE {type_str_col} = %s AND b.course_code = c.course_code
            GROUP BY b.course_code
        """
        df_courses = pd.read_sql(q_courses, conn, params=[inst_code_4])
        if df_courses.empty:
            df_courses = pd.read_sql(q_courses, conn, params=[inst_code_int])
        courses = [
            {'course_id': int(r['course_id']), 'course_code': r['course_code'] or '', 'course_name': r['course_name'] or ''}
            for _, r in df_courses.iterrows()
        ]
    except Exception as ex:
        logger.exception("inst_attendance_sheet_s13 courses query failed: %s", ex)
        courses = []

    # Form values
    course = request.POST.get('course') or request.GET.get('course') or ''
    semester = request.POST.get('semester') or request.GET.get('semester') or ''
    master = (request.POST.get('master') or request.GET.get('master') or '').strip()[:1]
    status = (request.POST.get('status') or request.GET.get('status') or '')
    block = (request.POST.get('block') or request.GET.get('block') or '25').strip()
    try:
        block_int = int(block)
        if block_int not in (25, 30, 35, 40, 45, 50):
            block_int = 25
    except (ValueError, TypeError):
        block_int = 25
    block = str(block_int)

    flg = request.POST.get('flg')
    block_list = None

    if flg == '1' and course and semester:
        if not typ:
            return render(request, 'seating_chart_inst/inst_attendance_sheet_s13.html', {
                'error_message': 'Something is Missing.',
                'current_exam_label': current_exam_label,
                'courses': courses,
                'block_list': None,
                'form_action': reverse('dashboard:seating_chart:seating_chart_inst:inst_attendance_sheet_s13'),
                'course': course,
                'semester': semester,
                'master': master,
                'status': status,
                'block': block,
                'typ': typ,
            })
        try:
            crs = pd.read_sql(
                f"SELECT course_code FROM {tbl_courses} WHERE course_id = %s",
                conn, params=[course],
            )
            if crs.empty:
                return render(request, 'seating_chart_inst/inst_attendance_sheet_s13.html', {
                    'error_message': 'Please Select Course.',
                    'current_exam_label': current_exam_label,
                    'courses': courses,
                    'block_list': None,
                    'course': course,
                    'semester': semester,
                    'master': master,
                    'status': status,
                    'block': block,
                    'typ': typ,
                })
            arrcourse_code = str(crs.iloc[0]['course_code'])

            parts = [
                f"course_code = '{arrcourse_code}'",
                f"{type_str_col} = '{inst_code_4}'",
                f"year_code = '{semester}'",
            ]
            if master:
                parts.append(f"master_code = '{master}'")
            if status in ('R', 'X'):
                parts.append(f"status_code = '{status}'")
            parts.append("(block IS NULL OR block != 'Y')")
            where_clause = " AND ".join(parts)
            q1 = f"""
                SELECT * FROM {tbl_seat}
                WHERE {where_clause}
                ORDER BY course_code, year_code, master_code, enroll_no, name
            """
            df1 = pd.read_sql(q1, conn)
            num = len(df1)
            blk = (num + block_int - 1) // block_int if num > 0 else 0
            blocks = []
            for i in range(blk):
                fr = i * block_int
                to_val = block_int
                j = i + 1
                blocks.append({
                    'label': f'Block{j}',
                    'from': fr,
                    'to': to_val,
                    'url': reverse('dashboard:seating_chart:seating_chart_inst:attendance_sheet_next1_s13') +
                        f'?course_id={course}&sem={semester}&master={master}&status={status}&from={fr}&to={to_val}&typ={typ}&instid={inst_code_4}',
                })
            block_list = {'num': num, 'blocks': blocks}
        except Exception as ex:
            logger.exception("inst_attendance_sheet_s13 block query failed: %s", ex)
            block_list = None

    return render(request, 'seating_chart_inst/inst_attendance_sheet_s13.html', {
        'current_exam_label': current_exam_label,
        'courses': courses,
        'block_list': block_list,
        'form_action': reverse('dashboard:seating_chart:seating_chart_inst:inst_attendance_sheet_s13'),
        'course': course,
        'semester': semester,
        'master': master,
        'status': status,
        'block': block,
        'typ': typ,
        'inst_code': inst_code_4,
        'error_message': None,
    })


@jwt_report_authorized(allowed_roles=['INSTITUTE', 'RBTE', 'ADMIN'])
def attendance_sheet_next1_s13(request):
    """
    Attendance Sheet block candidate list (PHP: attendance_sheet_next1_s13).
    GET: course_id, sem, master, status, from, to, typ, instid.
    """
    auth, err = get_auth_context(
        request, redirect_url='dashboard:seating_chart:seating_chart_home', require_institute=False,
    )
    if err:
        return err
    user_info, err = get_user_control_info(
        request, auth,
        allowed_roles=['INSTITUTE', 'RBTE', 'ADMIN'],
        require_institute_code=False,
        redirect_url='dashboard:seating_chart:seating_chart_home',
        error_message='You are not authorised to view this report',
    )
    if err:
        return err

    course_id = request.GET.get('course_id') or ''
    sem = request.GET.get('sem') or ''
    master = (request.GET.get('master') or '').strip()
    status = (request.GET.get('status') or '').strip()
    from_val = request.GET.get('from') or '0'
    to_val = request.GET.get('to') or '25'
    typ = (request.GET.get('typ') or 'C').strip().upper()
    instid = (request.GET.get('instid') or '').strip()

    current_exam_label = getattr(msbte_config, 'ACA_NAME_EXAM_S', 'Summer 2026')
    conn = get_db_connection()
    tbl_seat = getattr(msbte_config, 'SEAT_NO_W25', None)
    tbl_courses = getattr(msbte_config, 'COURSES1', None)

    if not course_id or not sem or not tbl_seat or not tbl_courses:
        return render(request, 'seating_chart_inst/attendance_sheet_next1_s13.html', {
            'error_message': 'Missing parameters or configuration.',
            'current_exam_label': current_exam_label,
            'report_rows': [],
            'report_batches': [],
        })

    try:
        from_i = int(from_val)
        to_i = int(to_val)
    except (ValueError, TypeError):
        from_i, to_i = 0, 25

    inst_code_4 = instid.zfill(4) if instid else ''
    type_str_col = 'center_code' if typ == 'C' else 'inst_code'

    try:
        crs = pd.read_sql(f"SELECT course_code, course_name FROM {tbl_courses} WHERE course_id = %s", conn, params=[course_id])
        if crs.empty:
            return render(request, 'seating_chart_inst/attendance_sheet_next1_s13.html', {
                'error_message': 'Invalid course.',
                'current_exam_label': current_exam_label,
                'report_rows': [],
                'report_batches': [],
            })
        course_code = str(crs.iloc[0]['course_code'])
        course_name = str(crs.iloc[0]['course_name']) if pd.notna(crs.iloc[0].get('course_name')) else course_code
    except Exception:
        return render(request, 'seating_chart_inst/attendance_sheet_next1_s13.html', {
            'error_message': 'Invalid course.',
            'current_exam_label': current_exam_label,
            'report_rows': [],
            'report_batches': [],
        })

    params = [course_code, inst_code_4, sem]
    where_parts = ["course_code = %s", f"{type_str_col} = %s", "year_code = %s", "(block IS NULL OR block != 'Y')"]
    if master:
        where_parts.append("master_code = %s")
        params.append(master)
    if status in ('R', 'X'):
        where_parts.append("status_code = %s")
        params.append(status)
    where_clause = " AND ".join(where_parts)
    params.extend([to_i, from_i])

    # PHP: SELECT * FROM SEAT_NO_W25 - need seat_no, status_code, sub_appear for attendance layout
    q = f"""
        SELECT enroll_no, name, seat_no, course_code, year_code, master_code, status_code, sub_appear
        FROM {tbl_seat}
        WHERE {where_clause}
        ORDER BY course_code, year_code, master_code, enroll_no, name
        LIMIT %s OFFSET %s
    """
    report_rows = []
    try:
        df = pd.read_sql(q, conn, params=params)
    except Exception as ex:
        try:
            q_fallback = f"""
                SELECT enroll_no, name, course_code, year_code, master_code
                FROM {tbl_seat}
                WHERE {where_clause}
                ORDER BY course_code, year_code, master_code, enroll_no, name
                LIMIT %s OFFSET %s
            """
            df = pd.read_sql(q_fallback, conn, params=params)
            df['seat_no'] = df.get('enroll_no', '')  # fallback
            df['status_code'] = ''
            df['sub_appear'] = ''
        except Exception as ex2:
            logger.exception("attendance_sheet_next1_s13 query failed: %s", ex2)
            return render(request, 'seating_chart_inst/attendance_sheet_next1_s13.html', {
                'error_message': 'Report query failed. Table columns may differ.',
                'current_exam_label': current_exam_label,
                'report_rows': [],
                'report_batches': [],
                'inst_name': '',
                'inst_code': inst_code_4,
                'course_name': course_name,
                'course_code': course_code,
                'city_name': '',
                'region_name': '',
                'printed_by': '',
            })

    tbl_input = getattr(msbte_config, 'S19_INPUT_EXAM_MARKS_TH', None)
    tbl_cand = getattr(msbte_config, 'CAND_INFO', None)
    try:
        inst_id_int = int(str(inst_code_4).lstrip('0') or 0) if inst_code_4 else None
    except (ValueError, TypeError):
        inst_id_int = None
    inst_name = get_inst_name(inst_id_int) if inst_id_int else ''
    city_name = get_city_name(inst_id_int) if inst_id_int else ''
    region_name = ''
    reg_code = None
    try:
        if inst_id_int and msbte_config.INSTITUTES:
            df_reg = pd.read_sql(
                f"SELECT reg_code FROM {msbte_config.INSTITUTES} WHERE inst_id = %s LIMIT 1",
                conn, params=[inst_id_int]
            )
            if not df_reg.empty and pd.notna(df_reg.iloc[0].get('reg_code')):
                reg_code = df_reg.iloc[0]['reg_code']
                region_name = get_region_name(reg_code) if reg_code else ''
    except Exception:
        pass

    user_role = (user_info.get('user_role') or auth.get('role') or '').upper()
    uid = user_info.get('uid') or ''
    printed_by = ''
    if user_role == 'INSTITUTE':
        printed_by = str(uid).lstrip('0') or str(uid)
    elif user_role == 'RBTE':
        printed_by = get_region_name(reg_code) if reg_code else 'RBTE'
    elif user_role == 'ADMIN':
        printed_by = 'Admin'

    for idx, r in df.iterrows():
        en_no = str(r.get('enroll_no') or '')
        seat_no = r.get('seat_no') or ''
        scheme = f"{r.get('course_code') or ''}-{r.get('year_code') or ''}-{r.get('master_code') or ''}"
        cand_status = str(r.get('status_code') or '')
        sub_appear_raw = str(r.get('sub_appear') or '')
        sub_arr = [s.strip() for s in sub_appear_raw.split(',') if s.strip()]
        th_subjects = [s for s in sub_arr if 'TH' in s.upper()]
        col_cnt = len(th_subjects)

        reg_id = 0
        if tbl_cand and en_no and course_code:
            try:
                df_ci = pd.read_sql(
                    "SELECT reg_id FROM {} WHERE (course_code_n = %s OR course_code = %s) AND enroll_no = %s LIMIT 1".format(tbl_cand),
                    conn, params=[course_code, course_code, en_no]
                )
                if not df_ci.empty and pd.notna(df_ci.iloc[0].get('reg_id')):
                    reg_id = int(df_ci.iloc[0]['reg_id'])
            except Exception:
                try:
                    df_ci = pd.read_sql(
                        "SELECT reg_id FROM {} WHERE enroll_no = %s LIMIT 1".format(tbl_cand),
                        conn, params=[en_no]
                    )
                    if not df_ci.empty and pd.notna(df_ci.iloc[0].get('reg_id')):
                        reg_id = int(df_ci.iloc[0]['reg_id'])
                except Exception:
                    pass

        special_code = ''
        if tbl_input and seat_no:
            try:
                df_sc = pd.read_sql(
                    f"SELECT special_code FROM {tbl_input} WHERE seat_no = %s AND special_code IN ('402','405') "
                    "GROUP BY paper_code ORDER BY CAST(paper_code AS UNSIGNED) ASC LIMIT 1",
                    conn, params=[seat_no]
                )
                if not df_sc.empty and pd.notna(df_sc.iloc[0].get('special_code')):
                    special_code = str(df_sc.iloc[0]['special_code'])
            except Exception:
                pass

        report_rows.append({
            'enroll_no': en_no,
            'name': str(r.get('name') or ''),
            'seat_no': seat_no,
            'course_code': r.get('course_code') or '',
            'year_code': r.get('year_code') or '',
            'master_code': r.get('master_code') or '',
            'scheme': scheme,
            'status_code': cand_status,
            'subjects_th': th_subjects,
            'col_cnt': col_cnt,
            'reg_id': reg_id,
            'special_code': special_code,
        })

    # Batch into pages of 7 candidates (PHP: 7 per page)
    report_batches = []
    for i in range(0, len(report_rows), 7):
        report_batches.append(report_rows[i:i + 7])

    return render(request, 'seating_chart_inst/attendance_sheet_next1_s13.html', {
        'current_exam_label': current_exam_label,
        'course_name': course_name,
        'course_code': course_code,
        'report_rows': report_rows,
        'report_batches': report_batches,
        'error_message': None,
        'inst_name': inst_name,
        'inst_code': inst_code_4,
        'city_name': city_name,
        'region_name': region_name,
        'printed_by': printed_by,
    })
