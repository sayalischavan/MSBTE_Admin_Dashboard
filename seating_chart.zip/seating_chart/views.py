from django.shortcuts import render, redirect
from django.urls import reverse
from django.contrib.auth.decorators import login_required
from django.contrib import messages
from django.db import connections
import logging
from dashboard.decorators import allowed_users, jwt_report_authorized
import config.msbte_config as msbte_config
from dashboard.utils import (
    get_db_connection,
    get_db_connection_crud,
    get_auth_context,
    handle_report_error,
    log_query,
    get_region_name,
)
import pandas as pd
import base64

logger = logging.getLogger(__name__)

REGION_MAP = {'1': 'Mumbai', '2': 'Pune', '3': 'Nagpur', '4': 'Chhatrapati Sambhajinagar'}
CORRECTION_TYPE_NAMES = {
    '1': 'Name', '2': 'Course Code', '3': 'Year Code', '4': 'Master Code',
    '5': 'Institute Code', '6': 'Status Code', '7': 'Appear Code', '8': 'Last Exam',
    '9': 'Last Seat', '10': 'Subjects want to Appear', '11': 'Deleted',
    '12': 'Update Elective', '99': 'Any Other Remark',
}

# GPDL institute code gets course filter CC, EC, MC
GPDL_INST_CODE = '0234'


@login_required
def seating_chart_home(request):
    """
    Home view for Seating Chart module.
    """
    return render(request, 'seating_chart/seating_chart_home.html')


@jwt_report_authorized(allowed_roles=['ADMIN'])
@allowed_users(allowed_roles=['admin'])
def chart_remove_confirmation_seatno(request):
    """
    Seating Chart Correction - Institute Confirmation Removal.
    PHP Reference: chart_remove_confirmation_seatno / inst_seat_chart
    Allows admin to remove institute confirmation of seating chart corrections.
    Enter institute code, view candidates with cand_conf='Y' and inst_conf!='Y',
    select and confirm to remove confirmation (copy to backup, clear confirmation fields).
    """
    auth, error = get_auth_context(request, require_institute=False)
    if error:
        return error

    try:
        conn = get_db_connection_crud()
        sflg = request.GET.get('f') or request.POST.get('f', '')
        inst_id = (request.GET.get('inst_id') or request.POST.get('inst_id') or '').strip()
        flg = request.GET.get('hid') or request.POST.get('hid', '')

        current_exam_label = getattr(msbte_config, 'ACA_NAME_EXAM_S', 'Summer 2026')
        uid = (
            request.session.get('USER_ID')
            or getattr(request, 'jwt_user_id', None)
            or (request.user.id if request.user.is_authenticated else None)
        )
        if not uid:
            uid = 0

        # GPDL course filter: inst 0234 uses CC, EC, MC; others use NOT IN
        if inst_id == GPDL_INST_CODE:
            gpdl_course = " AND course_code IN('CC','EC','MC')"
        else:
            gpdl_course = " AND course_code NOT IN('CC','EC','MC')"

        # Success shown via toast when f=del (see template JS)

        records = []
        num = 0

        if inst_id:
            try:
                entry_by_val = int(inst_id)
            except (ValueError, TypeError):
                entry_by_val = inst_id

            selconf = f"""
                SELECT * FROM {msbte_config.CORRECTION_TYPE}
                WHERE entry_by=%s AND cand_conf='Y' AND inst_conf!='Y'
                  AND rbte_conf!='Y' {gpdl_course}
            """
            try:
                df_conf = pd.read_sql(selconf, conn, params=[entry_by_val])
            except Exception as e:
                logger.exception("chart_remove_confirmation query failed: %s", e)
                df_conf = pd.DataFrame()

            if df_conf.empty:
                messages.error(
                    request,
                    'No records found or Institute already confirmed all the correction.',
                )
            elif flg == '':
                num = len(df_conf)
                main_tbl = msbte_config.SEATING_CHART
                corr_tbl = msbte_config.CORRECTION_MASTER

                for idx, r in df_conf.iterrows():
                    en_no = r['en_no']
                    seat_no = r['seat_no']
                    correction_type = r['correction_type']
                    course_code = r['course_code']
                    year_code = r['year_code']
                    master_code = r['master_code']
                    id_val = r['id']

                    get_name = f"""
                        SELECT name, status,
                               GROUP_CONCAT(CONCAT(COALESCE(sub_abbr,''), '-', COALESCE(thpr,'')) ORDER BY year_code) AS sub_abbr,
                               last_exam_no, last_exam_seatno, seatno
                        FROM {main_tbl}
                        WHERE enroll_no=%s AND seatno=%s AND course_code=%s AND master_code=%s AND year_code=%s
                        GROUP BY course_code, year_code, master_code
                        ORDER BY year_code
                    """
                    try:
                        df_name = pd.read_sql(
                            get_name, conn,
                            params=[en_no, seat_no, course_code, master_code, year_code]
                        )
                        if df_name.empty:
                            row_data = {'name': '', 'status': '', 'sub_abbr': '', 'last_exam_seatno': None, 'last_exam_no': None}
                        else:
                            row_data = df_name.iloc[0].to_dict()
                    except Exception:
                        row_data = {'name': '', 'status': '', 'sub_abbr': '', 'last_exam_seatno': None, 'last_exam_no': None}

                    last_seat = row_data.get('last_exam_seatno')
                    if not last_seat or str(last_seat) == '000000':
                        last_seat_display = 'NA'
                    else:
                        last_seat_display = last_seat

                    lexam = row_data.get('last_exam_no') or 'NA'

                    corr_query = f"SELECT name FROM {corr_tbl} WHERE id=%s"
                    try:
                        df_corr = pd.read_sql(corr_query, conn, params=[correction_type])
                        correction_name = df_corr.iloc[0]['name'] if not df_corr.empty else str(correction_type)
                    except Exception:
                        correction_name = str(correction_type)

                    region_code = str(r.get('region_code') or '')
                    region_name = REGION_MAP.get(region_code.lstrip('0') or region_code, '') or (
                        get_region_name(region_code) if region_code else ''
                    )
                    inst_code = r.get('inst_code', '')

                    chk_value = f"{seat_no}-{en_no}-{correction_type}-{course_code}-{year_code}-{master_code}-{id_val}"

                    records.append({
                        'en_no': en_no,
                        'seat_no': seat_no,
                        'name': row_data.get('name', ''),
                        'sub_abbr': row_data.get('sub_abbr', ''),
                        'correction_type_name': correction_name,
                        'course_code': course_code,
                        'year_code': year_code,
                        'master_code': master_code,
                        'scheme': f"{course_code}-{year_code}-{master_code}",
                        'status': row_data.get('status', ''),
                        'region_name': region_name,
                        'inst_code': inst_code,
                        'lexam': lexam,
                        'last_seat_display': last_seat_display,
                        'chk_value': chk_value,
                        'idx': idx + 1,
                    })

            elif flg == '1':
                # POST: Remove confirmation
                chk_num = (request.POST.get('num') or '').strip()
                if not chk_num:
                    messages.error(request, 'Please Check the Checkbox to Confirm Candidates')
                    return redirect(reverse('dashboard:seating_chart:chart_remove_confirmation_seatno') + f'?inst_id={inst_id}')

                try:
                    n = int(chk_num)
                except ValueError:
                    n = 0

                resupdcorr = None
                cursor = conn.cursor()
                for j in range(1, n + 1):
                    reg = (request.POST.get(f'chk{j}') or '').strip()
                    if not reg:
                        continue
                    r = reg.split('-')
                    if len(r) < 7:
                        continue
                    seat_no_i, en_no, correction_type, course_code, year_code, master_code, id_val = (
                        r[0], r[1], r[2], r[3], r[4], r[5], r[6]
                    )
                    if not seat_no_i:
                        continue

                    final_cpy = f"""
                        INSERT INTO {msbte_config.CORRECTION_TYPE_COPY}
                        SELECT * FROM {msbte_config.CORRECTION_TYPE}
                        WHERE seat_no=%s AND course_code=%s AND year_code=%s AND master_code=%s
                          AND correction_type=%s AND id=%s
                    """
                    try:
                        cursor.execute(final_cpy, [
                            seat_no_i, course_code, year_code, master_code, correction_type, id_val,
                        ])
                        log_query(final_cpy, msbte_config.CORRECTION_TYPE_COPY, [
                            seat_no_i, course_code, year_code, master_code, correction_type, id_val,
                        ])
                    except Exception as e:
                        logger.exception("INSERT copy failed: %s", e)

                    updcorr = f"""
                        UPDATE {msbte_config.CORRECTION_TYPE}
                        SET cand_conf='', inst_conf='', inst_conf_by='', 
                            inst_conf_on='', cand_conf_on='', cand_conf_by='',
                            modified_by=%s, modified_on=NOW()
                        WHERE seat_no=%s AND course_code=%s AND year_code=%s AND master_code=%s
                          AND correction_type=%s AND id=%s {gpdl_course}
                        LIMIT 1
                    """
                    try:
                        cursor.execute(updcorr, [
                            uid, seat_no_i, course_code, year_code, master_code, correction_type, id_val,
                        ])
                        log_query(updcorr, msbte_config.CORRECTION_TYPE, [
                            uid, seat_no_i, course_code, year_code, master_code, correction_type, id_val,
                        ])
                        resupdcorr = cursor
                    except Exception as e:
                        logger.exception("UPDATE correction failed: %s", e)

                try:
                    conn.commit()
                except Exception:
                    pass
                cursor.close()

                return redirect(
                    reverse('dashboard:seating_chart:chart_remove_confirmation_seatno') + f'?inst_id={inst_id}&f=del'
                )

        context = {
            'current_exam_label': current_exam_label,
            'inst_id': inst_id,
            'records': records,
            'num': num,
            'success_del': sflg == 'del',
        }
        return render(request, 'seating_chart/chart_remove_confirmation_seatno.html', context)

    except Exception as e:
        return handle_report_error(request, e, auth.get('is_jwt', False))


@jwt_report_authorized(allowed_roles=['ADMIN'])
@allowed_users(allowed_roles=['admin'])
def seat_chart_remove_institute_confirmation(request):
    """
    Seating Chart Correction - Seat No and Institute Confirmation Removal.
    PHP Reference: seat_chart_remove_institute_confirmation
    Allows admin to remove seat no and institute confirmation of seating chart corrections.
    Enter seat no, view candidates with cand_conf='Y' and inst_conf!='Y',
    select and confirm to remove confirmation (copy to backup, clear confirmation fields).
    """
    auth, error = get_auth_context(request, require_institute=False)
    if error:
        return error

    try:
        conn = get_db_connection_crud()
        sflg = request.GET.get('f') or request.POST.get('f', '')
        inst_id = (request.GET.get('inst_id') or request.POST.get('inst_id') or '').strip()
        flg = request.GET.get('hid') or request.POST.get('hid', '')

        current_exam_label = getattr(msbte_config, 'ACA_NAME_EXAM_S', 'Summer 2026')
        uid = (
            request.session.get('USER_ID')
            or getattr(request, 'jwt_user_id', None)
            or (request.user.id if request.user.is_authenticated else None)
        )
        if not uid:
            uid = 0

        # GPDL course filter: inst 0234 uses CC, EC, MC; others use NOT IN
        if inst_id == GPDL_INST_CODE:
            gpdl_course = " AND course_code IN('CC','EC','MC')"
        else:
            gpdl_course = " AND course_code NOT IN('CC','EC','MC')"

        # Success shown via toast when f=del (see template JS)

        records = []
        num = 0

        if inst_id:
            try:
                entry_by_val = int(inst_id)
            except (ValueError, TypeError):
                entry_by_val = inst_id

            selconf = f"""
                SELECT * FROM {msbte_config.CORRECTION_TYPE}
                WHERE entry_by=%s AND cand_conf='Y' AND inst_conf='Y'
                  AND rbte_conf!='Y' {gpdl_course}
            """
            try:
                df_conf = pd.read_sql(selconf, conn, params=[entry_by_val])
            except Exception as e:
                logger.exception("seat_chart_remove_institute_confirmation query failed: %s", e)
                df_conf = pd.DataFrame()

            if df_conf.empty:
                messages.error(
                    request,
                    'No records found or Institute already confirmed all the correction.',
                )
            elif flg == '':
                num = len(df_conf)
                main_tbl = msbte_config.SEATING_CHART
                corr_tbl = msbte_config.CORRECTION_MASTER

                for idx, r in df_conf.iterrows():
                    en_no = r['en_no']
                    seat_no = r['seat_no']
                    correction_type = r['correction_type']
                    course_code = r['course_code']
                    year_code = r['year_code']
                    master_code = r['master_code']
                    id_val = r['id']

                    get_name = f"""
                        SELECT name, status,
                               GROUP_CONCAT(CONCAT(COALESCE(sub_abbr,''), '-', COALESCE(thpr,'')) ORDER BY year_code) AS sub_abbr,
                               last_exam_no, last_exam_seatno, seatno
                        FROM {main_tbl}
                        WHERE enroll_no=%s AND seatno=%s AND course_code=%s AND master_code=%s AND year_code=%s
                        GROUP BY course_code, year_code, master_code
                        ORDER BY year_code
                    """
                    try:
                        df_name = pd.read_sql(
                            get_name, conn,
                            params=[en_no, seat_no, course_code, master_code, year_code]
                        )
                        if df_name.empty:
                            row_data = {'name': '', 'status': '', 'sub_abbr': '', 'last_exam_seatno': None, 'last_exam_no': None}
                        else:
                            row_data = df_name.iloc[0].to_dict()
                    except Exception:
                        row_data = {'name': '', 'status': '', 'sub_abbr': '', 'last_exam_seatno': None, 'last_exam_no': None}

                    last_seat = row_data.get('last_exam_seatno')
                    if not last_seat or str(last_seat) == '000000':
                        last_seat_display = 'NA'
                    else:
                        last_seat_display = last_seat

                    lexam = row_data.get('last_exam_no') or 'NA'

                    corr_query = f"SELECT name FROM {corr_tbl} WHERE id=%s"
                    try:
                        df_corr = pd.read_sql(corr_query, conn, params=[correction_type])
                        correction_name = df_corr.iloc[0]['name'] if not df_corr.empty else str(correction_type)
                    except Exception:
                        correction_name = str(correction_type)

                    region_code = str(r.get('region_code') or '')
                    region_name = REGION_MAP.get(region_code.lstrip('0') or region_code, '') or (
                        get_region_name(region_code) if region_code else ''
                    )
                    inst_code = r.get('inst_code', '')

                    chk_value = f"{seat_no}-{en_no}-{correction_type}-{course_code}-{year_code}-{master_code}-{id_val}"

                    records.append({
                        'en_no': en_no,
                        'seat_no': seat_no,
                        'name': row_data.get('name', ''),
                        'sub_abbr': row_data.get('sub_abbr', ''),
                        'correction_type_name': correction_name,
                        'course_code': course_code,
                        'year_code': year_code,
                        'master_code': master_code,
                        'scheme': f"{course_code}-{year_code}-{master_code}",
                        'status': row_data.get('status', ''),
                        'region_name': region_name,
                        'inst_code': inst_code,
                        'lexam': lexam,
                        'last_seat_display': last_seat_display,
                        'chk_value': chk_value,
                        'idx': idx + 1,
                    })

            elif flg == '1':
                # POST: Remove confirmation
                chk_num = (request.POST.get('num') or '').strip()
                if not chk_num:
                    messages.error(request, 'Please Check the Checkbox to Confirm Candidates')
                    return redirect(reverse('dashboard:seating_chart:seat_chart_remove_institute_confirmation') + f'?inst_id={inst_id}')

                try:
                    n = int(chk_num)
                except ValueError:
                    n = 0

                resupdcorr = None
                cursor = conn.cursor()
                for j in range(1, n + 1):
                    reg = (request.POST.get(f'chk{j}') or '').strip()
                    if not reg:
                        continue
                    r = reg.split('-')
                    if len(r) < 7:
                        continue
                    seat_no_i, en_no, correction_type, course_code, year_code, master_code, id_val = (
                        r[0], r[1], r[2], r[3], r[4], r[5], r[6]
                    )
                    if not seat_no_i:
                        continue

                    final_cpy = f"""
                        INSERT INTO {msbte_config.CORRECTION_TYPE_COPY}
                        SELECT * FROM {msbte_config.CORRECTION_TYPE}
                        WHERE seat_no=%s AND course_code=%s AND year_code=%s AND master_code=%s
                          AND correction_type=%s AND id=%s
                    """
                    try:
                        cursor.execute(final_cpy, [
                            seat_no_i, course_code, year_code, master_code, correction_type, id_val,
                        ])
                        log_query(final_cpy, msbte_config.CORRECTION_TYPE_COPY, [
                            seat_no_i, course_code, year_code, master_code, correction_type, id_val,
                        ])
                    except Exception as e:
                        logger.exception("INSERT copy failed: %s", e)

                    updcorr = f"""
                        UPDATE {msbte_config.CORRECTION_TYPE}
                        SET cand_conf='Y', inst_conf='', inst_conf_by='', rbte_conf='',rbte_conf_on='',
                            inst_conf_on='', cand_conf_on='', cand_conf_by='', rbte_conf_by='',
                            modified_by=%s, modified_on=NOW()
                        WHERE seat_no=%s AND course_code=%s AND year_code=%s AND master_code=%s
                          AND correction_type=%s AND id=%s {gpdl_course}
                        LIMIT 1
                    """
                    try:
                        cursor.execute(updcorr, [
                            uid, seat_no_i, course_code, year_code, master_code, correction_type, id_val,
                        ])
                        log_query(updcorr, msbte_config.CORRECTION_TYPE, [
                            uid, seat_no_i, course_code, year_code, master_code, correction_type, id_val,
                        ])
                        resupdcorr = cursor
                    except Exception as e:
                        logger.exception("UPDATE correction failed: %s", e)

                try:
                    conn.commit()
                except Exception:
                    pass
                cursor.close()

                return redirect(
                    reverse('dashboard:seating_chart:seat_chart_remove_institute_confirmation') + f'?inst_id={inst_id}&f=del'
                )

        context = {
            'current_exam_label': current_exam_label,
            'inst_id': inst_id,
            'records': records,
            'num': num,
            'success_del': sflg == 'del',
        }
        return render(request, 'seating_chart/chart_remove_institute_confirmation.html', context)

    except Exception as e:
        return handle_report_error(request, e, auth.get('is_jwt', False))

@jwt_report_authorized(allowed_roles=['ADMIN'])
@allowed_users(allowed_roles=['admin'])
def seat_chart_remove_rbte_confirmation(request):
    """
    Seating Chart Correction - Seat No and RBTE Confirmation Removal.
    PHP Reference: seat_chart_remove_rbte_confirmation
    Allows admin to remove seat no and RBTE confirmation of seating chart corrections.
    Enter seat no, view candidates with cand_conf='Y' and rbte_conf!='Y',
    select and confirm to remove confirmation (copy to backup, clear confirmation fields).
    RBTE users can only remove confirmation for their own region.
    """
    auth, error = get_auth_context(request, require_institute=False)
    if error:
        return error

    try:
        conn = get_db_connection_crud()
        sflg = request.GET.get('f') or request.POST.get('f', '')
        inst_id = (request.GET.get('inst_id') or request.POST.get('inst_id') or '').strip()
        flg = request.GET.get('hid') or request.POST.get('hid', '')

        current_exam_label = getattr(msbte_config, 'ACA_NAME_EXAM_S', 'Summer 2026')
        uid = (
            request.session.get('USER_ID')
            or getattr(request, 'jwt_user_id', None)
            or (request.user.id if request.user.is_authenticated else None)
        )
        if not uid:
            uid = 0

        # GPDL course filter: inst 0234 uses CC, EC, MC; others use NOT IN
        if inst_id == GPDL_INST_CODE:
            gpdl_course = " AND course_code IN('CC','EC','MC')"
        else:
            gpdl_course = " AND course_code NOT IN('CC','EC','MC')"

        # Success shown via toast when f=del (see template JS)

        records = []
        num = 0

        if inst_id:
            try:
                entry_by_val = int(inst_id)
            except (ValueError, TypeError):
                entry_by_val = inst_id

            selconf = f"""
                SELECT * FROM {msbte_config.CORRECTION_TYPE}
                WHERE entry_by=%s AND cand_conf='Y' AND inst_conf='Y'
                  AND rbte_conf='Y' {gpdl_course}
            """
            try:
                df_conf = pd.read_sql(selconf, conn, params=[entry_by_val])
            except Exception as e:
                logger.exception("seat_chart_remove_institute_confirmation query failed: %s", e)
                df_conf = pd.DataFrame()

            if df_conf.empty:
                messages.error(
                    request,
                    'No records found or Institute already confirmed all the correction.',
                )
            elif flg == '':
                num = len(df_conf)
                main_tbl = msbte_config.SEATING_CHART
                corr_tbl = msbte_config.CORRECTION_MASTER

                for idx, r in df_conf.iterrows():
                    en_no = r['en_no']
                    seat_no = r['seat_no']
                    correction_type = r['correction_type']
                    course_code = r['course_code']
                    year_code = r['year_code']
                    master_code = r['master_code']
                    id_val = r['id']

                    get_name = f"""
                        SELECT name, status,
                               GROUP_CONCAT(CONCAT(COALESCE(sub_abbr,''), '-', COALESCE(thpr,'')) ORDER BY year_code) AS sub_abbr,
                               last_exam_no, last_exam_seatno, seatno
                        FROM {main_tbl}
                        WHERE enroll_no=%s AND seatno=%s AND course_code=%s AND master_code=%s AND year_code=%s
                        GROUP BY course_code, year_code, master_code
                        ORDER BY year_code
                    """
                    try:
                        df_name = pd.read_sql(
                            get_name, conn,
                            params=[en_no, seat_no, course_code, master_code, year_code]
                        )
                        if df_name.empty:
                            row_data = {'name': '', 'status': '', 'sub_abbr': '', 'last_exam_seatno': None, 'last_exam_no': None}
                        else:
                            row_data = df_name.iloc[0].to_dict()
                    except Exception:
                        row_data = {'name': '', 'status': '', 'sub_abbr': '', 'last_exam_seatno': None, 'last_exam_no': None}

                    last_seat = row_data.get('last_exam_seatno')
                    if not last_seat or str(last_seat) == '000000':
                        last_seat_display = 'NA'
                    else:
                        last_seat_display = last_seat

                    lexam = row_data.get('last_exam_no') or 'NA'

                    corr_query = f"SELECT name FROM {corr_tbl} WHERE id=%s"
                    try:
                        df_corr = pd.read_sql(corr_query, conn, params=[correction_type])
                        correction_name = df_corr.iloc[0]['name'] if not df_corr.empty else str(correction_type)
                    except Exception:
                        correction_name = str(correction_type)

                    region_code = str(r.get('region_code') or '')
                    region_name = REGION_MAP.get(region_code.lstrip('0') or region_code, '') or (
                        get_region_name(region_code) if region_code else ''
                    )
                    inst_code = r.get('inst_code', '')

                    chk_value = f"{seat_no}-{en_no}-{correction_type}-{course_code}-{year_code}-{master_code}-{id_val}"

                    records.append({
                        'en_no': en_no,
                        'seat_no': seat_no,
                        'name': row_data.get('name', ''),
                        'sub_abbr': row_data.get('sub_abbr', ''),
                        'correction_type_name': correction_name,
                        'course_code': course_code,
                        'year_code': year_code,
                        'master_code': master_code,
                        'scheme': f"{course_code}-{year_code}-{master_code}",
                        'status': row_data.get('status', ''),
                        'region_name': region_name,
                        'inst_code': inst_code,
                        'lexam': lexam,
                        'last_seat_display': last_seat_display,
                        'chk_value': chk_value,
                        'idx': idx + 1,
                    })

            elif flg == '1':
                # POST: Remove confirmation
                chk_num = (request.POST.get('num') or '').strip()
                if not chk_num:
                    messages.error(request, 'Please Check the Checkbox to Confirm Candidates')
                    return redirect(reverse('dashboard:seating_chart:seat_chart_remove_rbte_confirmation') + f'?inst_id={inst_id}')

                try:
                    n = int(chk_num)
                except ValueError:
                    n = 0

                resupdcorr = None
                cursor = conn.cursor()
                for j in range(1, n + 1):
                    reg = (request.POST.get(f'chk{j}') or '').strip()
                    if not reg:
                        continue
                    r = reg.split('-')
                    if len(r) < 7:
                        continue
                    seat_no_i, en_no, correction_type, course_code, year_code, master_code, id_val = (
                        r[0], r[1], r[2], r[3], r[4], r[5], r[6]
                    )
                    if not seat_no_i:
                        continue

                    final_cpy = f"""
                        INSERT INTO {msbte_config.CORRECTION_TYPE_COPY}
                        SELECT * FROM {msbte_config.CORRECTION_TYPE}
                        WHERE seat_no=%s AND course_code=%s AND year_code=%s AND master_code=%s
                          AND correction_type=%s AND id=%s
                    """
                    try:
                        cursor.execute(final_cpy, [
                            seat_no_i, course_code, year_code, master_code, correction_type, id_val,
                        ])
                        log_query(final_cpy, msbte_config.CORRECTION_TYPE_COPY, [
                            seat_no_i, course_code, year_code, master_code, correction_type, id_val,
                        ])
                    except Exception as e:
                        logger.exception("INSERT copy failed: %s", e)

                    updcorr = f"""
                        UPDATE {msbte_config.CORRECTION_TYPE}
                        SET  rbte_conf='',rbte_conf_on='',
                            rbte_conf_by='', modified_by=%s, modified_on=NOW()
                        WHERE seat_no=%s AND course_code=%s AND year_code=%s AND master_code=%s
                          AND correction_type=%s AND id=%s {gpdl_course}
                        LIMIT 1
                    """
                    try:
                        cursor.execute(updcorr, [
                            uid, seat_no_i, course_code, year_code, master_code, correction_type, id_val,
                        ])
                        log_query(updcorr, msbte_config.CORRECTION_TYPE, [
                            uid, seat_no_i, course_code, year_code, master_code, correction_type, id_val,
                        ])
                        resupdcorr = cursor
                    except Exception as e:
                        logger.exception("UPDATE correction failed: %s", e)

                try:
                    conn.commit()
                except Exception:
                    pass
                cursor.close()

                return redirect(
                    reverse('dashboard:seating_chart:seat_chart_remove_rbte_confirmation') + f'?inst_id={inst_id}&f=del'
                )

        context = {
            'current_exam_label': current_exam_label,
            'inst_id': inst_id,
            'records': records,
            'num': num,
            'success_del': sflg == 'del',
        }
        return render(request, 'seating_chart/chart_remove_rbte_confirmation.html', context)

    except Exception as e:
        return handle_report_error(request, e, auth.get('is_jwt', False))


@jwt_report_authorized(allowed_roles=['ADMIN'])
@allowed_users(allowed_roles=['admin'])
def chart_del_seat_chart(request):
    """
    Seating Chart Correction - Delete Records (Institute-wise).
    PHP Reference: chart_del_seat_chart
    Allows admin to delete seating chart correction records for an institute.
    Flow:
    - Enter institute code (entry_by).
    - List all correction records for that institute (with GPDL course filter).
    - On confirm: copy selected records to CORRECTION_TYPE_COPY with modified_by/modified_on,
      then delete from CORRECTION_TYPE.
    """
    auth, error = get_auth_context(request, require_institute=False)
    if error:
        return error

    try:
        conn = get_db_connection_crud()
        sflg = request.GET.get('f') or request.POST.get('f', '')
        inst_id = (request.GET.get('inst_id') or request.POST.get('inst_id') or '').strip()
        flg = request.GET.get('hid') or request.POST.get('hid', '')

        current_exam_label = getattr(msbte_config, 'ACA_NAME_EXAM_S', 'Summer 2026')
        uid = (
            request.session.get('USER_ID')
            or getattr(request, 'jwt_user_id', None)
            or (request.user.id if request.user.is_authenticated else None)
        )
        if not uid:
            uid = 0

        # GPDL course filter: inst 0234 uses CC, EC, MC; others use NOT IN
        if inst_id == GPDL_INST_CODE:
            gpdl_course = " AND course_code IN('CC','EC','MC')"
        else:
            gpdl_course = " AND course_code NOT IN('CC','EC','MC')"

        # Success shown via toast when f=del (see template JS)

        records: list[dict] = []
        num = 0

        if inst_id:
            try:
                entry_by_val = int(inst_id)
            except (ValueError, TypeError):
                entry_by_val = inst_id

            # PHP: SELECT * FROM W18_CORRECTION_TYPE WHERE entry_by=? $gpdl_course
            selconf = f"""
                SELECT * FROM {msbte_config.CORRECTION_TYPE}
                WHERE entry_by=%s {gpdl_course}
            """
            try:
                df_conf = pd.read_sql(selconf, conn, params=[entry_by_val])
            except Exception as e:
                logger.exception("chart_del_seat_chart query failed: %s", e)
                df_conf = pd.DataFrame()

            if df_conf.empty:
                messages.error(
                    request,
                    'No records found or Institute already confirmed all the correction.',
                )
            elif flg == '':
                num = len(df_conf)

                for idx, r in df_conf.iterrows():
                    en_no = r['en_no']
                    seat_no = r['seat_no']
                    correction_type = r['correction_type']
                    course_code = r['course_code']
                    year_code = r['year_code']
                    master_code = r['master_code']
                    id_val = r['id']

                    get_name = f"""
                        SELECT name, status,
                               GROUP_CONCAT(CONCAT(COALESCE(sub_abbr,''), '-', COALESCE(thpr,'')) ORDER BY year_code) AS sub_abbr,
                               last_exam_no, last_exam_seatno, seatno
                        FROM {msbte_config.SEATING_CHART}
                        WHERE enroll_no=%s AND seatno=%s AND course_code=%s AND master_code=%s AND year_code=%s
                        GROUP BY course_code, year_code, master_code
                        ORDER BY year_code
                    """
                    try:
                        df_name = pd.read_sql(
                            get_name,
                            conn,
                            params=[en_no, seat_no, course_code, master_code, year_code],
                        )
                        if df_name.empty:
                            row_data = {
                                'name': '',
                                'status': '',
                                'sub_abbr': '',
                                'last_exam_seatno': None,
                                'last_exam_no': None,
                            }
                        else:
                            row_data = df_name.iloc[0].to_dict()
                    except Exception as e:
                        logger.exception("chart_del_seat_chart name query failed: %s", e)
                        row_data = {
                            'name': '',
                            'status': '',
                            'sub_abbr': '',
                            'last_exam_seatno': None,
                            'last_exam_no': None,
                        }

                    last_seat = row_data.get('last_exam_seatno')
                    if not last_seat or str(last_seat) == '000000':
                        last_seat_display = 'NA'
                    else:
                        last_seat_display = last_seat

                    lexam = row_data.get('last_exam_no') or 'NA'

                    corr_query = f"SELECT name FROM {msbte_config.CORRECTION_MASTER} WHERE id=%s"
                    try:
                        df_corr = pd.read_sql(corr_query, conn, params=[correction_type])
                        correction_name = (
                            df_corr.iloc[0]['name'] if not df_corr.empty else str(correction_type)
                        )
                    except Exception as e:
                        logger.exception("chart_del_seat_chart corr name failed: %s", e)
                        correction_name = str(correction_type)

                    region_code = str(r.get('region_code') or '')
                    region_name = REGION_MAP.get(region_code.lstrip('0') or region_code, '') or (
                        get_region_name(region_code) if region_code else ''
                    )
                    inst_code = r.get('inst_code', '')

                    # Checkbox value: seat_no-en_no-correction_type-course_code-year_code-master_code-id
                    chk_value = (
                        f"{seat_no}-{en_no}-{correction_type}-"
                        f"{course_code}-{year_code}-{master_code}-{id_val}"
                    )

                    records.append(
                        {
                            'en_no': en_no,
                            'seat_no': seat_no,
                            'name': row_data.get('name', ''),
                            'sub_abbr': row_data.get('sub_abbr', ''),
                            'correction_type_name': correction_name,
                            'course_code': course_code,
                            'year_code': year_code,
                            'master_code': master_code,
                            'scheme': f"{course_code}-{year_code}-{master_code}",
                            'status': row_data.get('status', ''),
                            'region_name': region_name,
                            'inst_code': inst_code,
                            'lexam': lexam,
                            'last_seat_display': last_seat_display,
                            'chk_value': chk_value,
                            'idx': idx + 1,
                        }
                    )

            elif flg == '1':
                # POST: Delete selected correction records
                chk_num = (request.POST.get('num') or '').strip()
                if not chk_num:
                    messages.error(request, 'Please Check the Checkbox to Confirm Candidates')
                    return redirect(
                        reverse('dashboard:seating_chart:chart_del_seat_chart')
                        + f'?inst_id={inst_id}'
                    )

                try:
                    n = int(chk_num)
                except ValueError:
                    n = 0

                cursor = conn.cursor()
                for j in range(1, n + 1):
                    reg = (request.POST.get(f'chk{j}') or '').strip()
                    if not reg:
                        continue
                    parts = reg.split('-')
                    if len(parts) < 7:
                        continue
                    seat_no_i, en_no, correction_type, course_code, year_code, master_code, id_val = (
                        parts[0],
                        parts[1],
                        parts[2],
                        parts[3],
                        parts[4],
                        parts[5],
                        parts[6],
                    )
                    if not seat_no_i:
                        continue

                    # Copy to backup table
                    final_cpy = f"""
                        INSERT INTO {msbte_config.CORRECTION_TYPE_COPY}
                        SELECT * FROM {msbte_config.CORRECTION_TYPE}
                        WHERE seat_no=%s AND course_code=%s AND year_code=%s AND master_code=%s
                          AND correction_type=%s AND id=%s
                    """
                    try:
                        params_cpy = [
                            seat_no_i,
                            course_code,
                            year_code,
                            master_code,
                            correction_type,
                            id_val,
                        ]
                        cursor.execute(final_cpy, params_cpy)
                        log_query(final_cpy, msbte_config.CORRECTION_TYPE_COPY, params_cpy)
                    except Exception as e:
                        logger.exception("chart_del_seat_chart INSERT copy failed: %s", e)

                    # Update backup with modified_by / modified_on
                    upd_cpy = f"""
                        UPDATE {msbte_config.CORRECTION_TYPE_COPY}
                        SET modified_by=%s, modified_on=NOW()
                        WHERE id=%s
                        LIMIT 1
                    """
                    try:
                        params_upd = [uid, id_val]
                        cursor.execute(upd_cpy, params_upd)
                        log_query(upd_cpy, msbte_config.CORRECTION_TYPE_COPY, params_upd)
                    except Exception as e:
                        logger.exception("chart_del_seat_chart UPDATE copy failed: %s", e)

                    # Delete from main correction table
                    del_sql = f"""
                        DELETE FROM {msbte_config.CORRECTION_TYPE}
                        WHERE id=%s {gpdl_course}
                        LIMIT 1
                    """
                    try:
                        params_del = [id_val]
                        cursor.execute(del_sql, params_del)
                        log_query(del_sql, msbte_config.CORRECTION_TYPE, params_del)
                    except Exception as e:
                        logger.exception("chart_del_seat_chart DELETE failed: %s", e)

                try:
                    conn.commit()
                except Exception:
                    pass
                cursor.close()

                return redirect(
                    reverse('dashboard:seating_chart:chart_del_seat_chart')
                    + f'?inst_id={inst_id}&f=del'
                )

        context = {
            'current_exam_label': current_exam_label,
            'inst_id': inst_id,
            'records': records,
            'num': num,
            'success_del': sflg == 'del',
        }
        return render(request, 'seating_chart/chart_del_seat_chart.html', context)

    except Exception as e:
        return handle_report_error(request, e, auth.get('is_jwt', False))

