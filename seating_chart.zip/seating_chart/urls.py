from django.urls import path, include
from . import views

app_name = 'seating_chart'

urlpatterns = [
    path('', views.seating_chart_home, name='seating_chart_home'),
    path('chart-del-seat-chart/', views.chart_del_seat_chart, name='chart_del_seat_chart'),
    path('chart-remove-confirmation-seatno/', views.chart_remove_confirmation_seatno, name='chart_remove_confirmation_seatno'),
    path('seat-chart-remove-institute-confirmation/', views.seat_chart_remove_institute_confirmation, name='seat_chart_remove_institute_confirmation'),
    path('seat-chart-remove-rbte-confirmation/', views.seat_chart_remove_rbte_confirmation, name='seat_chart_remove_rbte_confirmation'),
    path('institute/', include('dashboard.seating_chart.seating_chart_inst.urls')),
    path('rbte/', include('dashboard.seating_chart.seating_chart_rbte.urls')),
]