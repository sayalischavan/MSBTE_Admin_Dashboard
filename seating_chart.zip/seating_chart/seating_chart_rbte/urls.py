from django.urls import path
from . import views

app_name = 'seating_chart_rbte'

urlpatterns = [
    # Seating Chart RBTE reports
    path('rbte_seat_chart_rep/', views.rbte_seat_chart_rep, name='rbte_seat_chart_rep'),
    path('rbte_seat_chart_rep_notconf_inst/', views.rbte_seat_chart_rep_notconf_inst, name='rbte_seat_chart_rep_notconf_inst'),
    path('rbte_seat_chart_rep_next/', views.rbte_seat_chart_rep_next, name='rbte_seat_chart_rep_next'),
    path('rbte_seatingchart_arrangement_index/', views.rbte_seatingchart_arrangement_index, name='rbte_seatingchart_arrangement_index'),
]
