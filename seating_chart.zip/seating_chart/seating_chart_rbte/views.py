from django.shortcuts import render, redirect
from django.http import JsonResponse
from django.db import connections
from django.contrib import messages
from django.urls import reverse
import config.msbte_config as msbte_config
from dashboard.decorators import jwt_report_authorized
import logging
from datetime import datetime
import pandas as pd
from dashboard.utils import (
    get_auth_context,
    get_user_control_info,
    handle_report_error,
    get_db_connection,
    get_city_names_batch,
    get_inst_name,
    get_city_name,
    get_course_name,
    get_region_name,
    get_region_inst,
)
from dashboard.examform.views import _format_inst_code
from dashboard.seating_chart.seating_chart_inst.views import _get_remark_label

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Seating Chart RBTE Reports (PHP: rbte_seat_chart_rep, rbte_seat_chart_rep_next, etc.)
# ---------------------------------------------------------------------------

@jwt_report_authorized(allowed_roles=["RBTE", "ADMIN"])
def rbte_seat_chart_rep(request):
    """
    Seating Chart Correction Report of Institutes for RBTE level.
    PHP: rbte_seat_chart_rep - lists institutes with correction stats (Corrected Cand/s,
    Inst Conf, Inst Not Conf, Final Confirmed, Final Not Conf, RBTE Conf, RBTE Not Conf).
    Links to inst_seat_chart_rep_next with i_code and d for candidate drill-down.
    """
    auth, error = get_auth_context(
        request,
        redirect_url='dashboard:seating_chart:seating_chart_home',
        require_institute=False,
    )
    if error:
        return error

    user_info, err = get_user_control_info(
        request,
        auth,
        allowed_roles=['RBTE', 'ADMIN'],
        require_institute_code=False,
        require_rbte_code=False,
        redirect_url='dashboard:seating_chart:seating_chart_home',
        error_message='You are not authorised to view this report.',
    )
    if err:
        return err

    user_role = (user_info.get('user_role') or auth.get('role') or '').upper()
    uid = user_info.get('uid')
    is_admin = user_info.get('is_admin', False)
    region_id = (request.GET.get('region_id') or request.POST.get('region_id') or '').strip()
    current_exam_label = getattr(msbte_config, 'ACA_NAME_EXAM_S', 'Summer 2026')

    # Build region filter (PHP: region_code by uid or D45 uses region_id)
    region_filter = ""
    params = []
    if is_admin and not region_id:
        region_filter = ""
        params = []
    elif user_role == 'D45' and region_id:
        region_filter = " WHERE region_code = %s"
        params = [region_id]
    elif user_role == 'RBTE' and uid:
        reg_code = str(uid).strip()[-1]  # PHP: SUBSTR($uid,-1) for 005001->1, 005002->2, etc.
        region_filter = " WHERE region_code = %s"
        params = [reg_code]
    else:
        region_filter = " WHERE 1=1"
        params = []

    conn = get_db_connection()
    qrysel = f"SELECT DISTINCT inst_code FROM {msbte_config.CORRECTION_TYPE}{region_filter} ORDER BY inst_code"
    try:
        df_inst = pd.read_sql(qrysel, conn, params=params if params else None)
    except Exception as e:
        logger.exception("rbte_seat_chart_rep institutes query failed: %s", e)
        df_inst = pd.DataFrame()

    report_rows = []
    i = 0
    for _, row in df_inst.iterrows():
        inst_code = row.get('inst_code')
        inst_code_str = str(inst_code).lstrip('0').zfill(4) if inst_code is not None else '0000'
        if inst_code_str == '0000':
            continue
        try:
            inst_code_int = int(str(inst_code).lstrip('0') or 0)
        except (ValueError, TypeError):
            inst_code_int = 0
        inst_name = get_inst_name(inst_code_int) or get_city_name(inst_code_int) or ''

        selconf = f"""
            SELECT
                SUM(IF(cand_conf!='Y' OR cand_conf='Y','1','0')) AS corrected_cands,
                SUM(IF(cand_conf='Y','1','0')) AS cand_conf,
                SUM(IF(cand_conf!='Y' OR cand_conf IS NULL,'1','0')) AS cand_pending,
                SUM(IF(inst_conf='Y','1','0')) AS inst_conf,
                SUM(IF(inst_conf!='Y' OR inst_conf IS NULL,'1','0')) AS inst_not_conf,
                SUM(IF(rbte_conf='Y','1','0')) AS rbte_conf,
                SUM(IF(rbte_conf!='Y' OR rbte_conf IS NULL,'1','0')) AS rbte_not_conf,
                MAX(inst_conf) AS inst_conf1,
                MAX(rbte_conf) AS rbte_conf1
            FROM {msbte_config.CORRECTION_TYPE}
            WHERE inst_code = %s
        """
        try:
            df_cn = pd.read_sql(selconf, conn, params=[inst_code_int])
        except Exception as e:
            logger.warning("rbte_seat_chart_rep stats for inst %s failed: %s", inst_code_str, e)
            continue
        if df_cn.empty:
            continue
        r = df_cn.iloc[0]
        corrected_cands = int(r.get('corrected_cands') or 0)
        cand_conf = int(r.get('cand_conf') or 0)
        cand_pending = int(r.get('cand_pending') or 0)
        inst_conf = int(r.get('inst_conf') or 0)
        inst_not_conf = int(r.get('inst_not_conf') or 0)
        rbte_conf = int(r.get('rbte_conf') or 0)
        rbte_not_conf = int(r.get('rbte_not_conf') or 0)
        inst_conf1 = r.get('inst_conf1')
        rbte_conf1 = r.get('rbte_conf1')
        inst_conf1_str = str(inst_conf1).strip().upper() if inst_conf1 is not None else ''
        rbte_conf1_str = str(rbte_conf1).strip().upper() if rbte_conf1 is not None else ''

        i += 1
        report_rows.append({
            'sr_no': i,
            'inst_code': inst_code_str,
            'inst_name': inst_name,
            'corrected_cands': corrected_cands,
            'cand_conf': cand_conf,
            'cand_pending': cand_pending,
            'inst_conf': inst_conf,
            'inst_not_conf': inst_not_conf,
            'rbte_conf': rbte_conf,
            'rbte_not_conf': rbte_not_conf,
            'inst_conf1': inst_conf1_str,
            'rbte_conf1': rbte_conf1_str,
        })

    return render(request, 'seating_chart_rbte/rbte_seat_chart_rep.html', {
        'current_exam_label': current_exam_label,
        'user_info': user_info,
        'report_rows': report_rows,
        'no_data': len(report_rows) == 0,
    })


@jwt_report_authorized(allowed_roles=["RBTE", "ADMIN"])
def rbte_seat_chart_rep_notconf_inst(request):
    """
    Report of Institutes and RBTE not made Seating Chart Correction Final Confirmation.

    PHP reference: rbte_seat_chart_rep_notconf_inst
    - Lists institutes where:
        inst_conf != 'Y'
        AND inst_conf != 'E'
        AND rbte_conf != 'Y'
    - RBTE users are restricted to their region_code (derived from uid).
    - D45 users pass region_id to filter by region.
    - Admin can optionally filter by region_id, otherwise sees all.
    """
    auth, error = get_auth_context(
        request,
        redirect_url='dashboard:seating_chart:seating_chart_home',
        require_institute=False,
    )
    if error:
        return error

    user_info, err = get_user_control_info(
        request,
        auth,
        allowed_roles=['RBTE', 'ADMIN'],
        require_institute_code=False,
        require_rbte_code=False,
        redirect_url='dashboard:seating_chart:seating_chart_home',
        error_message='You are not authorised to view this report.',
    )
    if err:
        return err

    user_role = (user_info.get('user_role') or auth.get('role') or '').upper()
    uid = user_info.get('uid')
    is_admin = user_info.get('is_admin', False)
    region_id = (request.GET.get('region_id') or request.POST.get('region_id') or '').strip()
    current_exam_label = getattr(msbte_config, 'ACA_NAME_EXAM_S', 'Summer 2026')

    where_clauses = []
    params: list = []

    # Region filter logic similar to PHP:
    # - RBTE: region_code derived from uid (last digit of 005001 -> 1, etc.)
    # - D45: region_code from region_id request param
    # - ADMIN: optional region_id filter, otherwise all regions
    if user_role in ('RBTE') and uid:
        reg_code = str(uid).strip()[-1]
        where_clauses.append("region_code = %s")
        params.append(reg_code)
    elif is_admin and region_id:
        where_clauses.append("region_code = %s")
        params.append(region_id)

    # Business conditions from PHP:
    # inst_conf != 'Y' AND inst_conf != 'E' AND rbte_conf != 'Y'
    where_clauses.append("inst_conf != 'Y'")
    where_clauses.append("inst_conf != 'E'")
    where_clauses.append("rbte_conf != 'Y'")

    where_sql = " AND ".join(where_clauses) if where_clauses else "1=1"

    conn = get_db_connection()
    qrysel = f"""
        SELECT DISTINCT inst_code
        FROM {msbte_config.CORRECTION_TYPE}
        WHERE {where_sql}
        ORDER BY inst_code
    """

    try:
        df_inst = pd.read_sql(qrysel, conn, params=params or None)
    except Exception as e:
        logger.exception("rbte_seat_chart_rep_notconf_inst institutes query failed: %s", e)
        df_inst = pd.DataFrame()

    report_rows = []
    i = 0
    for _, row in df_inst.iterrows():
        inst_code = row.get('inst_code')
        inst_code_str = str(inst_code).lstrip('0').zfill(4) if inst_code is not None else '0000'
        if inst_code_str == '0000':
            continue
        try:
            inst_code_int = int(str(inst_code).lstrip('0') or 0)
        except (ValueError, TypeError):
            inst_code_int = 0

        inst_name = get_inst_name(inst_code_int) or get_city_name(inst_code_int) or ''

        i += 1
        report_rows.append({
            'sr_no': i,
            'inst_code': inst_code_str,
            'inst_name': inst_name,
        })

    return render(request, 'seating_chart_rbte/rbte_seat_chart_rep_notconf_inst.html', {
        'current_exam_label': current_exam_label,
        'user_info': user_info,
        'report_rows': report_rows,
        'no_data': len(report_rows) == 0,
    })


@jwt_report_authorized(allowed_roles=["RBTE", "ADMIN"])
def rbte_seatingchart_arrangement_index(request):
    """
    Seating arrangement for Exam Centers - RBTE level (PHP: rbte_seatingchart_arrangement_index).
    Lists exam centers by region_code with links to:
    - Statistics for Exam Centers (seatingchart_arrangement_ec)
    - Candidates List Papercodewise (seatingchart_arrangement_ec_cand_list)
    """
    auth, error = get_auth_context(
        request,
        redirect_url='dashboard:seating_chart:seating_chart_home',
        require_institute=False,
    )
    if error:
        return error

    user_info, err = get_user_control_info(
        request,
        auth,
        allowed_roles=['RBTE', 'ADMIN'],
        require_institute_code=False,
        require_rbte_code=False,
        redirect_url='dashboard:seating_chart:seating_chart_home',
        error_message='You are not authorised to view this report.',
    )
    if err:
        return err

    user_role = (user_info.get('user_role') or auth.get('role') or '').upper()
    uid = user_info.get('uid')
    is_admin = user_info.get('is_admin', False)
    current_exam_label = getattr(msbte_config, 'ACA_NAME_EXAM_S', 'Summer 2026')

    if user_role not in ('RBTE', 'MSBTE') and not is_admin:
        return render(request, 'seating_chart_rbte/rbte_seatingchart_arrangement_index.html', {
            'current_exam_label': current_exam_label,
            'user_info': user_info,
            'exam_centers': [],
            'no_data': True,
            'error_message': 'You are not a valid user.',
        })

    region_code = str(uid).strip()[-1] if uid else ''
    if not region_code and not is_admin:
        return render(request, 'seating_chart_rbte/rbte_seatingchart_arrangement_index.html', {
            'current_exam_label': current_exam_label,
            'user_info': user_info,
            'exam_centers': [],
            'no_data': True,
            'error_message': 'Region code could not be determined.',
        })

    tbl_seat = getattr(msbte_config, 'SEAT_NO_W25', None)
    if not tbl_seat:
        return render(request, 'seating_chart_rbte/rbte_seatingchart_arrangement_index.html', {
            'current_exam_label': current_exam_label,
            'user_info': user_info,
            'exam_centers': [],
            'no_data': True,
            'error_message': 'Configuration error: SEAT_NO_W25 not found.',
        })

    conn = get_db_connection()
    if is_admin:
        qry = f"SELECT center_code FROM {tbl_seat} GROUP BY center_code ORDER BY center_code"
        params = []
    else:
        qry = f"SELECT center_code FROM {tbl_seat} WHERE region_code = %s GROUP BY center_code ORDER BY center_code"
        params = [region_code]

    try:
        df = pd.read_sql(qry, conn, params=params or None)
    except Exception as e:
        logger.exception("rbte_seatingchart_arrangement_index query failed: %s", e)
        df = pd.DataFrame()

    exam_centers = []
    for i, row in enumerate(df.itertuples(index=False), start=1):
        center_code = getattr(row, 'center_code', None)
        if center_code is None:
            continue
        try:
            center_int = int(str(center_code).lstrip('0') or 0)
        except (ValueError, TypeError):
            center_int = 0
        center_display = str(center_code).lstrip('0').zfill(4) if center_code else '0000'
        center_name = get_inst_name(center_int) or get_city_name(center_int) or ''
        exam_centers.append({
            'sr_no': i,
            'center_code': center_display,
            'center_name': center_name,
            'center_id': center_int,
        })

    return render(request, 'seating_chart_rbte/rbte_seatingchart_arrangement_index.html', {
        'current_exam_label': current_exam_label,
        'user_info': user_info,
        'exam_centers': exam_centers,
        'no_data': len(exam_centers) == 0,
    })


@jwt_report_authorized(allowed_roles=["RBTE", "ADMIN"])
def rbte_seat_chart_rep_next(request):
    """
    Seating Chart Correction Report drill-down for RBTE (PHP: rbte_seat_chart_rep_next).
    Accepts i_code and d (C, CC, CN, IC, IN, RC, RN) from rbte_seat_chart_rep links.
    Uses RBTE-specific canddispstr logic per PHP.
    """
    auth, error = get_auth_context(
        request,
        redirect_url='dashboard:seating_chart:seating_chart_home',
        require_institute=False,
    )
    if error:
        return error

    user_info, err = get_user_control_info(
        request,
        auth,
        allowed_roles=['RBTE', 'ADMIN'],
        require_institute_code=False,
        require_rbte_code=False,
        redirect_url='dashboard:seating_chart:seating_chart_home',
        error_message='You are not authorised to view this report.',
    )
    if err:
        return err

    user_role = (user_info.get('user_role') or auth.get('role') or '').upper()
    uid = user_info.get('uid')
    is_admin = user_info.get('is_admin', False)
    d_param = (request.GET.get('d') or '').strip().upper()
    i_code_param = (request.GET.get('i_code') or '').strip()
    current_exam_label = getattr(msbte_config, 'ACA_NAME_EXAM_S', 'Summer 2026')

    if not i_code_param:
        return render(request, 'seating_chart_rbte/rbte_seat_chart_rep_next.html', {
            'current_exam_label': current_exam_label,
            'user_info': user_info,
            'd_param': d_param,
            'report_rows': [],
            'no_data': True,
            'error_message': 'Institute code (i_code) is required.',
        })

    try:
        inst_code_int = int(str(i_code_param).lstrip('0') or 0)
    except (ValueError, TypeError):
        inst_code_int = 0
    inst_code_display = str(inst_code_int).zfill(4)
    inst_name = get_inst_name(inst_code_int) or get_city_name(inst_code_int) or ''

    # PHP RBTE canddispstr
    if d_param == 'C':
        canddispstr = "AND (ct.cand_conf = 'Y' OR ct.cand_conf = '' OR ct.cand_conf IS NULL)"
    elif d_param == 'CC':
        canddispstr = "AND ct.cand_conf = 'Y'"
    elif d_param == 'CN':
        canddispstr = "AND ct.cand_conf != 'Y' AND (ct.inst_conf != 'Y' OR ct.inst_conf IS NULL) AND (ct.rbte_conf != 'Y' OR ct.rbte_conf IS NULL)"
    elif d_param == 'IC':
        canddispstr = "AND ct.cand_conf = 'Y' AND ct.inst_conf = 'Y'"
    elif d_param == 'IN':
        canddispstr = "AND (ct.inst_conf != 'Y' OR ct.inst_conf IS NULL) AND (ct.rbte_conf != 'Y' OR ct.rbte_conf IS NULL)"
    elif d_param == 'RC':
        canddispstr = "AND ct.cand_conf = 'Y' AND ct.inst_conf = 'Y' AND ct.rbte_conf = 'Y'"
    elif d_param == 'RN':
        canddispstr = "AND (ct.rbte_conf != 'Y' OR ct.rbte_conf IS NULL)"
    else:
        canddispstr = ""

    # str_inst_code: RBTE uses region_code AND inst_code; ADMIN uses inst_code only
    params = []
    if user_role in ('RBTE') and uid:
        # For filtering, use the numeric region_code stored in CORRECTION_TYPE (1-4)
        reg_code_ct = str(uid).strip()[-1]
        str_inst_code = " AND ct.region_code = %s AND ct.inst_code = %s"
        params = [reg_code_ct, inst_code_int]
        # For display, use the full RBTE code from JWT/session (e.g. 5001, 5002, ...)
        rbte_region_code = user_info.get('rbte_code') or uid
        region_name = get_region_name(rbte_region_code) or '-'
    else:
        str_inst_code = " AND ct.inst_code = %s"
        params = [inst_code_int]
        region_name = get_region_name(get_region_inst(inst_code_int)) or '-'

    conn = get_db_connection()
    tbl_ct = msbte_config.CORRECTION_TYPE
    tbl_sc = msbte_config.SEATING_CHART

    query = f"""
        SELECT ct.en_no, sc.name, sc.last_exam_no, sc.last_exam_seatno, sc.status, sc.appear_code,
               ct.add_del, ct.course_code, ct.year_code, ct.master_code, ct.sr_no, ct.correction_type,
               ct.inst_code, ct.region_code, ct.remark_id, ct.seat_no, ct.before_corr, ct.after_corr, ct.remark
        FROM {tbl_ct} ct
        INNER JOIN {tbl_sc} sc ON ct.en_no = sc.enroll_no
            AND ct.course_code = sc.course_code AND ct.year_code = sc.year_code
            AND ct.master_code = sc.master_code AND ct.inst_code = sc.inst_code
        WHERE (sc.block IS NULL OR sc.block NOT IN ('Y','D'))
          AND ct.course_code NOT IN ('CC','EC','MC')
          {canddispstr}
          {str_inst_code}
        GROUP BY ct.en_no, ct.course_code, ct.year_code, ct.master_code, ct.correction_type, ct.add_del,
                 sc.name, sc.last_exam_no, sc.last_exam_seatno, sc.status, sc.appear_code,
                 ct.inst_code, ct.region_code, ct.remark_id, ct.seat_no, ct.before_corr, ct.after_corr, ct.remark, ct.sr_no
        ORDER BY ct.inst_code, ct.en_no, ct.course_code, ct.year_code, ct.master_code, ct.sr_no
    """
    try:
        df = pd.read_sql(query, conn, params=params)
    except Exception as e:
        logger.exception("rbte_seat_chart_rep_next query failed: %s", e)
        return render(request, 'seating_chart_rbte/rbte_seat_chart_rep_next.html', {
            'current_exam_label': current_exam_label,
            'user_info': user_info,
            'd_param': d_param,
            'report_rows': [],
            'no_data': True,
            'error_message': 'Report query failed.',
        })

    if df.empty:
        return render(request, 'seating_chart_rbte/rbte_seat_chart_rep_next.html', {
            'current_exam_label': current_exam_label,
            'user_info': user_info,
            'd_param': d_param,
            'report_rows': [],
            'no_data': True,
            'region_name': region_name,
            'inst_code': inst_code_display,
            'inst_name': inst_name,
        })

    report_rows = []
    for idx, r in df.iterrows():
        en_no = r.get('en_no')
        add_del = r.get('add_del')
        sr_q = f"SELECT sr_no FROM {tbl_ct} WHERE en_no = %s AND add_del = %s ORDER BY sr_no"
        try:
            df_sr = pd.read_sql(sr_q, conn, params=[en_no, add_del])
            sr_list = [str(x) for x in df_sr['sr_no'].tolist() if pd.notna(x)]
            sr_str = ','.join(sr_list) if sr_list else ''
        except Exception:
            sr_str = str(r.get('sr_no') or '')

        cor_type = int(r.get('correction_type') or 0)
        before_corr = r.get('before_corr')
        after_corr = r.get('after_corr')
        if cor_type == 8 and before_corr and after_corr:
            before_display = before_corr
            after_display = after_corr
        else:
            before_display = before_corr or ''
            after_display = after_corr or ''

        if cor_type == 10 and add_del:
            add_del_val = int(add_del) if str(add_del).isdigit() else 0
            if add_del_val == 1:
                add_del_display = 'Added'
            elif add_del_val == 2:
                add_del_display = 'Deleted'
            else:
                add_del_display = 'NA'
        else:
            add_del_display = 'NA'

        if cor_type == 10 and add_del and str(add_del) == '2':
            # Deleted: DB stores one row per deleted subject; after_corr = that deleted subject. Show only deleted subjects.
            after_display = (after_corr or '').strip()
        elif cor_type == 10 and add_del and str(add_del) == '1':
            before_arr = (str(before_corr or '')).split(',')
            after_arr = (str(after_corr or '')).split(',')
            merged = list(dict.fromkeys(before_arr + after_arr))
            merged = [x for x in merged if x]
            after_display = ','.join(merged) if merged else (after_corr or '')

        last_seat = r.get('last_exam_seatno')
        if last_seat is None or str(last_seat) in ('', '0', '000000'):
            last_seat_display = 'NA'
        else:
            last_seat_display = str(last_seat)

        last_exam = r.get('last_exam_no')
        if cor_type == 8 and before_corr:
            last_exam_display = before_corr
        else:
            last_exam_display = last_exam if last_exam else 'NA'

        seat_no_val = r.get('seat_no')
        if seat_no_val is None or str(seat_no_val) in ('', '000000'):
            seat_no_display = 'N/A'
        else:
            seat_no_display = str(seat_no_val)

        remark_label = _get_remark_label(cor_type, r.get('remark_id'))
        other_remark = (r.get('remark') or '').strip() or 'NA'
        deleted_display = '405' if cor_type == 11 else 'NA'

        inst_c = r.get('inst_code')
        trimmed_code = str(inst_c).lstrip('0') if inst_c else ''

        report_rows.append({
            'en_no': str(en_no).lstrip('0') if en_no else '',
            'name': r.get('name') or '',
            'course_code': r.get('course_code') or '',
            'year_code': r.get('year_code') or '',
            'master_code': r.get('master_code') or '',
            'inst_code': trimmed_code,
            'status': r.get('status') or '',
            'appear_code': r.get('appear_code') or '',
            'last_exam': last_exam_display,
            'last_seat': last_seat_display,
            'sr_no_str': sr_str,
            'add_del_display': add_del_display,
            'before_corr': before_display,
            'after_corr': after_display,
            'correction_type': cor_type,
            'remark_label': remark_label,
            'other_remark': other_remark,
            'deleted_display': deleted_display,
            'seat_no': seat_no_display,
        })

    # Merge multiple "Deleted" (type 10, add_del=2) rows for same candidate: one row with all deleted subjects
    merged_rows = []
    pending_deleted = []

    def row_key(row):
        return (row['en_no'], row['course_code'], row['year_code'], row['master_code'])

    def flush_pending():
        nonlocal pending_deleted
        if not pending_deleted:
            return
        first = pending_deleted[0].copy()
        first['after_corr'] = ','.join(
            (r.get('after_corr') or '').strip() for r in pending_deleted if (r.get('after_corr') or '').strip()
        ).strip(',').rstrip(',')
        all_sr = []
        for r in pending_deleted:
            s = (r.get('sr_no_str') or '').strip()
            if s:
                for part in s.replace(' ', '').split(','):
                    if part and part not in all_sr:
                        all_sr.append(part)
        first['sr_no_str'] = ','.join(all_sr) if all_sr else (first.get('sr_no_str') or '')
        merged_rows.append(first)
        pending_deleted = []

    for row in report_rows:
        is_deleted = row['correction_type'] == 10 and str(row.get('add_del_display')) == 'Deleted'
        if is_deleted:
            if pending_deleted and row_key(row) != row_key(pending_deleted[0]):
                flush_pending()
            pending_deleted.append(row)
        else:
            flush_pending()
            merged_rows.append(row)
    flush_pending()
    report_rows = merged_rows

    return render(request, 'seating_chart_rbte/rbte_seat_chart_rep_next.html', {
        'current_exam_label': current_exam_label,
        'user_info': user_info,
        'd_param': d_param,
        'report_rows': report_rows,
        'no_data': False,
        'region_name': region_name,
        'inst_code': inst_code_display,
        'inst_name': inst_name,
        'user_role': user_role,
    })

