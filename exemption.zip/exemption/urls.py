from django.urls import path,include

from . import views

app_name = 'exemption'

urlpatterns = [
    path('', views.exemption_home, name='exemption_home'),
    path('institute/', include(('dashboard.exemption.exemp_inst.urls', 'exemp_inst'))),
    path('rbte/', include(('dashboard.exemption.exempt_rbte.urls', 'exempt_rbte'))),
]

