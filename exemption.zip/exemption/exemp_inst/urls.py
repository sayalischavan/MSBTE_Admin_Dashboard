from django.urls import path
from . import views

app_name = 'exemp_inst'

urlpatterns = [
    # Add exemption institute URLs here 
   path(
        'exemption_candidate_cancel_apply/',
        views.exemption_candidate_cancel_apply,
        name='exemption_candidate_cancel_apply',
    ),
    path(
        'exemption_candidate_cancel_apply/<str:token>/',
        views.exemption_candidate_cancel_apply,
        name='exemption_candidate_cancel_apply_token',
    ),
    path(
        'exemption_statistical_report/',
        views.exemption_statistical_report,
        name='exemption_statistical_report',
    ),
    path(
        'exemption_cand_applied/',
        views.exemption_cand_applied,
        name='exemption_cand_applied',
    ),
    path(
        'exemption_institute_confirmed/',
        views.exemption_institute_confirmed,
        name='exemption_institute_confirmed',
    ),
    path(
        'exemption_institute_confirmed/<str:token>/',
        views.exemption_institute_confirmed,
        name='exemption_institute_confirmed_token',
    ),
     path(
        'exemption_rbte_confirmed/',
        views.exemption_rbte_confirmed,
        name='exemption_rbte_confirmed',
    ),
    path(
        'exemption_rbte_confirmed/<str:token>/',
        views.exemption_rbte_confirmed,
        name='exemption_rbte_confirmed_token',
    ),
     path(
        'exemption_applied_candidate/',
        views.exemption_applied_candidate,
        name='exemption_applied_candidate',
    ),
    path(
    'exemption_applied_candidate_next/',
    views.exemption_applied_candidate_next,
    name='exemption_applied_candidate_next',
    ),
    path(
    'exemption_applied_candidate_next/<str:token>/',
    views.exemption_applied_candidate_next,
    name='exemption_applied_candidate_next_token',
),
path(
    'exemption_rbte_submit_report/',
    views.exemption_rbte_submit_report,
    name='exemption_rbte_submit_report',
),
path(
    'exemption_rbte_submit_report_next/',
    views.exemption_rbte_submit_report_next,
    name='exemption_rbte_submit_report_next',
),
path(
    'exemption_rbte_submit_report_next/<str:token>/',
    views.exemption_rbte_submit_report_next,
    name='exemption_rbte_submit_report_next_token',
),
path(
    'exemption_candidate_rbte_confirm/',
    views.exemption_candidate_rbte_confirm,
    name='exemption_candidate_rbte_confirm',
),
path(
    'exemption_candidate_rbte_confirm_next/',
    views.exemption_candidate_rbte_confirm_next,
    name='exemption_candidate_rbte_confirm_next',
),
path(
    'exemption_candidate_rbte_confirm_next/<str:token>/',
    views.exemption_candidate_rbte_confirm_next,
    name='exemption_candidate_rbte_confirm_next_token',
),

]

