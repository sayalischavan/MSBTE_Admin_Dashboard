from django.shortcuts import render
import logging
from datetime import datetime
import pandas as pd
from django.shortcuts import redirect


import config.msbte_config as msbte_config
from dashboard.decorators import jwt_report_authorized
from dashboard.utils import (
    get_auth_context,
    get_user_control_info,
    handle_report_error,
    get_institute_filter,
    get_db_connection,
)

logger = logging.getLogger(__name__)


@jwt_report_authorized(allowed_roles=['INSTITUTE', 'ADMIN'])
def exemption_candidate_cancel_apply(request):
    """
    Exemption Cancel Candidate Report (PHP reference: exemption applied list)
    Filters by institute (role-based) and date range, lists candidates with their exemption subjects.
    """

    # Step 1: Auth context
    auth, error = get_auth_context(request)
    if error:
        return error

    try:
        # Get user control info using standardized function
        user_info, error = get_user_control_info(
            request, auth,
            allowed_roles=['INSTITUTE', 'ADMIN'],
            require_institute_code=True,
            redirect_url='dashboard:exemption:exemp_inst:exemption_candidate_cancel_apply',
            error_message='You are not authorised user to view this report'
        )
        if error:
            return error

        # Step 2: Inputs (from/to date); optional, but PHP expects them
        from_date = request.GET.get('from_date') or request.POST.get('from_date') or ''
        to_date = request.GET.get('to_date') or request.POST.get('to_date') or ''

        def parse_date(value):
            # accept DD/MM/YYYY or YYYY-MM-DD
            for fmt in ('%d/%m/%Y', '%Y-%m-%d'):
                try:
                    return datetime.strptime(value, fmt).date()
                except (ValueError, TypeError):
                    continue
            return None

        from_date_obj = parse_date(from_date)
        to_date_obj = parse_date(to_date)

               # Step 3: Institute filter (inst_code) – matches PHP role logic
        inst_filter, inst_params = get_institute_filter(user_info['inst_code'])
        
        # Fix ambiguous column by adding table alias
        if inst_filter:
            inst_filter = inst_filter.replace('inst_code', 'e.inst_code')

        # Step 4: Connection
        conn = get_db_connection()

        # Step 5: Main query (mirrors PHP: EXEMPTION_CAND_DETAILS_COPY filtered by inst and date range if provided)
        date_clause = ""
        date_params = []
        if from_date_obj and to_date_obj:
            date_clause = " AND DATE(e.entry_on) >= %s AND DATE(e.entry_on) <= %s "
            date_params = [from_date_obj, to_date_obj]

        main_query = f"""
            SELECT 
                e.enroll_no,
                e.course_id,
                c.name AS candidate_name
            FROM {msbte_config.EXEMPTION_CAND_DETAILS_COPY} e
            LEFT JOIN {msbte_config.CAND_INFO} c
                ON e.enroll_no = c.enroll_no
            WHERE 1=1 {inst_filter} {date_clause}
            ORDER BY e.enroll_no
        """

        df = pd.read_sql(main_query, conn, params=inst_params + date_params)

        candidates = []
        if len(df) > 0:
            df['sr_no'] = range(1, len(df) + 1)

            for _, row in df.iterrows():
                subject_query = f"""
                    SELECT 
                        subject_name,
                        subject_abbr,
                        subject_thpr,
                        paper_code
                    FROM {msbte_config.EXEMPTION_SUBJECT_DETAILS_COPY}
                    WHERE enroll_no = %s
                """
                sub_df = pd.read_sql(subject_query, conn, params=[row['enroll_no']])
                subjects = sub_df.to_dict('records') if len(sub_df) > 0 else []

                candidates.append({
                    'sr_no': row['sr_no'],
                    'enroll_no': row['enroll_no'],
                    'candidate_name': row['candidate_name'],
                    'course_id': row['course_id'],
                    'subjects': subjects,
                })

        context = {
            'report_title': 'Exemption Cancel Candidate Report',
            'candidates': candidates,
            'total_count': len(candidates),
            'from_date': from_date,
            'to_date': to_date,
            'user_name': user_info['user_name'],
            'print_date': datetime.now().strftime('%d/%m/%Y'),
        }

        return render(request, 'exemption_candidate_cancel_apply.html', context)

    except Exception as e:
        logger.exception("Error in exemption_candidate_cancel_apply")
        return handle_report_error(request, e, user_info['is_jwt'])



@jwt_report_authorized(allowed_roles=['INSTITUTE', 'ADMIN'])
def exemption_statistical_report(request):
    """
    Statistical Report for Exemption
    Shows counts for Exemption Applied, Institute Confirmed, and RBTE Confirmed
    """
    # Step 1: Auth context
    auth, error = get_auth_context(request)
    if error:
        return error

    try:
        # Get user control info using standardized function
        user_info, error = get_user_control_info(
            request, auth,
            allowed_roles=['INSTITUTE', 'ADMIN'],
            require_institute_code=True,
            redirect_url='dashboard:exemption:exemp_inst:exemption_statistical_report',
            error_message='You are not authorised user to view this report'
        )
        if error:
            return error

        # Step 2: Institute filter (inst_code) – matches PHP role logic
        inst_filter, inst_params = get_institute_filter(user_info['inst_code'])

        # Step 3: Connection
        conn = get_db_connection()

        # Step 4: Query counts
        # Count 1: Exemption Applied (all records)
        applied_query = f"""
            SELECT COUNT(DISTINCT enroll_no) as count_en 
            FROM {msbte_config.EXEMPTION_CAND_DETAILS}
            WHERE 1=1 {inst_filter}
        """
        applied_df = pd.read_sql(applied_query, conn, params=inst_params)
        applied_count = int(applied_df.iloc[0]['count_en']) if len(applied_df) > 0 else 0

        # Count 2: Exemption Institute Confirmed
        inst_conf_query = f"""
            SELECT COUNT(DISTINCT enroll_no) as count_en 
            FROM {msbte_config.EXEMPTION_CAND_DETAILS}
            WHERE inst_conf='Y' {inst_filter}
        """
        inst_conf_df = pd.read_sql(inst_conf_query, conn, params=inst_params)
        inst_conf_count = int(inst_conf_df.iloc[0]['count_en']) if len(inst_conf_df) > 0 else 0

        # Count 3: Exemption RBTE Confirmed
        rbte_conf_query = f"""
            SELECT COUNT(DISTINCT enroll_no) as count_en 
            FROM {msbte_config.EXEMPTION_CAND_DETAILS}
            WHERE inst_conf='Y' AND rbte_conf='Y' {inst_filter}
        """
        rbte_conf_df = pd.read_sql(rbte_conf_query, conn, params=inst_params)
        rbte_conf_count = int(rbte_conf_df.iloc[0]['count_en']) if len(rbte_conf_df) > 0 else 0

        context = {
            'report_title': 'Statistical Report for Exemption',
            'applied_count': applied_count,
            'inst_conf_count': inst_conf_count,
            'rbte_conf_count': rbte_conf_count,
            'user_name': user_info['user_name'],
            'print_date': datetime.now().strftime('%d/%m/%Y'),
        }

        return render(request, 'exemption_statistical_report.html', context)

    except Exception as e:
        logger.exception("Error in exemption_statistical_report")
        return handle_report_error(request, e, user_info['is_jwt'])


@jwt_report_authorized(allowed_roles=['INSTITUTE', 'ADMIN'])
def exemption_cand_applied(request):
    """
    Exemption Applied Candidates Report
    Lists all candidates who have applied for exemption (PHP reference: exemption_cand_applied)
    """
    # Step 1: Auth context
    auth, error = get_auth_context(request)
    if error:
        return error

    try:
        # Get user control info using standardized function
        user_info, error = get_user_control_info(
            request, auth,
            allowed_roles=['INSTITUTE', 'ADMIN'],
            require_institute_code=True,
            redirect_url='dashboard:exemption:exemp_inst:exemption_cand_applied',
            error_message='You are not authorised user to view this report'
        )
        if error:
            return error

        # Step 2: Institute filter (inst_code) – matches PHP role logic
        inst_filter, inst_params = get_institute_filter(user_info['inst_code'])

        # Fix ambiguous column by adding table alias
        if inst_filter:
            inst_filter = inst_filter.replace('inst_code', 'e.inst_code')

        # Step 3: Connection
        conn = get_db_connection()

        # Step 4: Main query (mirrors PHP: EXEMPTION_CAND_DETAILS filtered by inst_code)
        main_query = f"""
            SELECT 
                e.enroll_no,
                e.course_id,
                c.name AS candidate_name,
                e.entry_on
            FROM {msbte_config.EXEMPTION_CAND_DETAILS} e
            LEFT JOIN {msbte_config.CAND_INFO} c
                ON e.enroll_no = c.enroll_no
            WHERE 1=1 {inst_filter}
            ORDER BY e.enroll_no
        """

        df = pd.read_sql(main_query, conn, params=inst_params)

        candidates = []
        if len(df) > 0:
            df['sr_no'] = range(1, len(df) + 1)

            # Convert entry_on to string to preserve exact database format
            # Handle both datetime objects and string values
            if 'entry_on' in df.columns:
                df['entry_on'] = df['entry_on'].apply(
                    lambda x: str(x) if pd.notna(x) else None
                )

            for _, row in df.iterrows():
                subject_query = f"""
                    SELECT 
                        subject_name,
                        subject_abbr,
                        subject_thpr,
                        paper_code
                    FROM {msbte_config.ELG_EXEMPTION_DETAILS}
                    WHERE enroll_no = %s
                """
                sub_df = pd.read_sql(subject_query, conn, params=[row['enroll_no']])
                subjects = sub_df.to_dict('records') if len(sub_df) > 0 else []

                candidates.append({
                    'sr_no': row['sr_no'],
                    'enroll_no': row['enroll_no'],
                    'candidate_name': row['candidate_name'],
                    'course_id': row['course_id'],
                    'subjects': subjects,
                    'entry_on': row['entry_on'] if pd.notna(row['entry_on']) else None,
                })

        context = {
            'report_title': 'Exemption Applied Candidates Report',
            'candidates': candidates,
            'total_count': len(candidates),
            'user_name': user_info['user_name'],
            'print_date': datetime.now().strftime('%d/%m/%Y'),
        }

        return render(request, 'exemption_cand_applied.html', context)

    except Exception as e:
        logger.exception("Error in exemption_cand_applied")
        return handle_report_error(request, e, user_info['is_jwt'])



@jwt_report_authorized(allowed_roles=['INSTITUTE', 'ADMIN'])
def exemption_institute_confirmed(request):
    """
    Exemption Institute Confirmed Candidates Report
    Lists all candidates who have been confirmed by institute (inst_conf='Y')
    PHP reference: exemption institute confirmed report
    """
    # Step 1: Auth context
    auth, error = get_auth_context(request)
    if error:
        return error

    try:
        # Step 2: Inputs (from/to date); optional
        from_date = request.GET.get('from_date') or request.POST.get('from_date') or ''
        to_date = request.GET.get('to_date') or request.POST.get('to_date') or ''

        def parse_date(value):
            # accept DD/MM/YYYY or YYYY-MM-DD
            for fmt in ('%d/%m/%Y', '%Y-%m-%d'):
                try:
                    return datetime.strptime(value, fmt).date()
                except (ValueError, TypeError):
                    continue
            return None

        from_date_obj = parse_date(from_date)
        to_date_obj = parse_date(to_date)

        # Get user control info using standardized function
        user_info, error = get_user_control_info(
            request, auth,
            allowed_roles=['INSTITUTE', 'ADMIN'],
            require_institute_code=True,
            redirect_url='dashboard:exemption:exemp_inst:exemption_institute_confirmed',
            error_message='You are not authorised user to view this report'
        )
        if error:
            return error

        # Step 3: Institute filter (inst_code) – matches PHP role logic
        inst_filter, inst_params = get_institute_filter(user_info['inst_code'])

        # Fix ambiguous column by adding table alias
        if inst_filter:
            inst_filter = inst_filter.replace('inst_code', 'e.inst_code')

        # Step 4: Connection
        conn = get_db_connection()

        # Step 5: Main query (mirrors PHP: EXEMPTION_CAND_DETAILS where inst_conf='Y')
        date_clause = ""
        date_params = []
        if from_date_obj and to_date_obj:
            date_clause = " AND DATE(e.inst_conf_on) >= %s AND DATE(e.inst_conf_on) <= %s "
            date_params = [from_date_obj, to_date_obj]

        main_query = f"""
            SELECT 
                e.enroll_no,
                e.course_id,
                c.name AS candidate_name,
                e.inst_conf_on
            FROM {msbte_config.EXEMPTION_CAND_DETAILS} e
            LEFT JOIN {msbte_config.CAND_INFO} c
                ON e.enroll_no = c.enroll_no
            WHERE e.inst_conf = 'Y' {inst_filter} {date_clause}
            ORDER BY e.enroll_no
        """

        df = pd.read_sql(main_query, conn, params=inst_params + date_params)

        candidates = []
        if len(df) > 0:
            df['sr_no'] = range(1, len(df) + 1)

            # Convert inst_conf_on to string to preserve exact database format
            if 'inst_conf_on' in df.columns:
                df['inst_conf_on'] = df['inst_conf_on'].apply(
                    lambda x: str(x) if pd.notna(x) else None
                )

            # Batch fetch course details
            unique_course_ids = df['course_id'].dropna().unique().tolist()
            course_lookup = {}
            if unique_course_ids:
                course_ids_str = ','.join([str(int(cid)) for cid in unique_course_ids if pd.notna(cid)])
                if course_ids_str:
                    course_query = f"""
                        SELECT course_id, course_name, course_code 
                        FROM {msbte_config.COURSES1} 
                        WHERE course_id IN ({course_ids_str})
                    """
                    course_df = pd.read_sql(course_query, conn)
                    for _, crow in course_df.iterrows():
                        course_lookup[int(crow['course_id'])] = {
                            'name': crow['course_name'],
                            'code': crow['course_code']
                        }

            for _, row in df.iterrows():
                # Get course code and name
                course_display = '-'
                if pd.notna(row['course_id']) and int(row['course_id']) in course_lookup:
                    course_info = course_lookup[int(row['course_id'])]
                    course_display = f"{course_info['code']}-{course_info['name']}"

                # Get exemption subjects
                subject_query = f"""
                    SELECT 
                        subject_name,
                        subject_abbr,
                        subject_thpr,
                        paper_code
                    FROM {msbte_config.ELG_EXEMPTION_DETAILS}
                    WHERE enroll_no = %s
                """
                sub_df = pd.read_sql(subject_query, conn, params=[row['enroll_no']])
                subjects = sub_df.to_dict('records') if len(sub_df) > 0 else []

                candidates.append({
                    'sr_no': row['sr_no'],
                    'enroll_no': row['enroll_no'],
                    'candidate_name': row['candidate_name'],
                    'course_id': course_display,
                    'subjects': subjects,
                    'inst_conf_on': row['inst_conf_on'] if pd.notna(row['inst_conf_on']) else None,
                })

        context = {
            'report_title': 'Exemption Institute Confirmed Candidates Report',
            'candidates': candidates,
            'total_count': len(candidates),
            'from_date': from_date,
            'to_date': to_date,
            'user_name': user_info['user_name'],
            'print_date': datetime.now().strftime('%d/%m/%Y'),
        }

        return render(request, 'exemption_institute_confirmed.html', context)

    except Exception as e:
        logger.exception("Error in exemption_institute_confirmed")
        return handle_report_error(request, e, user_info['is_jwt'])


@jwt_report_authorized(allowed_roles=['INSTITUTE', 'ADMIN', 'RBTE', 'SUBRBTE', 'MSBTE'])
def exemption_rbte_confirmed(request):
    """
    Exemption RBTE Confirmed Candidates Report
    Lists all candidates who have been confirmed by both institute and RBTE (inst_conf='Y' AND rbte_conf='Y')
    PHP reference: exemption RBTE confirm report
    """
    # Step 1: Auth context
    auth, error = get_auth_context(request)
    if error:
        return error

    try:
        # Step 2: Inputs (from/to date); optional - matches PHP date parsing
        from_date = request.GET.get('from_date') or request.POST.get('from_date') or ''
        to_date = request.GET.get('to_date') or request.POST.get('to_date') or ''

        def parse_date(value):
            # PHP: substr($from_date,6,4)."-".substr($from_date,3,2)."-".substr($from_date,0,2)
            # Accepts DD/MM/YYYY format and converts to YYYY-MM-DD
            if not value:
                return None
            for fmt in ('%d/%m/%Y', '%Y-%m-%d'):
                try:
                    dt = datetime.strptime(value, fmt)
                    return dt.date()
                except (ValueError, TypeError):
                    continue
            return None

        from_date_obj = parse_date(from_date)
        to_date_obj = parse_date(to_date)

        # Get user control info using standardized function
        user_info, error = get_user_control_info(
            request, auth,
            allowed_roles=['INSTITUTE', 'ADMIN', 'RBTE', 'SUBRBTE', 'MSBTE'],
            require_institute_code=True,
            redirect_url='dashboard:exemption:exemp_inst:exemption_rbte_confirmed',
            error_message='You are not authorised user to view this report'
        )
        if error:
            return error

        # Step 3: Institute filter (inst_code) – matches PHP role logic
        inst_filter, inst_params = get_institute_filter(user_info['inst_code'])

        # Fix ambiguous column by adding table alias
        if inst_filter:
            inst_filter = inst_filter.replace('inst_code', 'e.inst_code')

        # Step 4: Connection
        conn = get_db_connection()

        # Step 5: Get institute info for display (matches PHP: get_region_inst and get_region_name)
        inst_code = user_info['inst_code']
        inst_code_int = int(float(inst_code)) if inst_code else None
        inst_name = ""
        city_name = ""
        region_name = ""
        reg_id = None
        inst_code_formatted = ""
        
        if inst_code_int:
            # Fetch institute details from INSTITUTES table
            inst_query = f"""
                SELECT inst_id, inst_name, city_name, reg_code
                FROM {msbte_config.INSTITUTES}
                WHERE inst_id = %s
                LIMIT 1
            """
            df_inst = pd.read_sql(inst_query, conn, params=[inst_code_int])

            if len(df_inst) > 0:
                # Get institute code from table (inst_id) and format it
                inst_id_from_table = int(df_inst.iloc[0]['inst_id'])
                inst_code_formatted = str(inst_id_from_table).zfill(4)  # Format as 0000116
                
                # Get institute name (prefer inst_name, fallback to city_name)
                inst_name = df_inst.iloc[0]['inst_name'] if pd.notna(df_inst.iloc[0]['inst_name']) else ""
                city_name = df_inst.iloc[0]['city_name'] if pd.notna(df_inst.iloc[0]['city_name']) else ""
                
                # If inst_name is empty, use city_name
                if not inst_name:
                    inst_name = city_name
                # Get region code (reg_code) from institute - this is the region_id
                if pd.notna(df_inst.iloc[0]['reg_code']):
                    reg_id = int(float(df_inst.iloc[0]['reg_code']))
                    # Get region name from REGION_MASTER table if available, otherwise use mapping
                    try:
                        region_query = f"""
                            SELECT region_name 
                            FROM {msbte_config.REGION_MASTER}
                            WHERE reg_code = %s
                            LIMIT 1
                        """
                        df_region = pd.read_sql(region_query, conn, params=[reg_id])
                        if len(df_region) > 0 and pd.notna(df_region.iloc[0]['region_name']):
                            region_name = df_region.iloc[0]['region_name']
                    except:
                        pass
                     # Fallback to mapping if region_name not found
                    if not region_name:
                        region_code_map = {
                            5001: 'Mumbai',
                            5002: 'Pune',
                            5003: 'Nagpur',
                            5004: 'Chhatrapati Sambhaji Nagar (CSN)',
                        }
                        region_name = region_code_map.get(reg_id, '')

        # Step 6: Get Academic Year in YYYY-YYYY format
        # Extract from ACA_YEAR (e.g., "Academic Year 2025 - 26" -> "2025-2026")
        aca_year = getattr(msbte_config, 'ACA_YEAR', '')
        academic_year = ""
        if aca_year:
            # Extract year from "Academic Year 2025 - 26"
            import re
            match = re.search(r'(\d{4})\s*-\s*(\d{2})', aca_year)
            if match:
                year1 = match.group(1)  # 2025
                year2_short = match.group(2)  # 26
                # Convert 26 to 2026
                year2 = f"20{year2_short}" if len(year2_short) == 2 else year2_short
                academic_year = f"{year1}-{year2}"
            else:
                # Fallback: calculate from current year
                current_year = datetime.now().year
                academic_year = f"{current_year}-{current_year + 1}"
        else:
            # Fallback: calculate from current year
            current_year = datetime.now().year
            academic_year = f"{current_year}-{current_year + 1}"

        # Step 7: Main query (mirrors PHP: EXEMPTION_CAND_DETAILS where inst_conf='Y' AND rbte_conf='Y')
        date_clause = ""
        date_params = []
        if from_date_obj and to_date_obj:
            date_clause = " AND DATE(e.rbte_conf_on) >= %s AND DATE(e.rbte_conf_on) <= %s "
            date_params = [from_date_obj, to_date_obj]

        main_query = f"""
            SELECT 
                e.enroll_no,
                e.course_id,
                c.name AS candidate_name,
                e.rbte_conf_on
            FROM {msbte_config.EXEMPTION_CAND_DETAILS} e
            LEFT JOIN {msbte_config.CAND_INFO} c
                ON e.enroll_no = c.enroll_no
            WHERE e.inst_conf = 'Y' AND e.rbte_conf = 'Y' {inst_filter} {date_clause}
            ORDER BY e.enroll_no
        """

        df = pd.read_sql(main_query, conn, params=inst_params + date_params)

        candidates = []
        if len(df) > 0:
            df['sr_no'] = range(1, len(df) + 1)

            # Convert rbte_conf_on to string to preserve exact database format
            if 'rbte_conf_on' in df.columns:
                df['rbte_conf_on'] = df['rbte_conf_on'].apply(
                    lambda x: str(x) if pd.notna(x) else None
                )

            # Batch fetch course details
            unique_course_ids = df['course_id'].dropna().unique().tolist()
            course_lookup = {}
            if unique_course_ids:
                course_ids_str = ','.join([str(int(cid)) for cid in unique_course_ids if pd.notna(cid)])
                if course_ids_str:
                    course_query = f"""
                        SELECT course_id, course_name, course_code 
                        FROM {msbte_config.COURSES1} 
                        WHERE course_id IN ({course_ids_str})
                    """
                    course_df = pd.read_sql(course_query, conn)
                    for _, crow in course_df.iterrows():
                        course_lookup[int(crow['course_id'])] = {
                            'name': crow['course_name'],
                            'code': crow['course_code']
                        }

            for _, row in df.iterrows():
                # Get course code and name
                course_display = '-'
                if pd.notna(row['course_id']) and int(row['course_id']) in course_lookup:
                    course_info = course_lookup[int(row['course_id'])]
                    course_display = f"{course_info['code']}-{course_info['name']}"

                # Get exemption subjects
                subject_query = f"""
                    SELECT 
                        subject_name,
                        subject_abbr,
                        subject_thpr,
                        paper_code
                    FROM {msbte_config.ELG_EXEMPTION_DETAILS}
                    WHERE enroll_no = %s
                """
                sub_df = pd.read_sql(subject_query, conn, params=[row['enroll_no']])
                subjects = sub_df.to_dict('records') if len(sub_df) > 0 else []

                candidates.append({
                    'sr_no': row['sr_no'],
                    'enroll_no': row['enroll_no'],
                    'candidate_name': row['candidate_name'],
                    'course_id': course_display,
                    'subjects': subjects,
                    'rbte_conf_on': row['rbte_conf_on'] if pd.notna(row['rbte_conf_on']) else None,
                })

        # Get current date for document reference (DD-MM-YYYY format)
        current_date = datetime.now().strftime('%d-%m-%Y')

        context = {
            'report_title': 'Exemption RBTE Confirmed Candidates Report',
            'candidates': candidates,
            'total_count': len(candidates),
            'from_date': from_date,
            'to_date': to_date,
            'inst_code': inst_code,
            'inst_code_formatted': inst_code_formatted,
            'inst_name': inst_name,
            'city_name': city_name,
            'region_name': region_name,
            'reg_id': reg_id,
            'academic_year': academic_year,
            'user_name': user_info['user_name'],
            'print_date': datetime.now().strftime('%d/%m/%Y'),
            'current_date': current_date,
        }

        return render(request, 'exemption_rbte_confirmed.html', context)

    except Exception as e:
        logger.exception("Error in exemption_rbte_confirmed")
        return handle_report_error(request, e, user_info['is_jwt'])


@jwt_report_authorized(allowed_roles=['INSTITUTE', 'ADMIN'])
def exemption_applied_candidate(request):
    """
    Form for selecting date range to view Exemption Applied Candidates
    PHP reference: exemption_applied_candidate
    """
    auth, error = get_auth_context(request)
    if error:
        return error

    context = {
        'form_title': 'Consolidate Report for Exemption Applied Candidate',
    }
    return render(request, 'exemption_applied_candidate_form.html', context)

@jwt_report_authorized(allowed_roles=['INSTITUTE', 'ADMIN'])
def exemption_applied_candidate_next(request):
    """
    Exemption Applied Candidates Report with Date Range Filter
    PHP reference: exemption_applied_candidate_next
    Lists candidates who applied for exemption within the specified date range
    """
    # Step 1: Auth context
    auth, error = get_auth_context(request)
    if error:
        return error

    try:
        # Step 2: Get date range from request (required)
        from_date = request.GET.get('from_date') or request.POST.get('from_date') or ''
        to_date = request.GET.get('to_date') or request.POST.get('to_date') or ''

        # Validate that dates are provided
        if not from_date or not to_date:
            from django.contrib import messages
            messages.error(request, 'Please select both From Date and To Date.')
            return redirect('dashboard:exemption:exemp_inst:exemption_applied_candidate')

        def parse_date(value):
            # PHP: substr($from_date,6,4)."-".substr($from_date,3,2)."-".substr($from_date,0,2)
            # Accepts DD/MM/YYYY format and converts to YYYY-MM-DD
            if not value:
                return None
            for fmt in ('%d/%m/%Y', '%Y-%m-%d'):
                try:
                    return datetime.strptime(value, fmt).date()
                except (ValueError, TypeError):
                    continue
            return None

        from_date_obj = parse_date(from_date)
        to_date_obj = parse_date(to_date)

        if not from_date_obj or not to_date_obj:
            from django.contrib import messages
            messages.error(request, 'Invalid date format. Please use DD/MM/YYYY format.')
            return redirect('dashboard:exemption:exemp_inst:exemption_applied_candidate')

        # Get user control info using standardized function
        user_info, error = get_user_control_info(
            request, auth,
            allowed_roles=['INSTITUTE', 'ADMIN'],
            require_institute_code=True,
            redirect_url='dashboard:exemption:exemp_inst:exemption_applied_candidate',
            error_message='You are not authorised user to view this report'
        )
        if error:
            return error

        # Step 3: Institute filter (inst_code) – matches PHP role logic
        inst_filter, inst_params = get_institute_filter(user_info['inst_code'])

        # Fix ambiguous column by adding table alias
        if inst_filter:
            inst_filter = inst_filter.replace('inst_code', 'e.inst_code')

        # Step 4: Connection
        conn = get_db_connection()

        # Step 5: Main query with date filtering (required)
        # PHP: where inst_code=? and (date(entry_on)>=? and date(entry_on)<=?)
        main_query = f"""
            SELECT 
                e.enroll_no,
                e.course_id,
                c.name AS candidate_name,
                e.entry_on
            FROM {msbte_config.EXEMPTION_CAND_DETAILS} e
            LEFT JOIN {msbte_config.CAND_INFO} c
                ON e.enroll_no = c.enroll_no
            WHERE 1=1 {inst_filter} 
                AND DATE(e.entry_on) >= %s 
                AND DATE(e.entry_on) <= %s
            ORDER BY e.enroll_no
        """

        df = pd.read_sql(main_query, conn, params=inst_params + [from_date_obj, to_date_obj])

        candidates = []
        if len(df) > 0:
            df['sr_no'] = range(1, len(df) + 1)

            # Convert entry_on to string to preserve exact database format
            if 'entry_on' in df.columns:
                df['entry_on'] = df['entry_on'].apply(
                    lambda x: str(x) if pd.notna(x) else None
                )

            # Batch fetch course details
            unique_course_ids = df['course_id'].dropna().unique().tolist()
            course_lookup = {}
            if unique_course_ids:
                course_ids_str = ','.join([str(int(cid)) for cid in unique_course_ids if pd.notna(cid)])
                if course_ids_str:
                    course_query = f"""
                        SELECT course_id, course_name, course_code 
                        FROM {msbte_config.COURSES1} 
                        WHERE course_id IN ({course_ids_str})
                    """
                    course_df = pd.read_sql(course_query, conn)
                    for _, crow in course_df.iterrows():
                        course_lookup[int(crow['course_id'])] = {
                            'name': crow['course_name'],
                            'code': crow['course_code']
                        }

            for _, row in df.iterrows():
                # Get course code and name
                course_display = '-'
                if pd.notna(row['course_id']) and int(row['course_id']) in course_lookup:
                    course_info = course_lookup[int(row['course_id'])]
                    course_display = f"{course_info['code']}-{course_info['name']}"

                # Get exemption subjects
                subject_query = f"""
                    SELECT 
                        subject_name,
                        subject_abbr,
                        subject_thpr,
                        paper_code
                    FROM {msbte_config.ELG_EXEMPTION_DETAILS}
                    WHERE enroll_no = %s
                """
                sub_df = pd.read_sql(subject_query, conn, params=[row['enroll_no']])
                subjects = sub_df.to_dict('records') if len(sub_df) > 0 else []

                candidates.append({
                    'sr_no': row['sr_no'],
                    'enroll_no': row['enroll_no'],
                    'candidate_name': row['candidate_name'],
                    'course_id': course_display,
                    'subjects': subjects,
                    'entry_on': row['entry_on'] if pd.notna(row['entry_on']) else None,
                })

        # Get Academic Year for header
        aca_year = getattr(msbte_config, 'ACA_YEAR', '')
        academic_year = ""
        if aca_year:
            import re
            match = re.search(r'(\d{4})\s*-\s*(\d{2})', aca_year)
            if match:
                year1 = match.group(1)
                year2_short = match.group(2)
                year2 = f"20{year2_short}" if len(year2_short) == 2 else year2_short
                academic_year = f"{year1}-{year2}"
            else:
                current_year = datetime.now().year
                academic_year = f"{current_year}-{current_year + 1}"
        else:
            current_year = datetime.now().year
            academic_year = f"{current_year}-{current_year + 1}"

        context = {
            'report_title': 'Exemption Applied Candidates Report',
            'candidates': candidates,
            'total_count': len(candidates),
            'from_date': from_date,
            'to_date': to_date,
            'academic_year': academic_year,
            'user_name': user_info['user_name'],
            'print_date': datetime.now().strftime('%d/%m/%Y'),
        }

        return render(request, 'exemption_applied_candidate_next.html', context)

    except Exception as e:
        logger.exception("Error in exemption_applied_candidate_next")
        return handle_report_error(request, e, user_info['is_jwt'])


@jwt_report_authorized(allowed_roles=['INSTITUTE', 'ADMIN'])
def exemption_rbte_submit_report(request):
    """
    Form for selecting date range to view Exemption Institute Confirmed Candidates
    PHP reference: exemption_rbte_submit_report
    """
    auth, error = get_auth_context(request)
    if error:
        return error

    context = {
        'form_title': 'Consolidate Report for Exemption Institute Confirm Candidate',
    }
    return render(request, 'exemption_rbte_submit_report_form.html', context)


@jwt_report_authorized(allowed_roles=['INSTITUTE', 'ADMIN'])
def exemption_rbte_submit_report_next(request):
    """
    Exemption Institute Confirmed Candidates Report with Date Range Filter
    PHP reference: exemption_rbte_submit_report_next
    Lists candidates confirmed by institute within the specified date range
    """
    # Step 1: Auth context
    auth, error = get_auth_context(request)
    if error:
        return error

    try:
        # Step 2: Get date range from request (required)
        from_date = request.GET.get('from_date') or request.POST.get('from_date') or ''
        to_date = request.GET.get('to_date') or request.POST.get('to_date') or ''

        # Validate that dates are provided
        if not from_date or not to_date:
            from django.contrib import messages
            from django.shortcuts import redirect
            messages.error(request, 'Please select both From Date and To Date.')
            return redirect('dashboard:exemption:exemp_inst:exemption_rbte_submit_report')

        def parse_date(value):
            # PHP: substr($from_date,6,4)."-".substr($from_date,3,2)."-".substr($from_date,0,2)
            # Accepts DD/MM/YYYY format and converts to YYYY-MM-DD
            if not value:
                return None
            for fmt in ('%d/%m/%Y', '%Y-%m-%d'):
                try:
                    return datetime.strptime(value, fmt).date()
                except (ValueError, TypeError):
                    continue
            return None

        from_date_obj = parse_date(from_date)
        to_date_obj = parse_date(to_date)

        if not from_date_obj or not to_date_obj:
            from django.contrib import messages
            from django.shortcuts import redirect
            messages.error(request, 'Invalid date format. Please use DD/MM/YYYY format.')
            return redirect('dashboard:exemption:exemp_inst:exemption_rbte_submit_report')

        # Get user control info using standardized function
        user_info, error = get_user_control_info(
            request, auth,
            allowed_roles=['INSTITUTE', 'ADMIN'],
            require_institute_code=True,
            redirect_url='dashboard:exemption:exemp_inst:exemption_rbte_submit_report',
            error_message='You are not authorised user to view this report'
        )
        if error:
            return error

        # Step 3: Institute filter (inst_code) – matches PHP role logic
        inst_filter, inst_params = get_institute_filter(user_info['inst_code'])

        # Fix ambiguous column by adding table alias
        if inst_filter:
            inst_filter = inst_filter.replace('inst_code', 'e.inst_code')

        # Step 4: Connection
        conn = get_db_connection()

        # Step 5: Main query with date filtering (required)
        # PHP: where inst_code=? and inst_conf='Y' and (date(inst_conf_on)>=? and date(inst_conf_on)<=?)
        main_query = f"""
            SELECT 
                e.enroll_no,
                e.course_id,
                c.name AS candidate_name,
                e.inst_conf_on
            FROM {msbte_config.EXEMPTION_CAND_DETAILS} e
            LEFT JOIN {msbte_config.CAND_INFO} c
                ON e.enroll_no = c.enroll_no
            WHERE e.inst_conf = 'Y' {inst_filter} 
                AND DATE(e.inst_conf_on) >= %s 
                AND DATE(e.inst_conf_on) <= %s
            ORDER BY e.enroll_no
        """

        df = pd.read_sql(main_query, conn, params=inst_params + [from_date_obj, to_date_obj])

        candidates = []
        if len(df) > 0:
            df['sr_no'] = range(1, len(df) + 1)

            # Convert inst_conf_on to string to preserve exact database format
            if 'inst_conf_on' in df.columns:
                df['inst_conf_on'] = df['inst_conf_on'].apply(
                    lambda x: str(x) if pd.notna(x) else None
                )

            # Batch fetch course details
            unique_course_ids = df['course_id'].dropna().unique().tolist()
            course_lookup = {}
            if unique_course_ids:
                course_ids_str = ','.join([str(int(cid)) for cid in unique_course_ids if pd.notna(cid)])
                if course_ids_str:
                    course_query = f"""
                        SELECT course_id, course_name, course_code 
                        FROM {msbte_config.COURSES1} 
                        WHERE course_id IN ({course_ids_str})
                    """
                    course_df = pd.read_sql(course_query, conn)
                    for _, crow in course_df.iterrows():
                        course_lookup[int(crow['course_id'])] = {
                            'name': crow['course_name'],
                            'code': crow['course_code']
                        }

            for _, row in df.iterrows():
                # Get course code and name
                course_display = '-'
                if pd.notna(row['course_id']) and int(row['course_id']) in course_lookup:
                    course_info = course_lookup[int(row['course_id'])]
                    course_display = f"{course_info['code']}-{course_info['name']}"

                # Get exemption subjects
                subject_query = f"""
                    SELECT 
                        subject_name,
                        subject_abbr,
                        subject_thpr,
                        paper_code
                    FROM {msbte_config.ELG_EXEMPTION_DETAILS}
                    WHERE enroll_no = %s
                """
                sub_df = pd.read_sql(subject_query, conn, params=[row['enroll_no']])
                subjects = sub_df.to_dict('records') if len(sub_df) > 0 else []

                candidates.append({
                    'sr_no': row['sr_no'],
                    'enroll_no': row['enroll_no'],
                    'candidate_name': row['candidate_name'],
                    'course_id': course_display,
                    'subjects': subjects,
                    'inst_conf_on': row['inst_conf_on'] if pd.notna(row['inst_conf_on']) else None,
                })

        # Get Academic Year for header
        aca_year = getattr(msbte_config, 'ACA_YEAR', '')
        academic_year = ""
        if aca_year:
            import re
            match = re.search(r'(\d{4})\s*-\s*(\d{2})', aca_year)
            if match:
                year1 = match.group(1)
                year2_short = match.group(2)
                year2 = f"20{year2_short}" if len(year2_short) == 2 else year2_short
                academic_year = f"{year1}-{year2}"
            else:
                current_year = datetime.now().year
                academic_year = f"{current_year}-{current_year + 1}"
        else:
            current_year = datetime.now().year
            academic_year = f"{current_year}-{current_year + 1}"

        context = {
            'report_title': 'Exemption Institute Confirmed Candidates Report',
            'candidates': candidates,
            'total_count': len(candidates),
            'from_date': from_date,
            'to_date': to_date,
            'academic_year': academic_year,
            'user_name': user_info['user_name'],
            'print_date': datetime.now().strftime('%d/%m/%Y'),
        }

        return render(request, 'exemption_rbte_submit_report_next.html', context)

    except Exception as e:
        logger.exception("Error in exemption_rbte_submit_report_next")
        return handle_report_error(request, e, user_info['is_jwt'])


@jwt_report_authorized(allowed_roles=['INSTITUTE', 'ADMIN'])
def exemption_candidate_rbte_confirm(request):
    """
    Form for selecting date range to view Exemption RBTE Confirmed Candidates
    PHP reference: exemption_candidate_rbte_confirm
    """
    auth, error = get_auth_context(request)
    if error:
        return error

    context = {
        'form_title': 'Consolidate Report for Exemption Applied Candidate',
    }
    return render(request, 'exemption_candidate_rbte_confirm_form.html', context)

@jwt_report_authorized(allowed_roles=['INSTITUTE', 'ADMIN'])
def exemption_candidate_rbte_confirm_next(request):
    """
    Exemption RBTE Confirmed Candidates Report with Date Range Filter
    PHP reference: exemption_candidate_rbte_confirm_next
    Lists candidates confirmed by both institute and RBTE within the specified date range
    """
    # Step 1: Auth context
    auth, error = get_auth_context(request)
    if error:
        return error

    try:
        # Step 2: Get date range from request (required)
        from_date = request.GET.get('from_date') or request.POST.get('from_date') or ''
        to_date = request.GET.get('to_date') or request.POST.get('to_date') or ''

        # Validate that dates are provided
        if not from_date or not to_date:
            from django.contrib import messages
            from django.shortcuts import redirect
            messages.error(request, 'Please select both From Date and To Date.')
            return redirect('dashboard:exemption:exemp_inst:exemption_candidate_rbte_confirm')

        def parse_date(value):
            # PHP: substr($from_date,6,4)."-".substr($from_date,3,2)."-".substr($from_date,0,2)
            # Accepts DD/MM/YYYY format and converts to YYYY-MM-DD
            if not value:
                return None
            for fmt in ('%d/%m/%Y', '%Y-%m-%d'):
                try:
                    return datetime.strptime(value, fmt).date()
                except (ValueError, TypeError):
                    continue
            return None

        from_date_obj = parse_date(from_date)
        to_date_obj = parse_date(to_date)

        if not from_date_obj or not to_date_obj:
            from django.contrib import messages
            from django.shortcuts import redirect
            messages.error(request, 'Invalid date format. Please use DD/MM/YYYY format.')
            return redirect('dashboard:exemption:exemp_inst:exemption_candidate_rbte_confirm')

        # Get user control info using standardized function
        user_info, error = get_user_control_info(
            request, auth,
            allowed_roles=['INSTITUTE', 'ADMIN'],
            require_institute_code=True,
            redirect_url='dashboard:exemption:exemp_inst:exemption_candidate_rbte_confirm',
            error_message='You are not authorised user to view this report'
        )
        if error:
            return error

        # Step 3: Institute filter (inst_code) – matches PHP role logic
        inst_filter, inst_params = get_institute_filter(user_info['inst_code'])

        # Fix ambiguous column by adding table alias
        if inst_filter:
            inst_filter = inst_filter.replace('inst_code', 'e.inst_code')
            
        # Step 4: Connection
        conn = get_db_connection()

        # Step 5: Get institute info for display (matches PHP: get_region_inst and get_region_name)
        inst_code = user_info['inst_code']
        inst_code_int = int(float(inst_code)) if inst_code else None
        inst_name = ""
        city_name = ""
        region_name = ""
        reg_id = None
        inst_code_formatted = ""
        
        if inst_code_int:
            # Fetch institute details from INSTITUTES table
            inst_query = f"""
                SELECT inst_id, inst_name, city_name, reg_code
                FROM {msbte_config.INSTITUTES}
                WHERE inst_id = %s
                LIMIT 1
            """
            df_inst = pd.read_sql(inst_query, conn, params=[inst_code_int])

            if len(df_inst) > 0:
                # Get institute code from table (inst_id) and format it
                inst_id_from_table = int(df_inst.iloc[0]['inst_id'])
                inst_code_formatted = str(inst_id_from_table).zfill(4)
                
                # Get institute name (prefer inst_name, fallback to city_name)
                inst_name = df_inst.iloc[0]['inst_name'] if pd.notna(df_inst.iloc[0]['inst_name']) else ""
                city_name = df_inst.iloc[0]['city_name'] if pd.notna(df_inst.iloc[0]['city_name']) else ""
                
                # If inst_name is empty, use city_name
                if not inst_name:
                    inst_name = city_name
                # Get region code (reg_code) from institute - this is the region_id
                if pd.notna(df_inst.iloc[0]['reg_code']):
                    reg_id = int(float(df_inst.iloc[0]['reg_code']))
                    # Get region name from REGION_MASTER table if available
                    try:
                        region_query = f"""
                            SELECT region_name 
                            FROM {msbte_config.REGION_MASTER}
                            WHERE reg_code = %s
                            LIMIT 1
                        """
                        df_region = pd.read_sql(region_query, conn, params=[reg_id])
                        if len(df_region) > 0 and pd.notna(df_region.iloc[0]['region_name']):
                            region_name = df_region.iloc[0]['region_name']
                    except:
                        pass
                    # Fallback to mapping if region_name not found
                    if not region_name:
                        region_code_map = {
                            5001: 'Mumbai',
                            5002: 'Pune',
                            5003: 'Nagpur',
                            5004: 'Chhatrapati Sambhaji Nagar (CSN)',
                        }
                        region_name = region_code_map.get(reg_id, '')

        # Step 6: Get Academic Year and Enrollment Year
        aca_year = getattr(msbte_config, 'ACA_YEAR', '')
        academic_year = ""
        enroll_year = ""
        if aca_year:
            import re
            match = re.search(r'(\d{4})\s*-\s*(\d{2})', aca_year)
            if match:
                year1 = match.group(1)  # 2025
                year2_short = match.group(2)  # 26
                year2 = f"20{year2_short}" if len(year2_short) == 2 else year2_short
                academic_year = f"{year1}-{year2}"
                enroll_year = year1  # Use first year as enrollment year
            else:
                current_year = datetime.now().year
                academic_year = f"{current_year}-{current_year + 1}"
                enroll_year = str(current_year)
        else:
            current_year = datetime.now().year
            academic_year = f"{current_year}-{current_year + 1}"
            enroll_year = str(current_year)

        # Step 7: Main query with date filtering (required)
        # PHP: where inst_code=? and inst_conf='Y' and rbte_conf='Y' and (date(rbte_conf_on)>=? and date(rbte_conf_on)<=?)
        main_query = f"""
            SELECT 
                e.enroll_no,
                e.course_id,
                c.name AS candidate_name,
                e.rbte_conf_on
            FROM {msbte_config.EXEMPTION_CAND_DETAILS} e
            LEFT JOIN {msbte_config.CAND_INFO} c
                ON e.enroll_no = c.enroll_no
            WHERE e.inst_conf = 'Y' AND e.rbte_conf = 'Y' {inst_filter} 
                AND DATE(e.rbte_conf_on) >= %s 
                AND DATE(e.rbte_conf_on) <= %s
            ORDER BY e.enroll_no
        """

        df = pd.read_sql(main_query, conn, params=inst_params + [from_date_obj, to_date_obj])

        candidates = []
        if len(df) > 0:
            df['sr_no'] = range(1, len(df) + 1)

            # Convert rbte_conf_on to string to preserve exact database format
            if 'rbte_conf_on' in df.columns:
                df['rbte_conf_on'] = df['rbte_conf_on'].apply(
                    lambda x: str(x) if pd.notna(x) else None
                )

            # Batch fetch course details
            unique_course_ids = df['course_id'].dropna().unique().tolist()
            course_lookup = {}
            if unique_course_ids:
                course_ids_str = ','.join([str(int(cid)) for cid in unique_course_ids if pd.notna(cid)])
                if course_ids_str:
                    course_query = f"""
                        SELECT course_id, course_name, course_code 
                        FROM {msbte_config.COURSES1} 
                        WHERE course_id IN ({course_ids_str})
                    """
                    course_df = pd.read_sql(course_query, conn)
                    for _, crow in course_df.iterrows():
                        course_lookup[int(crow['course_id'])] = {
                            'name': crow['course_name'],
                            'code': crow['course_code']
                        }

            for _, row in df.iterrows():
                # Get course code and name
                course_display = '-'
                if pd.notna(row['course_id']) and int(row['course_id']) in course_lookup:
                    course_info = course_lookup[int(row['course_id'])]
                    course_display = f"{course_info['code']}-{course_info['name']}"

                # Get exemption subjects
                subject_query = f"""
                    SELECT 
                        subject_name,
                        subject_abbr,
                        subject_thpr,
                        paper_code
                    FROM {msbte_config.ELG_EXEMPTION_DETAILS}
                    WHERE enroll_no = %s
                """
                sub_df = pd.read_sql(subject_query, conn, params=[row['enroll_no']])
                subjects = sub_df.to_dict('records') if len(sub_df) > 0 else []

                candidates.append({
                    'sr_no': row['sr_no'],
                    'enroll_no': row['enroll_no'],
                    'candidate_name': row['candidate_name'],
                    'course_id': course_display,
                    'subjects': subjects,
                    'rbte_conf_on': row['rbte_conf_on'] if pd.notna(row['rbte_conf_on']) else None,
                })

        # Get current date for document reference (DD-MM-YYYY format)
        current_date = datetime.now().strftime('%d-%m-%Y')

        context = {
            'report_title': 'Exemption RBTE Confirmed Candidates Report',
            'candidates': candidates,
            'total_count': len(candidates),
            'from_date': from_date,
            'to_date': to_date,
            'inst_code': inst_code,
            'inst_code_formatted': inst_code_formatted,
            'inst_name': inst_name,
            'city_name': city_name,
            'region_name': region_name,
            'reg_id': reg_id,
            'academic_year': academic_year,
            'enroll_year': enroll_year,
            'user_name': user_info['user_name'],
            'print_date': datetime.now().strftime('%d/%m/%Y'),
            'current_date': current_date,
        }

        return render(request, 'exemption_candidate_rbte_confirm_next.html', context)

    except Exception as e:
        logger.exception("Error in exemption_candidate_rbte_confirm_next")
        return handle_report_error(request, e, user_info['is_jwt'])