from django.shortcuts import render, redirect
from django.contrib import messages
import logging
from datetime import datetime
import pandas as pd

import config.msbte_config as msbte_config
from dashboard.decorators import jwt_report_authorized
from dashboard.utils import (
    get_auth_context,
    get_user_control_info,
    handle_report_error,
    get_institute_filter,
    get_db_connection,
)

logger = logging.getLogger(__name__)


@jwt_report_authorized(allowed_roles=['RBTE', 'ADMIN'])
def exemption_rbte_applied_candidate(request):
    """
    Form for RBTE users to select institute code and date range to view Exemption Applied Candidates
    PHP reference: exemption_applied_candidate (RBTE version with inst field)
    """
    auth, error = get_auth_context(request)
    if error:
        return error

    context = {
        'form_title': 'Consolidate Report for Exemption Applied Candidate',
    }
    return render(request, 'exemption_rbte_applied_candidate_form.html', context)


@jwt_report_authorized(allowed_roles=['RBTE', 'ADMIN'])
def exemption_applied_candidate_next(request):
    """
    Exemption Applied Candidates Report with Date Range Filter (RBTE version)
    PHP reference: exemption_applied_candidate_next
    Lists candidates who applied for exemption within the specified date range
    For RBTE users: requires inst parameter from request
    """
    # Step 1: Auth context
    auth, error = get_auth_context(request)
    if error:
        return error

    try:
        # Step 2: Get date range from request (required)
        from_date = request.GET.get('from_date') or request.POST.get('from_date') or ''
        to_date = request.GET.get('to_date') or request.POST.get('to_date') or ''

        # Validate that dates are provided
        if not from_date or not to_date:
            messages.error(request, 'Please select both From Date and To Date.')
            return redirect('dashboard:exemption:exempt_rbte:exemption_rbte_applied_candidate')

        def parse_date(value):
            # PHP: substr($from_date,6,4)."-".substr($from_date,3,2)."-".substr($from_date,0,2)
            # Accepts DD/MM/YYYY format and converts to YYYY-MM-DD
            if not value:
                return None
            for fmt in ('%d/%m/%Y', '%Y-%m-%d'):
                try:
                    return datetime.strptime(value, fmt).date()
                except (ValueError, TypeError):
                    continue
            return None

        from_date_obj = parse_date(from_date)
        to_date_obj = parse_date(to_date)

        if not from_date_obj or not to_date_obj:
            messages.error(request, 'Invalid date format. Please use DD/MM/YYYY format.')
            return redirect('dashboard:exemption:exempt_rbte:exemption_rbte_applied_candidate')

        # Step 3: Get institute code from request (required for RBTE users)
        # PHP: if RBTE/ADMIN use $_REQUEST['inst']
        inst_param = request.GET.get('inst') or request.POST.get('inst') or ''
        
        if not inst_param:
            messages.error(request, 'Please enter Institute Code.')
            return redirect('dashboard:exemption:exempt_rbte:exemption_rbte_applied_candidate')
        
        # Clean and validate institute code
        inst_code = inst_param.strip()
        try:
            inst_code_int = int(inst_code)
        except ValueError:
            messages.error(request, 'Invalid Institute Code. Please enter a valid numeric code.')
            return redirect('dashboard:exemption:exempt_rbte:exemption_rbte_applied_candidate')

        # Step 4: Institute filter using inst from request
        inst_filter, inst_params = get_institute_filter(inst_code)
        
        # Fix ambiguous column by adding table alias
        if inst_filter:
            inst_filter = inst_filter.replace('inst_code', 'e.inst_code')

        # Step 5: Connection
        conn = get_db_connection()

        # Step 6: Main query with date filtering (required)
        # PHP: where inst_code=? and (date(entry_on)>=? and date(entry_on)<=?)
        main_query = f"""
            SELECT 
                e.enroll_no,
                e.elg_id,
                e.course_id,
                c.name AS candidate_name,
                e.entry_on
            FROM {msbte_config.EXEMPTION_CAND_DETAILS} e
            LEFT JOIN {msbte_config.CAND_INFO} c
                ON e.enroll_no = c.enroll_no
            WHERE 1=1 {inst_filter} 
                AND DATE(e.entry_on) >= %s 
                AND DATE(e.entry_on) <= %s
            ORDER BY e.enroll_no
        """

        df = pd.read_sql(main_query, conn, params=inst_params + [from_date_obj, to_date_obj])

        candidates = []
        if len(df) > 0:
            df['sr_no'] = range(1, len(df) + 1)
            df['elg_id'] = df['elg_id'].fillna('NA')

            # Convert entry_on to string to preserve exact database format
            if 'entry_on' in df.columns:
                df['entry_on'] = df['entry_on'].apply(
                    lambda x: str(x) if pd.notna(x) else None
                )

            # Batch fetch course details
            unique_course_ids = df['course_id'].dropna().unique().tolist()
            course_lookup = {}
            if unique_course_ids:
                course_ids_str = ','.join([str(int(cid)) for cid in unique_course_ids if pd.notna(cid)])
                if course_ids_str:
                    course_query = f"""
                        SELECT course_id, course_name, course_code 
                        FROM {msbte_config.COURSES1} 
                        WHERE course_id IN ({course_ids_str})
                    """
                    course_df = pd.read_sql(course_query, conn)
                    for _, crow in course_df.iterrows():
                        course_lookup[int(crow['course_id'])] = {
                            'name': crow['course_name'],
                            'code': crow['course_code']
                        }

            for _, row in df.iterrows():
                # Get course code and name
                course_display = '-'
                if pd.notna(row['course_id']) and int(row['course_id']) in course_lookup:
                    course_info = course_lookup[int(row['course_id'])]
                    course_display = f"{course_info['code']}-{course_info['name']}"

                # Get exemption subjects
                subject_query = f"""
                    SELECT 
                        subject_name,
                        subject_abbr,
                        subject_thpr,
                        paper_code
                    FROM {msbte_config.ELG_EXEMPTION_DETAILS}
                    WHERE enroll_no = %s
                """
                sub_df = pd.read_sql(subject_query, conn, params=[row['enroll_no']])
                subjects = sub_df.to_dict('records') if len(sub_df) > 0 else []

                candidates.append({
                    'sr_no': row['sr_no'],
                    'enroll_no': row['enroll_no'],
                    'elg_id': row['elg_id'],
                    'candidate_name': row['candidate_name'],
                    'course_id': course_display,
                    'subjects': subjects,
                    'entry_on': row['entry_on'] if pd.notna(row['entry_on']) else None,
                })

        # Get Academic Year for header
        aca_year = getattr(msbte_config, 'ACA_YEAR', '')
        academic_year = ""
        if aca_year:
            import re
            match = re.search(r'(\d{4})\s*-\s*(\d{2})', aca_year)
            if match:
                year1 = match.group(1)
                year2_short = match.group(2)
                year2 = f"20{year2_short}" if len(year2_short) == 2 else year2_short
                academic_year = f"{year1}-{year2}"
            else:
                current_year = datetime.now().year
                academic_year = f"{current_year}-{current_year + 1}"
        else:
            current_year = datetime.now().year
            academic_year = f"{current_year}-{current_year + 1}"

        # Get user control info using standardized function
        user_info, error = get_user_control_info(
            request, auth,
            allowed_roles=['RBTE', 'ADMIN'],
            require_institute_code=False,
            require_rbte_code=False,
            redirect_url='dashboard:exemption:exempt_rbte:exemption_rbte_applied_candidate',
            error_message='You are not authorised user to view this report'
        )
        if error:
            return error

        context = {
            'report_title': 'Exemption Applied Candidates Report',
            'candidates': candidates,
            'total_count': len(candidates),
            'from_date': from_date,
            'to_date': to_date,
            'academic_year': academic_year,
            'user_name': user_info['user_name'],
            'print_date': datetime.now().strftime('%d/%m/%Y'),
        }

        return render(request, 'exemption_applied_candidate_next.html', context)

    except Exception as e:
        logger.exception("Error in exemption_applied_candidate_next (RBTE)")
        return handle_report_error(request, e, user_info.get('is_jwt', auth.get('is_jwt', False)))
        


@jwt_report_authorized(allowed_roles=['RBTE', 'ADMIN'])
def exemption_rbte_submited_report(request):
    """
    Form for RBTE users to select institute code and date range to view Exemption Institute Confirmed Candidates
    PHP reference: exemption_rbte_submit_report (RBTE version with inst field)
    """
    auth, error = get_auth_context(request)
    if error:
        return error

    context = {
        'form_title': 'Consolidate Report for Exemption Institute Confirm Candidate',
    }
    return render(request, 'exemption_rbte_submited_report_form.html', context)


@jwt_report_authorized(allowed_roles=['RBTE', 'ADMIN'])
def exemption_rbte_submit_report_next(request):
    """
    Exemption Institute Confirmed Candidates Report with Date Range Filter (RBTE version)
    PHP reference: exemption_rbte_submit_report_next
    Lists candidates confirmed by institute within the specified date range
    For RBTE users: requires inst parameter from request
    """
    # Step 1: Auth context
    auth, error = get_auth_context(request)
    if error:
        return error

    try:
        # Step 2: Get date range from request (required)
        from_date = request.GET.get('from_date') or request.POST.get('from_date') or ''
        to_date = request.GET.get('to_date') or request.POST.get('to_date') or ''

        # Validate that dates are provided
        if not from_date or not to_date:
            messages.error(request, 'Please select both From Date and To Date.')
            return redirect('dashboard:exemption:exempt_rbte:exemption_rbte_submited_report')

        def parse_date(value):
            # PHP: substr($from_date,6,4)."-".substr($from_date,3,2)."-".substr($from_date,0,2)
            # Accepts DD/MM/YYYY format and converts to YYYY-MM-DD
            if not value:
                return None
            for fmt in ('%d/%m/%Y', '%Y-%m-%d'):
                try:
                    return datetime.strptime(value, fmt).date()
                except (ValueError, TypeError):
                    continue
            return None

        from_date_obj = parse_date(from_date)
        to_date_obj = parse_date(to_date)

        if not from_date_obj or not to_date_obj:
            messages.error(request, 'Invalid date format. Please use DD/MM/YYYY format.')
            return redirect('dashboard:exemption:exempt_rbte:exemption_rbte_submited_report')

        # Step 3: Get institute code from request (required for RBTE users)
        # PHP: if RBTE/ADMIN use $_REQUEST['inst']
        inst_param = request.GET.get('inst') or request.POST.get('inst') or ''
        
        if not inst_param:
            messages.error(request, 'Please enter Institute Code.')
            return redirect('dashboard:exemption:exempt_rbte:exemption_rbte_submited_report')
        
        # Clean and validate institute code
        inst_code = inst_param.strip()
        try:
            inst_code_int = int(inst_code)
        except ValueError:
            messages.error(request, 'Invalid Institute Code. Please enter a valid numeric code.')
            return redirect('dashboard:exemption:exempt_rbte:exemption_rbte_submited_report')

        # Step 4: Institute filter using inst from request
        inst_filter, inst_params = get_institute_filter(inst_code)
        
        # Fix ambiguous column by adding table alias
        if inst_filter:
            inst_filter = inst_filter.replace('inst_code', 'e.inst_code')

        # Step 5: Connection
        conn = get_db_connection()

        # Step 6: Main query with date filtering (required)
        # PHP: where inst_code=? and inst_conf='Y' and (date(inst_conf_on)>=? and date(inst_conf_on)<=?)
        main_query = f"""
            SELECT 
                e.enroll_no,
                e.elg_id,
                e.course_id,
                c.name AS candidate_name,
                e.inst_conf_on
            FROM {msbte_config.EXEMPTION_CAND_DETAILS} e
            LEFT JOIN {msbte_config.CAND_INFO} c
                ON e.enroll_no = c.enroll_no
            WHERE e.inst_conf = 'Y' {inst_filter} 
                AND DATE(e.inst_conf_on) >= %s 
                AND DATE(e.inst_conf_on) <= %s
            ORDER BY e.enroll_no
        """

        df = pd.read_sql(main_query, conn, params=inst_params + [from_date_obj, to_date_obj])

        candidates = []
        if len(df) > 0:
            df['sr_no'] = range(1, len(df) + 1)
            df['elg_id'] = df['elg_id'].fillna('NA')

            # Convert inst_conf_on to string to preserve exact database format
            if 'inst_conf_on' in df.columns:
                df['inst_conf_on'] = df['inst_conf_on'].apply(
                    lambda x: str(x) if pd.notna(x) else None
                )

            # Batch fetch course details
            unique_course_ids = df['course_id'].dropna().unique().tolist()
            course_lookup = {}
            if unique_course_ids:
                course_ids_str = ','.join([str(int(cid)) for cid in unique_course_ids if pd.notna(cid)])
                if course_ids_str:
                    course_query = f"""
                        SELECT course_id, course_name, course_code 
                        FROM {msbte_config.COURSES1} 
                        WHERE course_id IN ({course_ids_str})
                    """
                    course_df = pd.read_sql(course_query, conn)
                    for _, crow in course_df.iterrows():
                        course_lookup[int(crow['course_id'])] = {
                            'name': crow['course_name'],
                            'code': crow['course_code']
                        }

            for _, row in df.iterrows():
                # Get course code and name
                course_display = '-'
                if pd.notna(row['course_id']) and int(row['course_id']) in course_lookup:
                    course_info = course_lookup[int(row['course_id'])]
                    course_display = f"{course_info['code']}-{course_info['name']}"

                # Get exemption subjects
                subject_query = f"""
                    SELECT 
                        subject_name,
                        subject_abbr,
                        subject_thpr,
                        paper_code
                    FROM {msbte_config.ELG_EXEMPTION_DETAILS}
                    WHERE enroll_no = %s
                """
                sub_df = pd.read_sql(subject_query, conn, params=[row['enroll_no']])
                subjects = sub_df.to_dict('records') if len(sub_df) > 0 else []

                candidates.append({
                    'sr_no': row['sr_no'],
                    'enroll_no': row['enroll_no'],
                    'elg_id': row['elg_id'],
                    'candidate_name': row['candidate_name'],
                    'course_id': course_display,
                    'subjects': subjects,
                    'inst_conf_on': row['inst_conf_on'] if pd.notna(row['inst_conf_on']) else None,
                })

        # Get Academic Year for header
        aca_year = getattr(msbte_config, 'ACA_YEAR', '')
        academic_year = ""
        if aca_year:
            import re
            match = re.search(r'(\d{4})\s*-\s*(\d{2})', aca_year)
            if match:
                year1 = match.group(1)
                year2_short = match.group(2)
                year2 = f"20{year2_short}" if len(year2_short) == 2 else year2_short
                academic_year = f"{year1}-{year2}"
            else:
                current_year = datetime.now().year
                academic_year = f"{current_year}-{current_year + 1}"
        else:
            current_year = datetime.now().year
            academic_year = f"{current_year}-{current_year + 1}"

        # Get user control info using standardized function
        user_info, error = get_user_control_info(
            request, auth,
            allowed_roles=['RBTE', 'ADMIN'],
            require_institute_code=False,
            require_rbte_code=False,
            redirect_url='dashboard:exemption:exempt_rbte:exemption_rbte_submited_report',
            error_message='You are not authorised user to view this report'
        )
        if error:
            return error

        context = {
            'report_title': 'Exemption Institute Confirmed Candidates Report',
            'candidates': candidates,
            'total_count': len(candidates),
            'from_date': from_date,
            'to_date': to_date,
            'academic_year': academic_year,
            'user_name': user_info['user_name'],
            'print_date': datetime.now().strftime('%d/%m/%Y'),
        }

        return render(request, 'exemption_rbte_submit_report_next.html', context)

    except Exception as e:
        logger.exception("Error in exemption_rbte_submit_report_next (RBTE)")
        # For RBTE/ADMIN users, redirect back to form on error
        return handle_report_error(request, e, user_info.get('is_jwt', auth.get('is_jwt', False)), redirect_url='dashboard:exemption:exempt_rbte:exemption_rbte_submited_report')



@jwt_report_authorized(allowed_roles=['RBTE','ADMIN'])
def exemption_rbte_cand_cancel_apply(request):
    """
    Form for RBTE users to select institute code to view Exemption Cancel Candidate Report
    PHP reference: exemption_candidate_cancel_apply (form)
    """
    auth, error = get_auth_context(request)
    if error:
        return error

    context = {
        'form_title': 'Consolidate Report for Exemption Canceled Candidate',
    }
    return render(request, 'exemption_rbte_cand_cancel_apply.html', context)

@jwt_report_authorized(allowed_roles=['RBTE', 'ADMIN'])
def exemption_candidate_cancel_apply(request):
    """
    Exemption Cancel Candidate Report (RBTE version)
    PHP reference: exemption_candidate_cancel_apply
    Lists all exemption candidates for the selected institute (no date filter)
    For RBTE users: requires inst parameter from request
    """
    # Step 1: Auth context
    auth, error = get_auth_context(request)
    if error:
        return error

    try:
        # Step 2: Get institute code from request (required for RBTE users)
        # PHP: if RBTE/ADMIN use $_REQUEST['inst']
        inst_param = request.GET.get('inst') or request.POST.get('inst') or ''
        
        if not inst_param:
            messages.error(request, 'Please enter Institute Code.')
            return redirect('dashboard:exemption:exempt_rbte:exemption_rbte_cand_cancel_apply')
        
        # Clean and validate institute code
        inst_code = inst_param.strip()
        try:
            inst_code_int = int(inst_code)
        except ValueError:
            messages.error(request, 'Invalid Institute Code. Please enter a valid numeric code.')
            return redirect('dashboard:exemption:exempt_rbte:exemption_rbte_cand_cancel_apply')

        # Step 3: Institute filter using inst from request
        inst_filter, inst_params = get_institute_filter(inst_code)
        
        # Fix ambiguous column by adding table alias
        if inst_filter:
            inst_filter = inst_filter.replace('inst_code', 'e.inst_code')

        # Step 4: Connection
        conn = get_db_connection()

        # Step 5: Main query (PHP: select * from EXEMPTION_CAND_DETAILS_COPY where inst_code=? order by enroll_no)
        main_query = f"""
            SELECT 
                e.enroll_no,
                e.elg_id,
                e.course_id,
                c.name AS candidate_name
            FROM {msbte_config.EXEMPTION_CAND_DETAILS_COPY} e
            LEFT JOIN {msbte_config.CAND_INFO} c
                ON e.enroll_no = c.enroll_no
            WHERE 1=1 {inst_filter}
            ORDER BY e.enroll_no
        """

        df = pd.read_sql(main_query, conn, params=inst_params)

        candidates = []
        if len(df) > 0:
            df['sr_no'] = range(1, len(df) + 1)
            df['elg_id'] = df['elg_id'].fillna('NA')

            # Batch fetch course details
            unique_course_ids = df['course_id'].dropna().unique().tolist()
            course_lookup = {}
            if unique_course_ids:
                course_ids_str = ','.join([str(int(cid)) for cid in unique_course_ids if pd.notna(cid)])
                if course_ids_str:
                    course_query = f"""
                        SELECT course_id, course_name, course_code 
                        FROM {msbte_config.COURSES1} 
                        WHERE course_id IN ({course_ids_str})
                    """
                    course_df = pd.read_sql(course_query, conn)
                    for _, crow in course_df.iterrows():
                        course_lookup[int(crow['course_id'])] = {
                            'name': crow['course_name'],
                            'code': crow['course_code']
                        }

            for _, row in df.iterrows():
                # Get course code and name
                course_display = '-'
                if pd.notna(row['course_id']) and int(row['course_id']) in course_lookup:
                    course_info = course_lookup[int(row['course_id'])]
                    course_display = f"{course_info['code']}-{course_info['name']}"

                # Get exemption subjects (PHP: from exe25_examption_details_copy)
                subject_query = f"""
                    SELECT 
                        subject_name,
                        subject_abbr,
                        subject_thpr,
                        paper_code
                    FROM {msbte_config.EXEMPTION_SUBJECT_DETAILS_COPY}
                    WHERE enroll_no = %s
                """
                sub_df = pd.read_sql(subject_query, conn, params=[row['enroll_no']])
                subjects = sub_df.to_dict('records') if len(sub_df) > 0 else []

                candidates.append({
                    'sr_no': row['sr_no'],
                    'enroll_no': row['enroll_no'],
                    'elg_id': row['elg_id'],
                    'candidate_name': row['candidate_name'],
                    'course_id': course_display,
                    'subjects': subjects,
                })

        # Get Academic Year for header
        aca_year = getattr(msbte_config, 'ACA_YEAR', '')
        academic_year = ""
        if aca_year:
            import re
            match = re.search(r'(\d{4})\s*-\s*(\d{2})', aca_year)
            if match:
                year1 = match.group(1)
                year2_short = match.group(2)
                year2 = f"20{year2_short}" if len(year2_short) == 2 else year2_short
                academic_year = f"{year1}-{year2}"
            else:
                current_year = datetime.now().year
                academic_year = f"{current_year}-{current_year + 1}"
        else:
            current_year = datetime.now().year
            academic_year = f"{current_year}-{current_year + 1}"

        # Get user control info using standardized function
        user_info, error = get_user_control_info(
            request, auth,
            allowed_roles=['RBTE', 'ADMIN'],
            require_institute_code=False,
            require_rbte_code=False,
            redirect_url='dashboard:exemption:exempt_rbte:exemption_rbte_cand_cancel_apply',
            error_message='You are not authorised user to view this report'
        )
        if error:
            return error

        context = {
            'report_title': 'Exemption Cancel Candidate Report',
            'candidates': candidates,
            'total_count': len(candidates),
            'academic_year': academic_year,
            'user_name': user_info['user_name'],
            'print_date': datetime.now().strftime('%d/%m/%Y'),
        }

        return render(request, 'exemption_candidate_cancel_apply.html', context)

    except Exception as e:
        logger.exception("Error in exemption_candidate_cancel_apply (RBTE)")
        # For RBTE/ADMIN users, redirect back to form on error
        return handle_report_error(request, e, user_info.get('is_jwt', auth.get('is_jwt', False)), redirect_url='dashboard:exemption:exempt_rbte:exemption_rbte_cand_cancel_apply')

@jwt_report_authorized(allowed_roles=['RBTE', 'ADMIN'])
def exemption_rbte_candidate_rbte_confirm(request):
    """
    Form for RBTE users to select institute code and date range to view Exemption RBTE Confirmed Candidates
    PHP reference: exemption_candidate_rbte_confirm (RBTE version with inst field)
    """
    auth, error = get_auth_context(request)
    if error:
        return error

    context = {
        'form_title': 'Consolidate Report for Exemption Applied Candidate',
    }
    return render(request, 'exemption_rbte_candidate_rbte_confirm_form.html', context)

@jwt_report_authorized(allowed_roles=['RBTE', 'ADMIN'])
def exemption_candidate_rbte_confirm_next(request):
    """
    Exemption RBTE Confirmed Candidates Report with Date Range Filter (RBTE version)
    PHP reference: exemption_candidate_rbte_confirm_next
    Lists candidates confirmed by both institute and RBTE within the specified date range
    For RBTE users: requires inst parameter from request
    """
    # Step 1: Auth context
    auth, error = get_auth_context(request)
    if error:
        return error

    try:
        # Step 2: Get date range from request (required)
        from_date = request.GET.get('from_date') or request.POST.get('from_date') or ''
        to_date = request.GET.get('to_date') or request.POST.get('to_date') or ''

        # Validate that dates are provided
        if not from_date or not to_date:
            messages.error(request, 'Please select both From Date and To Date.')
            return redirect('dashboard:exemption:exempt_rbte:exemption_rbte_candidate_rbte_confirm')

        def parse_date(value):
            # PHP: substr($from_date,6,4)."-".substr($from_date,3,2)."-".substr($from_date,0,2)
            # Accepts DD/MM/YYYY format and converts to YYYY-MM-DD
            if not value:
                return None
            for fmt in ('%d/%m/%Y', '%Y-%m-%d'):
                try:
                    return datetime.strptime(value, fmt).date()
                except (ValueError, TypeError):
                    continue
            return None

        from_date_obj = parse_date(from_date)
        to_date_obj = parse_date(to_date)

        if not from_date_obj or not to_date_obj:
            messages.error(request, 'Invalid date format. Please use DD/MM/YYYY format.')
            return redirect('dashboard:exemption:exempt_rbte:exemption_rbte_candidate_rbte_confirm')

        # Step 3: Get institute code from request (required for RBTE users)
        # PHP: if RBTE/ADMIN use $_REQUEST['inst']
        inst_param = request.GET.get('inst') or request.POST.get('inst') or ''
        
        if not inst_param:
            messages.error(request, 'Please enter Institute Code.')
            return redirect('dashboard:exemption:exempt_rbte:exemption_rbte_candidate_rbte_confirm')
        
        # Clean and validate institute code
        inst_code = inst_param.strip()
        try:
            inst_code_int = int(inst_code)
        except ValueError:
            messages.error(request, 'Invalid Institute Code. Please enter a valid numeric code.')
            return redirect('dashboard:exemption:exempt_rbte:exemption_rbte_candidate_rbte_confirm')

        # Step 4: Institute filter using inst from request
        inst_filter, inst_params = get_institute_filter(inst_code)
        
        # Fix ambiguous column by adding table alias
        if inst_filter:
            inst_filter = inst_filter.replace('inst_code', 'e.inst_code')

        # Step 5: Connection
        conn = get_db_connection()

        # Step 6: Get institute info for display (matches PHP: get_region_inst and get_region_name)
        inst_name = ""
        city_name = ""
        region_name = ""
        reg_id = None
        inst_code_formatted = ""
        
        if inst_code_int:
            # Fetch institute details from INSTITUTES table
            inst_query = f"""
                SELECT inst_id, inst_name, city_name, reg_code
                FROM {msbte_config.INSTITUTES}
                WHERE inst_id = %s
                LIMIT 1
            """
            df_inst = pd.read_sql(inst_query, conn, params=[inst_code_int])

            if len(df_inst) > 0:
                # Get institute code from table (inst_id) and format it
                inst_id_from_table = int(df_inst.iloc[0]['inst_id'])
                inst_code_formatted = str(inst_id_from_table).zfill(4)
                
                # Get institute name (prefer inst_name, fallback to city_name)
                inst_name = df_inst.iloc[0]['inst_name'] if pd.notna(df_inst.iloc[0]['inst_name']) else ""
                city_name = df_inst.iloc[0]['city_name'] if pd.notna(df_inst.iloc[0]['city_name']) else ""
                
                # If inst_name is empty, use city_name
                if not inst_name:
                    inst_name = city_name
                    
                # Get region code (reg_code) from institute - this is the region_id
                if pd.notna(df_inst.iloc[0]['reg_code']):
                    reg_id = int(float(df_inst.iloc[0]['reg_code']))
                    # Get region name from REGION_MASTER table if available
                    try:
                        region_query = f"""
                            SELECT region_name 
                            FROM {msbte_config.REGION_MASTER}
                            WHERE reg_code = %s
                            LIMIT 1
                        """
                        df_region = pd.read_sql(region_query, conn, params=[reg_id])
                        if len(df_region) > 0 and pd.notna(df_region.iloc[0]['region_name']):
                            region_name = df_region.iloc[0]['region_name']
                    except:
                        pass
                    # Fallback to mapping if region_name not found
                    if not region_name:
                        region_code_map = {
                            5001: 'Mumbai',
                            5002: 'Pune',
                            5003: 'Nagpur',
                            5004: 'Chhatrapati Sambhaji Nagar (CSN)',
                        }
                        region_name = region_code_map.get(reg_id, '')

        # Step 7: Get Academic Year and Enrollment Year
        aca_year = getattr(msbte_config, 'ACA_YEAR', '')
        academic_year = ""
        enroll_year = ""
        if aca_year:
            import re
            match = re.search(r'(\d{4})\s*-\s*(\d{2})', aca_year)
            if match:
                year1 = match.group(1)  # 2025
                year2_short = match.group(2)  # 26
                year2 = f"20{year2_short}" if len(year2_short) == 2 else year2_short
                academic_year = f"{year1}-{year2}"
                enroll_year = year1  # Use first year as enrollment year
            else:
                current_year = datetime.now().year
                academic_year = f"{current_year}-{current_year + 1}"
                enroll_year = str(current_year)
        else:
            current_year = datetime.now().year
            academic_year = f"{current_year}-{current_year + 1}"
            enroll_year = str(current_year)

        # Step 8: Main query with date filtering (required)
        # PHP: where inst_code=? and inst_conf='Y' and rbte_conf='Y' and (date(rbte_conf_on)>=? and date(rbte_conf_on)<=?)
        main_query = f"""
            SELECT 
                e.enroll_no,
                e.elg_id,
                e.course_id,
                c.name AS candidate_name,
                e.rbte_conf_on
            FROM {msbte_config.EXEMPTION_CAND_DETAILS} e
            LEFT JOIN {msbte_config.CAND_INFO} c
                ON e.enroll_no = c.enroll_no
            WHERE e.inst_conf = 'Y' AND e.rbte_conf = 'Y' {inst_filter} 
                AND DATE(e.rbte_conf_on) >= %s 
                AND DATE(e.rbte_conf_on) <= %s
            ORDER BY e.enroll_no
        """

        df = pd.read_sql(main_query, conn, params=inst_params + [from_date_obj, to_date_obj])

        candidates = []
        if len(df) > 0:
            df['sr_no'] = range(1, len(df) + 1)
            df['elg_id'] = df['elg_id'].fillna('NA')

            # Convert rbte_conf_on to string to preserve exact database format
            if 'rbte_conf_on' in df.columns:
                df['rbte_conf_on'] = df['rbte_conf_on'].apply(
                    lambda x: str(x) if pd.notna(x) else None
                )

            # Batch fetch course details
            unique_course_ids = df['course_id'].dropna().unique().tolist()
            course_lookup = {}
            if unique_course_ids:
                course_ids_str = ','.join([str(int(cid)) for cid in unique_course_ids if pd.notna(cid)])
                if course_ids_str:
                    course_query = f"""
                        SELECT course_id, course_name, course_code 
                        FROM {msbte_config.COURSES1} 
                        WHERE course_id IN ({course_ids_str})
                    """
                    course_df = pd.read_sql(course_query, conn)
                    for _, crow in course_df.iterrows():
                        course_lookup[int(crow['course_id'])] = {
                            'name': crow['course_name'],
                            'code': crow['course_code']
                        }

            for _, row in df.iterrows():
                # Get course code and name
                course_display = '-'
                if pd.notna(row['course_id']) and int(row['course_id']) in course_lookup:
                    course_info = course_lookup[int(row['course_id'])]
                    course_display = f"{course_info['code']}-{course_info['name']}"

                # Get exemption subjects (PHP: from EXEMPTION_DETAILS)
                subject_query = f"""
                    SELECT 
                        subject_name,
                        subject_abbr,
                        subject_thpr,
                        paper_code
                    FROM {msbte_config.ELG_EXEMPTION_DETAILS}
                    WHERE enroll_no = %s
                """
                sub_df = pd.read_sql(subject_query, conn, params=[row['enroll_no']])
                subjects = sub_df.to_dict('records') if len(sub_df) > 0 else []

                candidates.append({
                    'sr_no': row['sr_no'],
                    'enroll_no': row['enroll_no'],
                    'elg_id': row['elg_id'],
                    'candidate_name': row['candidate_name'],
                    'course_id': course_display,
                    'subjects': subjects,
                    'rbte_conf_on': row['rbte_conf_on'] if pd.notna(row['rbte_conf_on']) else None,
                })

        # Get current date for document reference (DD-MM-YYYY format)
        current_date = datetime.now().strftime('%d-%m-%Y')

        # Get user control info using standardized function
        user_info, error = get_user_control_info(
            request, auth,
            allowed_roles=['RBTE', 'ADMIN'],
            require_institute_code=False,
            require_rbte_code=False,
            redirect_url='dashboard:exemption:exempt_rbte:exemption_rbte_candidate_rbte_confirm',
            error_message='You are not authorised user to view this report'
        )
        if error:
            return error

        context = {
            'report_title': 'Exemption RBTE Confirmed Candidates Report',
            'candidates': candidates,
            'total_count': len(candidates),
            'from_date': from_date,
            'to_date': to_date,
            'inst_code': inst_code,
            'inst_code_formatted': inst_code_formatted,
            'inst_name': inst_name,
            'city_name': city_name,
            'region_name': region_name,
            'reg_id': reg_id,
            'academic_year': academic_year,
            'enroll_year': enroll_year,
            'user_name': user_info['user_name'],
            'print_date': datetime.now().strftime('%d/%m/%Y'),
            'current_date': current_date,
        }

        return render(request, 'exemption_candidate_rbte_confirm_next.html', context)

    except Exception as e:
        logger.exception("Error in exemption_candidate_rbte_confirm_next (RBTE)")
        # For RBTE/ADMIN users, redirect back to form on error
        return handle_report_error(request, e, user_info.get('is_jwt', auth.get('is_jwt', False)), redirect_url='dashboard:exemption:exempt_rbte:exemption_rbte_candidate_rbte_confirm')

@jwt_report_authorized(allowed_roles=['RBTE', 'ADMIN'])
def exemption_rbte_status_report(request):
    """
    Statistical Report for Exemption by Institute (RBTE version)
    PHP reference: Reports For Exemption
    Shows institute-wise counts for Exemption Applied, Institute Confirmed, and RBTE Confirmed
    For RBTE: uses user's RBTE code as region (can only see their own region)
    For SUBRBTE: extracts region from username (500 + 5th character of username)
    For ADMIN/MSBTE: uses region parameter from request
    """
    # Step 1: Auth context
    auth, error = get_auth_context(request, require_institute=False)
    if error:
        return error

    try:
        # Get user control info using standardized function
        user_info, error = get_user_control_info(
            request, auth,
            allowed_roles=['RBTE', 'ADMIN', 'SUBRBTE', 'MSBTE'],
            require_institute_code=False,
            require_rbte_code=False,
            redirect_url='dashboard:exemption:exemption_home',
            error_message='You are not authorised user to view this report'
        )
        if error:
            return error

        # Step 2: Get database connection
        conn = get_db_connection()
        
        # Step 3: Get user ID (reg_code) from user_info - matches PHP $uid
        uid = user_info.get('uid')
        if uid:
            uid = str(uid).strip()
        
        # Step 4: Check if user is admin from user_info
        is_admin = user_info.get('is_admin', False)
        
        logger.info(f"exemption_rbte_status_report - uid: {uid}, is_admin: {is_admin}")
        
        # Step 5: Determine region code based on admin status
        # Security: RBTE users can ONLY see their own region (from token/session)
        #           ADMIN users can see ANY region (via region parameter) or ALL regions if no parameter
        region = None
        region_param = request.GET.get('region') or request.POST.get('region') or ''
        show_all_regions = False
        
        if is_admin:
            # ADMIN users: can access ANY region via region parameter, or ALL regions if no parameter
            if region_param:
                region = region_param
            else:
                # ADMIN without region parameter: show all regions combined
                show_all_regions = True
                logger.info(f"exemption_rbte_status_report - ADMIN user with no region parameter, showing all regions")
        else:
            # RBTE users: MUST use their own uid (from token/session) - IGNORE region_param for security
            if not uid:
                logger.warning(f"exemption_rbte_status_report - RBTE user but no uid found")
                messages.error(request, 'Unable to determine RBTE code. Please contact administrator.')
                return redirect('dashboard:exemption:exemption_home')
            region = uid
            # Security check: RBTE users cannot access other regions via region_param
            if region_param and region_param != str(region):
                logger.warning(f"exemption_rbte_status_report - RBTE user attempted to access different region: {region_param} (allowed: {region})")
                messages.warning(request, 'You can only view your own RBTE region data.')
        
        # Step 6: Get institutes - either by specific region or all regions for ADMIN
        if show_all_regions:
            # ADMIN viewing all regions: get all institutes
            institutes_query = f"""
                SELECT inst_id, inst_name, city_name, status, reg_code
                FROM {msbte_config.INSTITUTES}
                ORDER BY reg_code, inst_id
            """
            df_institutes = pd.read_sql(institutes_query, conn)
        else:
            # Step 7: Clean and validate region code for specific region
            try:
                region_int = int(region)
            except (ValueError, TypeError):
                messages.error(request, 'Invalid Region Code. Please enter a valid numeric code.')
                return redirect('dashboard:exemption:exemption_home')

            # Get institutes by specific region (PHP: select inst_id,inst_name,status from INSTITUTES where reg_code = ?)
            institutes_query = f"""
                SELECT inst_id, inst_name, city_name, status, reg_code
                FROM {msbte_config.INSTITUTES}
                WHERE reg_code = %s
                ORDER BY inst_id
            """
            df_institutes = pd.read_sql(institutes_query, conn, params=[region_int])

        institutes = []
        total_applied = 0
        total_inst_confirmed = 0
        total_rbte_confirmed = 0

        # Step 8: Query counts for each institute (matches pattern from exemption_statistical_report)
        if len(df_institutes) > 0:
            for _, inst_row in df_institutes.iterrows():
                inst_code = int(inst_row['inst_id'])
                inst_name_val = inst_row['inst_name'] if pd.notna(inst_row['inst_name']) else ""
                city_name_val = inst_row['city_name'] if pd.notna(inst_row['city_name']) else ""
                
                # Use city_name if inst_name is empty (PHP: city_name($arr['inst_id']))
                if not inst_name_val:
                    inst_name_val = city_name_val if city_name_val else ""
                
                # Count 1: Exemption Applied (all records) - using COUNT(DISTINCT) like exemption_statistical_report
                applied_query = f"""
                    SELECT COUNT(DISTINCT enroll_no) as count_en 
                    FROM {msbte_config.EXEMPTION_CAND_DETAILS}
                    WHERE inst_code = %s
                """
                applied_df = pd.read_sql(applied_query, conn, params=[inst_code])
                applied_count = int(applied_df.iloc[0]['count_en']) if len(applied_df) > 0 else 0
                total_applied += applied_count

                # Count 2: Exemption Institute Confirmed - using COUNT(DISTINCT) like exemption_statistical_report
                inst_conf_query = f"""
                    SELECT COUNT(DISTINCT enroll_no) as count_en 
                    FROM {msbte_config.EXEMPTION_CAND_DETAILS}
                    WHERE inst_code = %s AND inst_conf = 'Y'
                """
                inst_conf_df = pd.read_sql(inst_conf_query, conn, params=[inst_code])
                inst_confirmed_count = int(inst_conf_df.iloc[0]['count_en']) if len(inst_conf_df) > 0 else 0
                total_inst_confirmed += inst_confirmed_count

                # Count 3: Exemption RBTE Confirmed - using COUNT(DISTINCT) like exemption_statistical_report
                rbte_conf_query = f"""
                    SELECT COUNT(DISTINCT enroll_no) as count_en 
                    FROM {msbte_config.EXEMPTION_CAND_DETAILS}
                    WHERE inst_code = %s AND inst_conf = 'Y' AND rbte_conf = 'Y'
                """
                rbte_conf_df = pd.read_sql(rbte_conf_query, conn, params=[inst_code])
                rbte_confirmed_count = int(rbte_conf_df.iloc[0]['count_en']) if len(rbte_conf_df) > 0 else 0
                total_rbte_confirmed += rbte_confirmed_count

                institutes.append({
                    'inst_code': inst_code,
                    'inst_name': inst_name_val,
                    'applied_count': applied_count,
                    'inst_confirmed_count': inst_confirmed_count,
                    'rbte_confirmed_count': rbte_confirmed_count,
                })

        # is_admin already determined above

        context = {
            'report_title': 'Reports For Exemption',
            'institutes': institutes,
            'total_applied': total_applied,
            'total_inst_confirmed': total_inst_confirmed,
            'total_rbte_confirmed': total_rbte_confirmed,
            'region': region if not show_all_regions else 'ALL',
            'user_name': user_info['user_name'],
            'is_admin': is_admin,
        }

        return render(request, 'exemption_rbte_status_report.html', context)

    except Exception as e:
        logger.exception("Error in exemption_rbte_status_report")
        return handle_report_error(request, e, user_info.get('is_jwt', auth.get('is_jwt', False)))

@jwt_report_authorized(allowed_roles=['RBTE', 'ADMIN'])
def exemption_cand_applied(request):
    """
    Exemption Applied Candidates Report (RBTE version - no date filter)
    PHP reference: exemption_cand_applied
    Lists all exemption candidates for the selected institute (no date filter)
    For INSTITUTE: uses their own institute code from session
    For RBTE/ADMIN: requires inst parameter from request
    """
    # Step 1: Auth context
    auth, error = get_auth_context(request, require_institute=False)
    if error:
        return error

    try:
        # Get user control info using standardized function
        user_info, error = get_user_control_info(
            request, auth,
            allowed_roles=['RBTE', 'ADMIN', 'INSTITUTE'],
            require_institute_code=False,
            require_rbte_code=False,
            redirect_url='dashboard:exemption:exemption_home',
            error_message='You are not authorised user to view this report'
        )
        if error:
            return error

        # Step 2: Get institute code based on role
        # PHP: if INSTITUTE $inst_code=$uid; else if RBTE/ADMIN $inst_code=$_REQUEST['inst']
        user_role = user_info.get('user_role', '').upper()
        
        if user_role == 'INSTITUTE':
            inst_code = user_info.get('inst_code', '')
        else:
            # RBTE/ADMIN: get inst from request
            inst_code = request.GET.get('inst') or request.POST.get('inst') or ''
        
        if not inst_code:
            messages.error(request, 'Please provide Institute Code.')
            return redirect('dashboard:exemption:exemption_home')
        
        # Clean and validate institute code
        try:
            inst_code_int = int(inst_code)
        except ValueError:
            messages.error(request, 'Invalid Institute Code. Please enter a valid numeric code.')
            return redirect('dashboard:exemption:exemption_home')

        # Step 3: Institute filter
        inst_filter, inst_params = get_institute_filter(inst_code)
        
        # Fix ambiguous column by adding table alias
        if inst_filter:
            inst_filter = inst_filter.replace('inst_code', 'e.inst_code')

        # Step 4: Connection
        conn = get_db_connection()

        # Step 5: Main query (PHP: select * from EXEMPTION_CAND_DETAILS where inst_code=? order by enroll_no)
        main_query = f"""
            SELECT 
                e.enroll_no,
                e.elg_id,
                e.course_id,
                c.name AS candidate_name,
                e.entry_on
            FROM {msbte_config.EXEMPTION_CAND_DETAILS} e
            LEFT JOIN {msbte_config.CAND_INFO} c
                ON e.enroll_no = c.enroll_no
            WHERE 1=1 {inst_filter}
            ORDER BY e.enroll_no
        """

        df = pd.read_sql(main_query, conn, params=inst_params)

        candidates = []
        if len(df) > 0:
            df['sr_no'] = range(1, len(df) + 1)
            df['elg_id'] = df['elg_id'].fillna('NA')

            # Convert entry_on to string to preserve exact database format
            if 'entry_on' in df.columns:
                df['entry_on'] = df['entry_on'].apply(
                    lambda x: str(x) if pd.notna(x) else None
                )

            # Batch fetch course details
            unique_course_ids = df['course_id'].dropna().unique().tolist()
            course_lookup = {}
            if unique_course_ids:
                course_ids_str = ','.join([str(int(cid)) for cid in unique_course_ids if pd.notna(cid)])
                if course_ids_str:
                    course_query = f"""
                        SELECT course_id, course_name, course_code 
                        FROM {msbte_config.COURSES1} 
                        WHERE course_id IN ({course_ids_str})
                    """
                    course_df = pd.read_sql(course_query, conn)
                    for _, crow in course_df.iterrows():
                        course_lookup[int(crow['course_id'])] = {
                            'name': crow['course_name'],
                            'code': crow['course_code']
                        }

            for _, row in df.iterrows():
                # Get course code and name
                course_display = '-'
                if pd.notna(row['course_id']) and int(row['course_id']) in course_lookup:
                    course_info = course_lookup[int(row['course_id'])]
                    course_display = f"{course_info['code']}-{course_info['name']}"

                # Get exemption subjects
                subject_query = f"""
                    SELECT 
                        subject_name,
                        subject_abbr,
                        subject_thpr,
                        paper_code
                    FROM {msbte_config.ELG_EXEMPTION_DETAILS}
                    WHERE enroll_no = %s
                """
                sub_df = pd.read_sql(subject_query, conn, params=[row['enroll_no']])
                subjects = sub_df.to_dict('records') if len(sub_df) > 0 else []

                candidates.append({
                    'sr_no': row['sr_no'],
                    'enroll_no': row['enroll_no'],
                    'elg_id': row['elg_id'],
                    'candidate_name': row['candidate_name'],
                    'course_id': course_display,
                    'subjects': subjects,
                    'entry_on': row['entry_on'] if pd.notna(row['entry_on']) else None,
                })

        # Get Academic Year for header
        aca_year = getattr(msbte_config, 'ACA_YEAR', '')
        academic_year = ""
        if aca_year:
            import re
            match = re.search(r'(\d{4})\s*-\s*(\d{2})', aca_year)
            if match:
                year1 = match.group(1)
                year2_short = match.group(2)
                year2 = f"20{year2_short}" if len(year2_short) == 2 else year2_short
                academic_year = f"{year1}-{year2}"
            else:
                current_year = datetime.now().year
                academic_year = f"{current_year}-{current_year + 1}"
        else:
            current_year = datetime.now().year
            academic_year = f"{current_year}-{current_year + 1}"

        context = {
            'report_title': 'Exemption Applied Candidates Report',
            'candidates': candidates,
            'total_count': len(candidates),
            'academic_year': academic_year,
            'user_name': user_info['user_name'],
            'print_date': datetime.now().strftime('%d/%m/%Y'),
        }

        return render(request, 'exemption_cand_applied.html', context)

    except Exception as e:
        logger.exception("Error in exemption_cand_applied (RBTE)")
        return handle_report_error(request, e, user_info.get('is_jwt', auth.get('is_jwt', False)))


@jwt_report_authorized(allowed_roles=['RBTE', 'ADMIN'])
def exemption_inst_confirm(request):
    """
    Exemption Institute Confirmed Candidates Report (RBTE version - no date filter)
    PHP reference: exemption_inst_confirm
    Lists all institute confirmed candidates for the selected institute (no date filter)
    For INSTITUTE: uses their own institute code from session
    For RBTE/ADMIN: requires inst parameter from request
    """
    # Step 1: Auth context
    auth, error = get_auth_context(request, require_institute=False)
    if error:
        return error

    try:
        # Get user control info using standardized function
        user_info, error = get_user_control_info(
            request, auth,
            allowed_roles=['RBTE', 'ADMIN', 'INSTITUTE'],
            require_institute_code=False,
            require_rbte_code=False,
            redirect_url='dashboard:exemption:exemption_home',
            error_message='You are not authorised user to view this report'
        )
        if error:
            return error

        # Step 2: Get institute code based on role
        # PHP: if INSTITUTE $inst_code=$uid; else if RBTE/ADMIN $inst_code=$_REQUEST['inst']
        user_role = user_info.get('user_role', '').upper()
        
        if user_role == 'INSTITUTE':
            inst_code = user_info.get('inst_code', '')
        else:
            # RBTE/ADMIN: get inst from request
            inst_code = request.GET.get('inst') or request.POST.get('inst') or ''
        
        if not inst_code:
            messages.error(request, 'Please provide Institute Code.')
            return redirect('dashboard:exemption:exemption_home')
        
        # Clean and validate institute code
        try:
            inst_code_int = int(inst_code)
        except ValueError:
            messages.error(request, 'Invalid Institute Code. Please enter a valid numeric code.')
            return redirect('dashboard:exemption:exemption_home')

        # Step 3: Institute filter
        inst_filter, inst_params = get_institute_filter(inst_code)
        
        # Fix ambiguous column by adding table alias
        if inst_filter:
            inst_filter = inst_filter.replace('inst_code', 'e.inst_code')

        # Step 4: Connection
        conn = get_db_connection()

        # Step 5: Main query (PHP: select * from EXEMPTION_CAND_DETAILS where inst_code=? and inst_conf='Y' order by enroll_no)
        main_query = f"""
            SELECT 
                e.enroll_no,
                e.elg_id,
                e.course_id,
                c.name AS candidate_name,
                e.inst_conf_on
            FROM {msbte_config.EXEMPTION_CAND_DETAILS} e
            LEFT JOIN {msbte_config.CAND_INFO} c
                ON e.enroll_no = c.enroll_no
            WHERE e.inst_conf = 'Y' {inst_filter}
            ORDER BY e.enroll_no
        """

        df = pd.read_sql(main_query, conn, params=inst_params)

        candidates = []
        if len(df) > 0:
            df['sr_no'] = range(1, len(df) + 1)
            df['elg_id'] = df['elg_id'].fillna('NA')

            # Convert inst_conf_on to string to preserve exact database format
            if 'inst_conf_on' in df.columns:
                df['inst_conf_on'] = df['inst_conf_on'].apply(
                    lambda x: str(x) if pd.notna(x) else None
                )

            # Batch fetch course details
            unique_course_ids = df['course_id'].dropna().unique().tolist()
            course_lookup = {}
            if unique_course_ids:
                course_ids_str = ','.join([str(int(cid)) for cid in unique_course_ids if pd.notna(cid)])
                if course_ids_str:
                    course_query = f"""
                        SELECT course_id, course_name, course_code 
                        FROM {msbte_config.COURSES1} 
                        WHERE course_id IN ({course_ids_str})
                    """
                    course_df = pd.read_sql(course_query, conn)
                    for _, crow in course_df.iterrows():
                        course_lookup[int(crow['course_id'])] = {
                            'name': crow['course_name'],
                            'code': crow['course_code']
                        }

            for _, row in df.iterrows():
                # Get course code and name
                course_display = '-'
                if pd.notna(row['course_id']) and int(row['course_id']) in course_lookup:
                    course_info = course_lookup[int(row['course_id'])]
                    course_display = f"{course_info['code']}-{course_info['name']}"

                # Get exemption subjects
                subject_query = f"""
                    SELECT 
                        subject_name,
                        subject_abbr,
                        subject_thpr,
                        paper_code
                    FROM {msbte_config.ELG_EXEMPTION_DETAILS}
                    WHERE enroll_no = %s
                """
                sub_df = pd.read_sql(subject_query, conn, params=[row['enroll_no']])
                subjects = sub_df.to_dict('records') if len(sub_df) > 0 else []

                candidates.append({
                    'sr_no': row['sr_no'],
                    'enroll_no': row['enroll_no'],
                    'elg_id': row['elg_id'],
                    'candidate_name': row['candidate_name'],
                    'course_id': course_display,
                    'subjects': subjects,
                    'inst_conf_on': row['inst_conf_on'] if pd.notna(row['inst_conf_on']) else None,
                })

        # Get Academic Year for header
        aca_year = getattr(msbte_config, 'ACA_YEAR', '')
        academic_year = ""
        if aca_year:
            import re
            match = re.search(r'(\d{4})\s*-\s*(\d{2})', aca_year)
            if match:
                year1 = match.group(1)
                year2_short = match.group(2)
                year2 = f"20{year2_short}" if len(year2_short) == 2 else year2_short
                academic_year = f"{year1}-{year2}"
            else:
                current_year = datetime.now().year
                academic_year = f"{current_year}-{current_year + 1}"
        else:
            current_year = datetime.now().year
            academic_year = f"{current_year}-{current_year + 1}"

        context = {
            'report_title': 'Exemption Institute Confirmed Candidates Report',
            'candidates': candidates,
            'total_count': len(candidates),
            'academic_year': academic_year,
            'user_name': user_info['user_name'],
            'print_date': datetime.now().strftime('%d/%m/%Y'),
        }

        return render(request, 'exemption_inst_confirm.html', context)

    except Exception as e:
        logger.exception("Error in exemption_inst_confirm (RBTE)")
        return handle_report_error(request, e, user_info.get('is_jwt', auth.get('is_jwt', False)))


@jwt_report_authorized(allowed_roles=['RBTE', 'ADMIN'])
def exemption_rbte_confirm(request):
    """
    Exemption RBTE Confirmed Candidates Report (RBTE version - no date filter)
    PHP reference: exemption_rbte_confirm
    Lists all RBTE confirmed candidates for the selected institute (no date filter)
    For INSTITUTE: uses their own institute code from session
    For RBTE/ADMIN: requires inst parameter from request
    """
    # Step 1: Auth context
    auth, error = get_auth_context(request, require_institute=False)
    if error:
        return error

    try:
        # Get user control info using standardized function
        user_info, error = get_user_control_info(
            request, auth,
            allowed_roles=['RBTE', 'ADMIN', 'INSTITUTE'],
            require_institute_code=False,
            require_rbte_code=False,
            redirect_url='dashboard:exemption:exemption_home',
            error_message='You are not authorised user to view this report'
        )
        if error:
            return error

        # Step 2: Get institute code based on role
        # PHP: if INSTITUTE $inst_code=$uid; else if RBTE/ADMIN $inst_code=$_REQUEST['inst']
        user_role = user_info.get('user_role', '').upper()
        
        if user_role == 'INSTITUTE':
            inst_code = user_info.get('inst_code', '')
        else:
            # RBTE/ADMIN: get inst from request
            inst_code = request.GET.get('inst') or request.POST.get('inst') or ''
        
        if not inst_code:
            messages.error(request, 'Please provide Institute Code.')
            return redirect('dashboard:exemption:exemption_home')
        
        # Clean and validate institute code
        try:
            inst_code_int = int(inst_code)
        except ValueError:
            messages.error(request, 'Invalid Institute Code. Please enter a valid numeric code.')
            return redirect('dashboard:exemption:exemption_home')

        # Step 3: Institute filter
        inst_filter, inst_params = get_institute_filter(inst_code)
        
        # Fix ambiguous column by adding table alias
        if inst_filter:
            inst_filter = inst_filter.replace('inst_code', 'e.inst_code')

        # Step 4: Connection
        conn = get_db_connection()

        # Step 5: Get institute info for region display (PHP: get_region_inst and get_region_name)
        inst_name = ""
        city_name = ""
        region_name = ""
        reg_id = None
        inst_code_formatted = ""
        
        if inst_code_int:
            inst_query = f"""
                SELECT inst_id, inst_name, city_name, reg_code
                FROM {msbte_config.INSTITUTES}
                WHERE inst_id = %s
                LIMIT 1
            """
            df_inst = pd.read_sql(inst_query, conn, params=[inst_code_int])

            if len(df_inst) > 0:
                inst_id_from_table = int(df_inst.iloc[0]['inst_id'])
                inst_code_formatted = str(inst_id_from_table).zfill(4)
                
                inst_name = df_inst.iloc[0]['inst_name'] if pd.notna(df_inst.iloc[0]['inst_name']) else ""
                city_name = df_inst.iloc[0]['city_name'] if pd.notna(df_inst.iloc[0]['city_name']) else ""
                
                if not inst_name:
                    inst_name = city_name if city_name else ""
                
                # Get region code and name (PHP: get_region_inst and get_region_name)
                if pd.notna(df_inst.iloc[0]['reg_code']):
                    reg_id = int(float(df_inst.iloc[0]['reg_code']))
                    try:
                        region_query = f"""
                            SELECT region_name 
                            FROM {msbte_config.REGION_MASTER}
                            WHERE reg_code = %s
                            LIMIT 1
                        """
                        df_region = pd.read_sql(region_query, conn, params=[reg_id])
                        if len(df_region) > 0 and pd.notna(df_region.iloc[0]['region_name']):
                            region_name = df_region.iloc[0]['region_name']
                    except:
                        pass
                    if not region_name:
                        region_code_map = {
                            5001: 'Mumbai',
                            5002: 'Pune',
                            5003: 'Nagpur',
                            5004: 'Chhatrapati Sambhaji Nagar (CSN)',
                        }
                        region_name = region_code_map.get(reg_id, '')

        # Step 6: Get Enrollment Year (PHP: ENROLL_YEAR)
        enroll_year = getattr(msbte_config, 'ENROLL_YEAR', '')

        # Step 7: Main query (PHP: select * from EXEMPTION_CAND_DETAILS where inst_code=? and inst_conf='Y' and rbte_conf='Y' order by enroll_no)
        main_query = f"""
            SELECT 
                e.enroll_no,
                e.elg_id,
                e.course_id,
                c.name AS candidate_name,
                e.rbte_conf_on
            FROM {msbte_config.EXEMPTION_CAND_DETAILS} e
            LEFT JOIN {msbte_config.CAND_INFO} c
                ON e.enroll_no = c.enroll_no
            WHERE e.inst_conf = 'Y' AND e.rbte_conf = 'Y' {inst_filter}
            ORDER BY e.enroll_no
        """

        df = pd.read_sql(main_query, conn, params=inst_params)

        candidates = []
        if len(df) > 0:
            df['sr_no'] = range(1, len(df) + 1)
            df['elg_id'] = df['elg_id'].fillna('NA')

            # Convert rbte_conf_on to string to preserve exact database format
            if 'rbte_conf_on' in df.columns:
                df['rbte_conf_on'] = df['rbte_conf_on'].apply(
                    lambda x: str(x) if pd.notna(x) else None
                )

            # Batch fetch course details
            unique_course_ids = df['course_id'].dropna().unique().tolist()
            course_lookup = {}
            if unique_course_ids:
                course_ids_str = ','.join([str(int(cid)) for cid in unique_course_ids if pd.notna(cid)])
                if course_ids_str:
                    course_query = f"""
                        SELECT course_id, course_name, course_code 
                        FROM {msbte_config.COURSES1} 
                        WHERE course_id IN ({course_ids_str})
                    """
                    course_df = pd.read_sql(course_query, conn)
                    for _, crow in course_df.iterrows():
                        course_lookup[int(crow['course_id'])] = {
                            'name': crow['course_name'],
                            'code': crow['course_code']
                        }

            for _, row in df.iterrows():
                # Get course code and name
                course_display = '-'
                if pd.notna(row['course_id']) and int(row['course_id']) in course_lookup:
                    course_info = course_lookup[int(row['course_id'])]
                    course_display = f"{course_info['code']}-{course_info['name']}"

                # Get exemption subjects
                subject_query = f"""
                    SELECT 
                        subject_name,
                        subject_abbr,
                        subject_thpr,
                        paper_code
                    FROM {msbte_config.ELG_EXEMPTION_DETAILS}
                    WHERE enroll_no = %s
                """
                sub_df = pd.read_sql(subject_query, conn, params=[row['enroll_no']])
                subjects = sub_df.to_dict('records') if len(sub_df) > 0 else []

                candidates.append({
                    'sr_no': row['sr_no'],
                    'enroll_no': row['enroll_no'],
                    'elg_id': row['elg_id'],
                    'candidate_name': row['candidate_name'],
                    'course_id': course_display,
                    'subjects': subjects,
                    'rbte_conf_on': row['rbte_conf_on'] if pd.notna(row['rbte_conf_on']) else None,
                })

        # Get Academic Year for header (PHP: EXAM_YEAR)
        aca_year = getattr(msbte_config, 'ACA_YEAR', '')
        academic_year = ""
        if aca_year:
            import re
            match = re.search(r'(\d{4})\s*-\s*(\d{2})', aca_year)
            if match:
                year1 = match.group(1)
                year2_short = match.group(2)
                year2 = f"20{year2_short}" if len(year2_short) == 2 else year2_short
                academic_year = f"{year1}-{year2}"
            else:
                current_year = datetime.now().year
                academic_year = f"{current_year}-{current_year + 1}"
        else:
            current_year = datetime.now().year
            academic_year = f"{current_year}-{current_year + 1}"

        # Get current date for document reference (DD-MM-YYYY format)
        current_date = datetime.now().strftime('%d-%m-%Y')

        context = {
            'report_title': 'Exemption RBTE Confirmed Candidates Report',
            'candidates': candidates,
            'total_count': len(candidates),
            'academic_year': academic_year,
            'enroll_year': enroll_year,
            'inst_code': inst_code,
            'inst_code_formatted': inst_code_formatted,
            'inst_name': inst_name,
            'city_name': city_name,
            'region_name': region_name,
            'reg_id': reg_id,
            'user_name': user_info['user_name'],
            'print_date': datetime.now().strftime('%d/%m/%Y'),
            'current_date': current_date,
        }

        return render(request, 'exemption_rbte_confirm.html', context)

    except Exception as e:
        logger.exception("Error in exemption_rbte_confirm (RBTE)")
        return handle_report_error(request, e, user_info.get('is_jwt', auth.get('is_jwt', False)))