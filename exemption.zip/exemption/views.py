from django.contrib.auth.decorators import login_required
from django.shortcuts import render

from dashboard.decorators import allowed_users


@login_required
@allowed_users(allowed_roles=['admin','client'])
def exemption_home(request):
    """Exemption home page mirroring enrollment dashboard layout."""
    return render(request, 'exemption_home.html')


