"""
Institute-specific eligibility views and reports
"""

