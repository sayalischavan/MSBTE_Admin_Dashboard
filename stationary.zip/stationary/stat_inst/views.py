from django.shortcuts import render, redirect
from django.urls import reverse
import logging
from datetime import datetime
import pandas as pd

import config.msbte_config as msbte_config
from dashboard.decorators import jwt_report_authorized
from dashboard.examform.views import _format_inst_code
from dashboard.utils import (
    get_auth_context,
    get_user_control_info,
    handle_report_error,
    get_db_connection,
    get_city_name,
    get_inst_name,
)

logger = logging.getLogger(__name__)


def _get_stationary_exam_center(request, auth, user_info, template_name):
    """
    Helper function to resolve exam center and validate stationery access.
    Extracted shared logic from report_32_stationary and report_32_supli_stationery.
    
    Args:
        request: Django request object
        auth: Auth context from get_auth_context
        user_info: User info from get_user_control_info
        template_name: Template name to render on error (e.g., 'stat_inst/report_32_stationary.html')
    
    Returns:
        tuple: (ec_id, dec_id, conn, error_response)
        - Success: (int, int, connection, None)
        - Error: (None, None, None, HttpResponse) - renders error on same page
    """
    # Extract user info
    is_admin = user_info['is_admin']
    uid = user_info.get('uid')
    
    # Step 1: Determine uid_int (institute code) - matching PHP: $uid = $_SESSION['USER_ID']
    uid_int = None
    
    if not is_admin:
        # INSTITUTE users: use USER_ID directly (matching PHP: $uid = $_SESSION['USER_ID'])
        if auth.get('is_jwt'):
            # JWT users: use institute_code from auth
            inst_code = auth.get('institute_code')
            if inst_code:
                try:
                    uid_int = int(str(inst_code).lstrip('0'))
                except (ValueError, TypeError):
                    error_message = 'You are not authorised user to view this report'
                    return None, None, None, render(request, template_name, {
                        'report_title': 'Error - Stationary Report',
                        'error_message': error_message,
                        'current_exam': getattr(msbte_config, 'ACA_NAME_EXAM_W', getattr(msbte_config, 'CURRENT_EXAM', msbte_config.EXAM_CODE)),
                        'user_name': user_info.get('user_name', 'User'),
                        'print_date': datetime.now().strftime('%d/%m/%Y'),
                    })
            else:
                error_message = 'You are not authorised user to view this report'
                return None, None, None, render(request, template_name, {
                    'report_title': 'Error - Stationary Report',
                    'error_message': error_message,
                    'current_exam': getattr(msbte_config, 'ACA_NAME_EXAM_W', getattr(msbte_config, 'CURRENT_EXAM', msbte_config.EXAM_CODE)),
                    'user_name': user_info.get('user_name', 'User'),
                    'print_date': datetime.now().strftime('%d/%m/%Y'),
                })
        else:
            # Session users: use USER_ID directly (matching PHP exactly)
            # PHP: $uid = $_SESSION['USER_ID']
            if uid:
                try:
                    uid_int = int(str(uid).lstrip('0'))
                except (ValueError, TypeError):
                    error_message = 'You are not authorised user to view this report'
                    return None, None, None, render(request, template_name, {
                        'report_title': 'Error - Stationary Report',
                        'error_message': error_message,
                        'current_exam': getattr(msbte_config, 'ACA_NAME_EXAM_W', getattr(msbte_config, 'CURRENT_EXAM', msbte_config.EXAM_CODE)),
                        'user_name': user_info.get('user_name', 'User'),
                        'print_date': datetime.now().strftime('%d/%m/%Y'),
                    })
            else:
                error_message = 'You are not authorised user to view this report'
                return None, None, None, render(request, template_name, {
                    'report_title': 'Error - Stationary Report',
                    'error_message': error_message,
                    'current_exam': getattr(msbte_config, 'ACA_NAME_EXAM_W', getattr(msbte_config, 'CURRENT_EXAM', msbte_config.EXAM_CODE)),
                    'user_name': user_info.get('user_name', 'User'),
                    'print_date': datetime.now().strftime('%d/%m/%Y'),
                })
    else:
        # ADMIN users: Admin has access to all institutes
        # If JWT token has institute_code, filter by that institute code
        # Otherwise, admin is not required to provide institute code
        # If instid parameter is provided, use it (optional)
        inst_code = None
        
        # Priority 1: Check JWT token for institute_code (if JWT authenticated)
        # If JWT has institute_code, use it to filter by that institute
        if auth.get('is_jwt'):
            inst_code = auth.get('institute_code')
        
        # Priority 2: If no JWT institute_code, use inst_code from user_info (from get_user_control_info)
        # This already handles instid parameter extraction - admin can optionally provide instid
        if not inst_code:
            inst_code = user_info.get('inst_code')
        
        # Admin is NOT required to provide institute code
        # Only use institute code if available (from JWT or optional instid parameter)
        if inst_code:
            # Convert institute code to integer
            try:
                uid_int = int(str(inst_code).lstrip('0'))
            except (ValueError, TypeError):
                error_message = "Invalid Institute Code"
                return None, None, None, render(request, template_name, {
                    'report_title': 'Error - Stationary Report',
                    'error_message': error_message,
                    'current_exam': getattr(msbte_config, 'ACA_NAME_EXAM_W', getattr(msbte_config, 'CURRENT_EXAM', msbte_config.EXAM_CODE)),
                    'user_name': user_info.get('user_name', 'User'),
                    'print_date': datetime.now().strftime('%d/%m/%Y'),
                })
        # If no institute code is available, uid_int remains None and will be handled below

    if not uid_int:
        # For admin users without institute code, return special flag to show form
        if is_admin:
            # Return special marker to indicate form should be shown
            return None, None, None, 'SHOW_FORM'
        else:
            error_message = "Institute code not found"
            return None, None, None, render(request, template_name, {
                'report_title': 'Error - Stationary Report',
                'error_message': error_message,
                'current_exam': getattr(msbte_config, 'ACA_NAME_EXAM_W', getattr(msbte_config, 'CURRENT_EXAM', msbte_config.EXAM_CODE)),
                'user_name': user_info.get('user_name', 'User'),
                'print_date': datetime.now().strftime('%d/%m/%Y'),
            })
    # Step 2: Get database connection
    conn = get_db_connection()
    
    # Step 3: Check if institute is exam center
    # PHP: select * from RAC_DC_DETAILS where exam_center=?
    rac_dc_query = f"""
        SELECT exam_center, dist_center, dist_regcode
        FROM {msbte_config.W25_RAC_DC_DETAILS}
        WHERE exam_center = %s
        LIMIT 1
    """
    df_rac_dc = pd.read_sql(rac_dc_query, conn, params=[uid_int])
    
    if len(df_rac_dc) == 0:
        error_message = "Sorry Your Institute Not Exam Center...!!!"
        return None, None, None, render(request, template_name, {
            'report_title': 'Error - Stationary Report',
            'error_message': error_message,
            'current_exam': getattr(msbte_config, 'ACA_NAME_EXAM_W', getattr(msbte_config, 'CURRENT_EXAM', msbte_config.EXAM_CODE)),
            'user_name': user_info.get('user_name', 'User'),
            'print_date': datetime.now().strftime('%d/%m/%Y'),
        })
    
    # PHP: $exam_center=$arrres['exam_center']; if($exam_center==$uid)
    exam_center = int(df_rac_dc.iloc[0]['exam_center']) if pd.notna(df_rac_dc.iloc[0]['exam_center']) else None
    
    # PHP: if($exam_center==$uid)
    if exam_center != uid_int:
        error_message = "Sorry Your Institute Not Exam Center...!!!"
        return None, None, None, render(request, template_name, {
            'report_title': 'Error - Stationary Report',
            'error_message': error_message,
            'current_exam': getattr(msbte_config, 'ACA_NAME_EXAM_W', getattr(msbte_config, 'CURRENT_EXAM', msbte_config.EXAM_CODE)),
            'user_name': user_info.get('user_name', 'User'),
            'print_date': datetime.now().strftime('%d/%m/%Y'),
        })
    
    # Step 4: Check stationery details
    # PHP: $ec_id=$exam_center; select ec_id from STATIONERY_DETAILS where ec_id=?
    ec_id = exam_center
    stationery_query = f"""
        SELECT ec_id
        FROM {msbte_config.S25_STATIONERY_DETAILS}
        WHERE ec_id = %s
        LIMIT 1
    """
    df_stationery = pd.read_sql(stationery_query, conn, params=[ec_id])
    
    if len(df_stationery) == 0:
        error_message = "Stationery details not found for this exam center"
        return None, None, None, render(request, template_name, {
            'report_title': 'Error - Stationary Report',
            'error_message': error_message,
            'current_exam': getattr(msbte_config, 'ACA_NAME_EXAM_W', getattr(msbte_config, 'CURRENT_EXAM', msbte_config.EXAM_CODE)),
            'user_name': user_info.get('user_name', 'User'),
            'print_date': datetime.now().strftime('%d/%m/%Y'),
        })
    
    # Step 5: Return success values
    dec_id = exam_center
    return ec_id, dec_id, conn, None


@jwt_report_authorized(allowed_roles=['INSTITUTE', 'ADMIN'])
def report_32_stationary(request):
    """
    Report of 32 page old sheet issued and used.
    PHP Reference: report_32_stationary
    Business Logic (from PHP):
    - PHP: $uid = $_SESSION['USER_ID'] (directly uses USER_ID as institute code)
    - Queries RAC_DC_DETAILS where exam_center=$uid
    - Checks if exam_center==$uid
    - Uses exam_center as ec_id and dec_id
    - Joins DAILY_STATIONERY_DETAILS with STATIONERY_DETAILS
    - Calculates opening balance, issued books, used books, and totals
    """
    # Step 1: Auth context
    auth, error = get_auth_context(request)
    if error:
        return error

    try:
        # Get user control info using standardized function
        user_info, error = get_user_control_info(
            request, auth,
            allowed_roles=['INSTITUTE', 'ADMIN'],
            require_institute_code=False,  # We'll extract manually to match PHP: $uid = $_SESSION['USER_ID']
            redirect_url='dashboard:stationary:stat_inst:report_32_stationary',
            error_message='You are not authorised user to view this report'
        )
        if error:
            return error
        
        # Check if admin needs to select institute (no JWT institute_code and no instid)
        is_admin = user_info.get('is_admin', False)
        if is_admin:
            # Check if JWT has institute_code
            jwt_inst_code = auth.get('institute_code') if auth.get('is_jwt') else None
            # Check if instid parameter is provided
            instid_param = request.GET.get('instid', '').strip() or request.POST.get('instid', '').strip()
            
            # If no JWT institute_code and no instid, show form
            if not jwt_inst_code and not instid_param:
                conn = get_db_connection()
                # Get all exam centers (institutes that are exam centers)
                exam_centers_query = f"""
                    SELECT DISTINCT r.exam_center, i.inst_name
                    FROM {msbte_config.W25_RAC_DC_DETAILS} r
                    INNER JOIN {msbte_config.INSTITUTES} i ON i.inst_id = r.exam_center
                    ORDER BY r.exam_center
                """
                df_exam_centers = pd.read_sql(exam_centers_query, conn)
                exam_centers = []
                for _, row in df_exam_centers.iterrows():
                    exam_centers.append({
                        'inst_id': int(row['exam_center']),
                        'inst_name': row['inst_name'] if pd.notna(row['inst_name']) else f"Institute {int(row['exam_center'])}"
                    })
                
                current_exam = getattr(msbte_config, 'ACA_NAME_EXAM_W', getattr(msbte_config, 'CURRENT_EXAM', msbte_config.EXAM_CODE))
                context = {
                    'report_title': 'Select Institute - Report of 32 Page Old Sheet',
                    'exam_centers': exam_centers,
                    'current_exam': current_exam,
                    'user_name': user_info.get('user_name', 'User'),
                    'print_date': datetime.now().strftime('%d/%m/%Y'),
                    'form_action': reverse('dashboard:stationary:stat_inst:report_32_stationary'),
                }
                return render(request, 'stat_inst/admin_select_institute.html', context)
        
        # Step 2: Resolve exam center and validate stationery access
        ec_id, dec_id, conn, error_response = _get_stationary_exam_center(
            request, auth, user_info, 'stat_inst/report_32_stationary.html'
        )
        if error_response:
            # Check if it's the special form marker
            if error_response == 'SHOW_FORM':
                # This shouldn't happen here since we handle it above, but just in case
                return redirect(reverse('dashboard:stationary:stat_inst:report_32_stationary'))
            return error_response
        
        # Step 3: Get daily stationery details
        # PHP: select D.exam_day,D.d32_issue_ans_book,D.duse_book_32_rem,D.d32_issue_supl_ans_book,
        #      D.duse_book_32_supl_rem,D.total_32_bal,D.total_32_supl_bal,S.book_32_rem,D.duse_sr_no_32_book
        #      from DAILY_STATIONERY_DETAILS D, STATIONERY_DETAILS S 
        #      where dec_id='$dec_id11' and S.ec_id=D.dec_id
        #      ORDER BY FIELD(D.exam_day, 'DAY1_MORNING', 'DAY1_AFTERNOON', ...)
        daily_query = f"""
            SELECT 
                D.exam_day,
                D.d32_issue_ans_book,
                D.duse_book_32_rem,
                D.d32_issue_supl_ans_book,
                D.duse_book_32_supl_rem,
                D.total_32_bal,
                D.total_32_supl_bal,
                S.book_32_rem,
                D.duse_sr_no_32_book
            FROM {msbte_config.W25_DAILY_STATIONERY_DETAILS} D
            INNER JOIN {msbte_config.STATIONERY_DETAILS} S ON S.ec_id = D.dec_id
            WHERE D.dec_id = %s
            ORDER BY FIELD(D.exam_day,
                'DAY1_MORNING', 'DAY1_AFTERNOON',
                'DAY2_MORNING', 'DAY2_AFTERNOON',
                'DAY3_MORNING', 'DAY3_AFTERNOON',
                'DAY4_MORNING', 'DAY4_AFTERNOON',
                'DAY5_MORNING', 'DAY5_AFTERNOON',
                'DAY6_MORNING', 'DAY6_AFTERNOON',
                'DAY7_MORNING', 'DAY7_AFTERNOON',
                'DAY8_MORNING', 'DAY8_AFTERNOON',
                'DAY9_MORNING', 'DAY9_AFTERNOON',
                'DAY10_MORNING', 'DAY10_AFTERNOON',
                'DAY11_MORNING', 'DAY11_AFTERNOON',
                'DAY12_MORNING', 'DAY12_AFTERNOON',
                'DAY13_MORNING', 'DAY13_AFTERNOON',
                'DAY14_MORNING', 'DAY14_AFTERNOON',
                'DAY15_MORNING', 'DAY15_AFTERNOON',
                'DAY16_MORNING', 'DAY16_AFTERNOON',
                'DAY17_MORNING', 'DAY17_AFTERNOON',
                'DAY18_MORNING', 'DAY18_AFTERNOON'
            )
        """
        df_daily = pd.read_sql(daily_query, conn, params=[dec_id])
        
        # Step 4: Process data similar to PHP logic
        # PHP logic:
        # $book_32_rem = $row2['book_32_rem'] - $total_duse_book_32_rem;
        # $duse_and_dissued_book_32_total = $row2['d32_issue_ans_book'] - $row2['duse_book_32_rem'];
        # $total_balance_opening = $book_32_rem - $row2['duse_book_32_rem'];
        # $total_duse_book_32_rem += $duse_book_32_rem;
        # $final_use_32_answer_book = $duse_book_32_rem + $final_use_32_answer_book;
        report_data = []
        total_duse_book_32_rem = 0
        final_use_32_answer_book = 0
        
        for idx, row in df_daily.iterrows():
            exam_day = row['exam_day'] if pd.notna(row['exam_day']) else ''
            duse_sr_no_32_book = row['duse_sr_no_32_book'] if pd.notna(row['duse_sr_no_32_book']) else ''
            book_32_rem_value = int(row['book_32_rem']) if pd.notna(row['book_32_rem']) else 0
            d32_issue_ans_book = int(row['d32_issue_ans_book']) if pd.notna(row['d32_issue_ans_book']) else 0
            duse_book_32_rem = int(row['duse_book_32_rem']) if pd.notna(row['duse_book_32_rem']) else 0
            
            # PHP: $book_32_rem=$row2['book_32_rem'] - $total_duse_book_32_rem;
            opening_balance = book_32_rem_value - total_duse_book_32_rem
            
            # PHP: $duse_and_dissued_book_32_total=$row2['d32_issue_ans_book'] - $row2['duse_book_32_rem'];
            duse_and_dissued_book_32_total = d32_issue_ans_book - duse_book_32_rem
            
            # PHP: $total_balance_opening=$book_32_rem - $row2['duse_book_32_rem'];
            total_balance_opening = opening_balance - duse_book_32_rem
            
            # PHP: $total_duse_book_32_rem += $duse_book_32_rem;
            total_duse_book_32_rem += duse_book_32_rem
            
            # PHP: $final_use_32_answer_book = $duse_book_32_rem + $final_use_32_answer_book;
            final_use_32_answer_book += duse_book_32_rem
            
            report_data.append({
                'sr_no': idx + 1,
                'exam_day': exam_day,
                'opening_balance': opening_balance,
                'd32_issue_ans_book': d32_issue_ans_book,
                'duse_book_32_rem': duse_book_32_rem,
                'duse_and_dissued_book_32_total': duse_and_dissued_book_32_total,
                'total_balance_opening': total_balance_opening,
                'duse_sr_no_32_book': duse_sr_no_32_book,
            })
        
        # Step 5: Get current exam name (matching PHP: CURRENT_EXAM)
        current_exam = getattr(msbte_config, 'ACA_NAME_EXAM_W', getattr(msbte_config, 'CURRENT_EXAM', msbte_config.EXAM_CODE))
        
        # Step 6: Get institute details (matching PHP: city_name($exam_center))
        inst_name = get_inst_name(ec_id)
        city_name_val = get_city_name(ec_id)
        ec_id_formatted = _format_inst_code(ec_id)
        
        context = {
            'report_title': 'Report of 32 Page Old Sheet Issued and Used',
            'report_data': report_data,
            'final_use_32_answer_book': final_use_32_answer_book,
            'current_exam': current_exam,
            'ec_id': ec_id_formatted,
            'inst_name': inst_name,
            'city_name': city_name_val,
            'user_name': user_info['user_name'],
            'print_date': datetime.now().strftime('%d/%m/%Y'),
        }

        return render(request, 'stat_inst/report_32_stationary.html', context)

    except Exception as e:
        logger.exception("Error in report_32_stationary")
        # Safely get is_jwt and user_name - variables might not be defined if error occurs early
        is_jwt = False
        user_name = 'User'
        if 'user_info' in locals():
            is_jwt = user_info.get('is_jwt', False)
            user_name = user_info.get('user_name', 'User')
        elif 'auth' in locals():
            is_jwt = auth.get('is_jwt', False)
            user_name = auth.get('user_name', 'User')
        
        return handle_report_error(
            request, e, 
            is_jwt,
            template_name='stat_inst/report_32_stationary.html',
            context={
                'report_title': 'Error - Report of 32 Page Old Sheet',
                'error_message': str(e),
                'current_exam': getattr(msbte_config, 'ACA_NAME_EXAM_W', getattr(msbte_config, 'CURRENT_EXAM', msbte_config.EXAM_CODE)),
                'user_name': user_name,
                'print_date': datetime.now().strftime('%d/%m/%Y'),
            }
        )


@jwt_report_authorized(allowed_roles=['INSTITUTE', 'ADMIN'])
def report_32_supli_stationery(request):
    """
    Report of 32 page old Supplement sheet issued and used.
    PHP Reference: report_32_supli_stationery
    Business Logic (from PHP):
    - PHP: $uid = $_SESSION['USER_ID'] (directly uses USER_ID as institute code)
    - Queries RAC_DC_DETAILS where exam_center=$uid
    - Checks if exam_center==$uid
    - Uses exam_center as ec_id and dec_id
    - Uses supplement fields: book_32_supl_rem, d32_issue_supl_ans_book, duse_book_32_supl_rem, duse_sr_no_32_suppl
    """
    # Step 1: Auth context
    auth, error = get_auth_context(request)
    if error:
        return error

    try:
        # Get user control info using standardized function
        user_info, error = get_user_control_info(
            request, auth,
            allowed_roles=['INSTITUTE', 'ADMIN'],
            require_institute_code=False,  # We'll extract manually to match PHP: $uid = $_SESSION['USER_ID']
            redirect_url='dashboard:stationary:stat_inst:report_32_supli_stationery',
            error_message='You are not authorised user to view this report'
        )
        if error:
            return error
        
        # Check if admin needs to select institute (no JWT institute_code and no instid)
        is_admin = user_info.get('is_admin', False)
        if is_admin:
            # Check if JWT has institute_code
            jwt_inst_code = auth.get('institute_code') if auth.get('is_jwt') else None
            # Check if instid parameter is provided
            instid_param = request.GET.get('instid', '').strip() or request.POST.get('instid', '').strip()
            
            # If no JWT institute_code and no instid, show form
            if not jwt_inst_code and not instid_param:
                conn = get_db_connection()
                # Get all exam centers (institutes that are exam centers)
                exam_centers_query = f"""
                    SELECT DISTINCT r.exam_center, i.inst_name
                    FROM {msbte_config.W25_RAC_DC_DETAILS} r
                    INNER JOIN {msbte_config.INSTITUTES} i ON i.inst_id = r.exam_center
                    ORDER BY r.exam_center
                """
                df_exam_centers = pd.read_sql(exam_centers_query, conn)
                exam_centers = []
                for _, row in df_exam_centers.iterrows():
                    exam_centers.append({
                        'inst_id': int(row['exam_center']),
                        'inst_name': row['inst_name'] if pd.notna(row['inst_name']) else f"Institute {int(row['exam_center'])}"
                    })
                
                current_exam = getattr(msbte_config, 'ACA_NAME_EXAM_W', getattr(msbte_config, 'CURRENT_EXAM', msbte_config.EXAM_CODE))
                context = {
                    'report_title': 'Select Institute - Report of 32 Page Old Supplement Sheet',
                    'exam_centers': exam_centers,
                    'current_exam': current_exam,
                    'user_name': user_info.get('user_name', 'User'),
                    'print_date': datetime.now().strftime('%d/%m/%Y'),
                    'form_action': reverse('dashboard:stationary:stat_inst:report_32_supli_stationery'),
                }
                return render(request, 'stat_inst/admin_select_institute.html', context)
        
        # Step 2: Resolve exam center and validate stationery access
        ec_id, dec_id, conn, error_response = _get_stationary_exam_center(
            request, auth, user_info, 'stat_inst/report_32_supli_stationery.html'
        )
        if error_response:
            # Check if it's the special form marker
            if error_response == 'SHOW_FORM':
                # This shouldn't happen here since we handle it above, but just in case
                return redirect(reverse('dashboard:stationary:stat_inst:report_32_supli_stationery'))
            return error_response
        
        # Step 3: Get daily stationery details for supplement sheets
        # PHP: select S.book_32_supl_rem,D.exam_day,D.d32_issue_supl_ans_book,D.duse_book_32_supl_rem,duse_sr_no_32_suppl 
        #      from DAILY_STATIONERY_DETAILS D, STATIONERY_DETAILS S where dec_id='$dec_id11' and S.ec_id=D.dec_id
        daily_query = f"""
            SELECT 
                D.exam_day,
                D.d32_issue_supl_ans_book,
                D.duse_book_32_supl_rem,
                D.duse_sr_no_32_suppl,
                S.book_32_supl_rem
            FROM {msbte_config.W25_DAILY_STATIONERY_DETAILS} D
            INNER JOIN {msbte_config.STATIONERY_DETAILS} S ON S.ec_id = D.dec_id
            WHERE D.dec_id = %s
            ORDER BY FIELD(D.exam_day,
                'DAY1_MORNING', 'DAY1_AFTERNOON',
                'DAY2_MORNING', 'DAY2_AFTERNOON',
                'DAY3_MORNING', 'DAY3_AFTERNOON',
                'DAY4_MORNING', 'DAY4_AFTERNOON',
                'DAY5_MORNING', 'DAY5_AFTERNOON',
                'DAY6_MORNING', 'DAY6_AFTERNOON',
                'DAY7_MORNING', 'DAY7_AFTERNOON',
                'DAY8_MORNING', 'DAY8_AFTERNOON',
                'DAY9_MORNING', 'DAY9_AFTERNOON',
                'DAY10_MORNING', 'DAY10_AFTERNOON',
                'DAY11_MORNING', 'DAY11_AFTERNOON',
                'DAY12_MORNING', 'DAY12_AFTERNOON',
                'DAY13_MORNING', 'DAY13_AFTERNOON',
                'DAY14_MORNING', 'DAY14_AFTERNOON',
                'DAY15_MORNING', 'DAY15_AFTERNOON',
                'DAY16_MORNING', 'DAY16_AFTERNOON',
                'DAY17_MORNING', 'DAY17_AFTERNOON',
                'DAY18_MORNING', 'DAY18_AFTERNOON'
            )
        """
        df_daily = pd.read_sql(daily_query, conn, params=[dec_id])
        
        # Step 4: Process data similar to PHP logic for supplement sheets
        # PHP: $book_32_supl_rem=$row2['book_32_supl_rem'] - $total_duse_book_32_supli_rem;
        #      $total_duse_book_32_supli_rem += $duse_book_32_supl_rem;
        #      $final_use_32_answer_supli_book = $duse_book_32_supl_rem + $final_use_32_answer_supli_book;
        report_data = []
        total_duse_book_32_supli_rem = 0
        final_use_32_answer_supli_book = 0
        
        for idx, row in df_daily.iterrows():
            exam_day = row['exam_day'] if pd.notna(row['exam_day']) else ''
            duse_sr_no_32_suppl = row['duse_sr_no_32_suppl'] if pd.notna(row['duse_sr_no_32_suppl']) else ''
            book_32_supl_rem = int(row['book_32_supl_rem']) if pd.notna(row['book_32_supl_rem']) else 0
            d32_issue_supl_ans_book = int(row['d32_issue_supl_ans_book']) if pd.notna(row['d32_issue_supl_ans_book']) else 0
            duse_book_32_supl_rem = int(row['duse_book_32_supl_rem']) if pd.notna(row['duse_book_32_supl_rem']) else 0
            
            # PHP: $book_32_supl_rem=$row2['book_32_supl_rem'] - $total_duse_book_32_supli_rem;
            opening_balance = book_32_supl_rem - total_duse_book_32_supli_rem
            # PHP: $duse_and_dissued_book_32_supli_total=$row2['d32_issue_supl_ans_book'] - $row2['duse_book_32_supl_rem'];
            duse_and_dissued_book_32_supli_total = d32_issue_supl_ans_book - duse_book_32_supl_rem
            # PHP: $total_balance_opening=$book_32_supl_rem - $row2['duse_book_32_supl_rem'];
            total_balance_opening = opening_balance - duse_book_32_supl_rem
            
            # PHP: $total_duse_book_32_supli_rem += $duse_book_32_supl_rem;
            total_duse_book_32_supli_rem += duse_book_32_supl_rem
            # PHP: $final_use_32_answer_supli_book = $duse_book_32_supl_rem + $final_use_32_answer_supli_book;
            final_use_32_answer_supli_book += duse_book_32_supl_rem
            
            report_data.append({
                'sr_no': idx + 1,
                'exam_day': exam_day,
                'opening_balance': opening_balance,
                'd32_issue_supl_ans_book': d32_issue_supl_ans_book,
                'duse_book_32_supl_rem': duse_book_32_supl_rem,
                'duse_and_dissued_book_32_supli_total': duse_and_dissued_book_32_supli_total,
                'total_balance_opening': total_balance_opening,
                'duse_sr_no_32_suppl': duse_sr_no_32_suppl,
            })
        
        # Step 5: Get current exam name
        current_exam = getattr(msbte_config, 'ACA_NAME_EXAM_W', msbte_config.EXAM_CODE)
        
        # Step 6: Get institute details
        inst_name = get_inst_name(ec_id)
        city_name_val = get_city_name(ec_id)
        ec_id_formatted = _format_inst_code(ec_id)
        
        context = {
            'report_title': 'Report of 32 Page Old Supplement Sheet Issued and Used',
            'report_data': report_data,
            'final_use_32_answer_supli_book': final_use_32_answer_supli_book,
            'current_exam': current_exam,
            'ec_id': ec_id_formatted,
            'inst_name': inst_name,
            'city_name': city_name_val,
            'user_name': user_info['user_name'],
            'print_date': datetime.now().strftime('%d/%m/%Y'),
        }

        return render(request, 'stat_inst/report_32_supli_stationery.html', context)

    except Exception as e:
        logger.exception("Error in report_32_supli_stationery")
        # Safely get is_jwt and user_name - variables might not be defined if error occurs early
        is_jwt = False
        user_name = 'User'
        if 'user_info' in locals():
            is_jwt = user_info.get('is_jwt', False)
            user_name = user_info.get('user_name', 'User')
        elif 'auth' in locals():
            is_jwt = auth.get('is_jwt', False)
            user_name = auth.get('user_name', 'User')
        
        return handle_report_error(
            request, e,
            is_jwt,
            template_name='stat_inst/report_32_supli_stationery.html',
            context={
                'report_title': 'Error - Report of 32 Page Old Supplement Sheet',
                'error_message': str(e),
                'current_exam': getattr(msbte_config, 'ACA_NAME_EXAM_W', msbte_config.EXAM_CODE),
                'user_name': user_name,
                'print_date': datetime.now().strftime('%d/%m/%Y'),
            }
        )

@jwt_report_authorized(allowed_roles=['INSTITUTE', 'ADMIN'])
def report_32_barcode_stationery(request):
    """
    Report of 32 page Barcode sheet issued and used.
    PHP Reference: uses d32_code_issue_ans_book, duse_book_code_32_rem, book_code_32_rem, duse_sr_no_32_book_code
    Business Logic (from PHP):
    - Same exam center / stationery checks as other 32-page reports
    - Uses barcode/code fields: book_code_32_rem (S), d32_code_issue_ans_book, duse_book_code_32_rem, duse_sr_no_32_book_code (D)
    """
    auth, error = get_auth_context(request)
    if error:
        return error

    try:
        user_info, error = get_user_control_info(
            request, auth,
            allowed_roles=['INSTITUTE', 'ADMIN'],
            require_institute_code=False,
            redirect_url='dashboard:stationary:stat_inst:report_32_barcode_stationery',
            error_message='You are not authorised user to view this report'
        )
        if error:
            return error

        is_admin = user_info.get('is_admin', False)
        if is_admin:
            jwt_inst_code = auth.get('institute_code') if auth.get('is_jwt') else None
            instid_param = request.GET.get('instid', '').strip() or request.POST.get('instid', '').strip()

            if not jwt_inst_code and not instid_param:
                conn = get_db_connection()
                exam_centers_query = f"""
                    SELECT DISTINCT r.exam_center, i.inst_name
                    FROM {msbte_config.W25_RAC_DC_DETAILS} r
                    INNER JOIN {msbte_config.INSTITUTES} i ON i.inst_id = r.exam_center
                    ORDER BY r.exam_center
                """
                df_exam_centers = pd.read_sql(exam_centers_query, conn)
                exam_centers = [
                    {'inst_id': int(row['exam_center']), 'inst_name': row['inst_name'] if pd.notna(row['inst_name']) else f"Institute {int(row['exam_center'])}"}
                    for _, row in df_exam_centers.iterrows()
                ]
                current_exam = getattr(msbte_config, 'ACA_NAME_EXAM_W', getattr(msbte_config, 'CURRENT_EXAM', msbte_config.EXAM_CODE))
                context = {
                    'report_title': 'Select Institute - 32 Page Barcode Sheet Report',
                    'exam_centers': exam_centers,
                    'current_exam': current_exam,
                    'user_name': user_info.get('user_name', 'User'),
                    'print_date': datetime.now().strftime('%d/%m/%Y'),
                    'form_action': reverse('dashboard:stationary:stat_inst:report_32_barcode_stationery'),
                }
                return render(request, 'stat_inst/admin_select_institute.html', context)

        ec_id, dec_id, conn, error_response = _get_stationary_exam_center(
            request, auth, user_info, 'stat_inst/report_32_barcode_stationery.html'
        )
        if error_response:
            if error_response == 'SHOW_FORM':
                return redirect(reverse('dashboard:stationary:stat_inst:report_32_barcode_stationery'))
            return error_response

        # PHP: select D.exam_day,D.d32_code_issue_ans_book,D.duse_book_code_32_rem,S.book_code_32_rem,D.duse_sr_no_32_book_code
        #      from DAILY_STATIONERY_DETAILS D, STATIONERY_DETAILS S where dec_id='$dec_id11' and S.ec_id=D.dec_id
        daily_query = f"""
            SELECT
                D.exam_day,
                D.d32_code_issue_ans_book,
                D.duse_book_code_32_rem,
                D.duse_sr_no_32_book_code,
                S.book_code_32_rem
            FROM {msbte_config.W25_DAILY_STATIONERY_DETAILS} D
            INNER JOIN {msbte_config.STATIONERY_DETAILS} S ON S.ec_id = D.dec_id
            WHERE D.dec_id = %s
            ORDER BY FIELD(D.exam_day,
                'DAY1_MORNING', 'DAY1_AFTERNOON', 'DAY2_MORNING', 'DAY2_AFTERNOON',
                'DAY3_MORNING', 'DAY3_AFTERNOON', 'DAY4_MORNING', 'DAY4_AFTERNOON',
                'DAY5_MORNING', 'DAY5_AFTERNOON', 'DAY6_MORNING', 'DAY6_AFTERNOON',
                'DAY7_MORNING', 'DAY7_AFTERNOON', 'DAY8_MORNING', 'DAY8_AFTERNOON',
                'DAY9_MORNING', 'DAY9_AFTERNOON', 'DAY10_MORNING', 'DAY10_AFTERNOON',
                'DAY11_MORNING', 'DAY11_AFTERNOON', 'DAY12_MORNING', 'DAY12_AFTERNOON',
                'DAY13_MORNING', 'DAY13_AFTERNOON', 'DAY14_MORNING', 'DAY14_AFTERNOON',
                'DAY15_MORNING', 'DAY15_AFTERNOON', 'DAY16_MORNING', 'DAY16_AFTERNOON',
                'DAY17_MORNING', 'DAY17_AFTERNOON', 'DAY18_MORNING', 'DAY18_AFTERNOON'
            )
        """
        df_daily = pd.read_sql(daily_query, conn, params=[dec_id])

        report_data = []
        total_duse_book_code_32_rem = 0
        final_use_32_answer_book = 0

        for idx, row in df_daily.iterrows():
            exam_day = row['exam_day'] if pd.notna(row['exam_day']) else ''
            duse_sr_no_32_book_code = row['duse_sr_no_32_book_code'] if pd.notna(row['duse_sr_no_32_book_code']) else ''
            book_code_32_rem = int(row['book_code_32_rem']) if pd.notna(row['book_code_32_rem']) else 0
            d32_code_issue_ans_book = int(row['d32_code_issue_ans_book']) if pd.notna(row['d32_code_issue_ans_book']) else 0
            duse_book_code_32_rem = int(row['duse_book_code_32_rem']) if pd.notna(row['duse_book_code_32_rem']) else 0

            opening_balance = book_code_32_rem - total_duse_book_code_32_rem
            duse_and_dissued_book_32_total = d32_code_issue_ans_book - duse_book_code_32_rem
            total_balance_opening = opening_balance - duse_book_code_32_rem

            total_duse_book_code_32_rem += duse_book_code_32_rem
            final_use_32_answer_book += duse_book_code_32_rem

            report_data.append({
                'sr_no': idx + 1,
                'exam_day': exam_day,
                'opening_balance': opening_balance,
                'd32_code_issue_ans_book': d32_code_issue_ans_book,
                'duse_book_code_32_rem': duse_book_code_32_rem,
                'duse_and_dissued_book_32_total': duse_and_dissued_book_32_total,
                'total_balance_opening': total_balance_opening,
                'duse_sr_no_32_book_code': duse_sr_no_32_book_code,
            })

        current_exam = getattr(msbte_config, 'ACA_NAME_EXAM_W', msbte_config.EXAM_CODE)
        inst_name = get_inst_name(ec_id)
        city_name_val = get_city_name(ec_id)
        ec_id_formatted = _format_inst_code(ec_id)

        context = {
            'report_title': 'Report of 32 Page Barcode Sheet Issued and Used',
            'report_data': report_data,
            'final_use_32_answer_book': final_use_32_answer_book,
            'current_exam': current_exam,
            'ec_id': ec_id_formatted,
            'inst_name': inst_name,
            'city_name': city_name_val,
            'user_name': user_info['user_name'],
            'print_date': datetime.now().strftime('%d/%m/%Y'),
        }

        return render(request, 'stat_inst/report_32_barcode_stationery.html', context)

    except Exception as e:
        logger.exception("Error in report_32_barcode_stationery")
        is_jwt = user_info.get('is_jwt', False) if 'user_info' in locals() else (auth.get('is_jwt', False) if 'auth' in locals() else False)
        user_name = user_info.get('user_name', 'User') if 'user_info' in locals() else (auth.get('user_name', 'User') if 'auth' in locals() else 'User')
        return handle_report_error(
            request, e,
            is_jwt,
            template_name='stat_inst/report_32_barcode_stationery.html',
            context={
                'report_title': 'Error - 32 Page Barcode Sheet Report',
                'error_message': str(e),
                'current_exam': getattr(msbte_config, 'ACA_NAME_EXAM_W', msbte_config.EXAM_CODE),
                'user_name': user_name,
                'print_date': datetime.now().strftime('%d/%m/%Y'),
            }
        )

@jwt_report_authorized(allowed_roles=['INSTITUTE', 'ADMIN'])
def report_32_barcode_supli_stationery(request):
    """
    Report of 32 page Barcode Supplement sheet issued and used.
    PHP Reference: uses d32_code_issue_supl_ans_book, duse_book_code_32_supl_rem, book_code_32_supl_rem, duse_sr_no_32_suppl_code
    Business Logic (from PHP):
    - Same exam center / stationery checks as other 32-page reports
    - Uses barcode supplement fields: book_code_32_supl_rem (S), d32_code_issue_supl_ans_book, duse_book_code_32_supl_rem, duse_sr_no_32_suppl_code (D)
    """
    auth, error = get_auth_context(request)
    if error:
        return error

    try:
        user_info, error = get_user_control_info(
            request, auth,
            allowed_roles=['INSTITUTE', 'ADMIN'],
            require_institute_code=False,
            redirect_url='dashboard:stationary:stat_inst:report_32_barcode_supli_stationery',
            error_message='You are not authorised user to view this report'
        )
        if error:
            return error

        is_admin = user_info.get('is_admin', False)
        if is_admin:
            jwt_inst_code = auth.get('institute_code') if auth.get('is_jwt') else None
            instid_param = request.GET.get('instid', '').strip() or request.POST.get('instid', '').strip()

            if not jwt_inst_code and not instid_param:
                conn = get_db_connection()
                exam_centers_query = f"""
                    SELECT DISTINCT r.exam_center, i.inst_name
                    FROM {msbte_config.W25_RAC_DC_DETAILS} r
                    INNER JOIN {msbte_config.INSTITUTES} i ON i.inst_id = r.exam_center
                    ORDER BY r.exam_center
                """
                df_exam_centers = pd.read_sql(exam_centers_query, conn)
                exam_centers = [
                    {'inst_id': int(row['exam_center']), 'inst_name': row['inst_name'] if pd.notna(row['inst_name']) else f"Institute {int(row['exam_center'])}"}
                    for _, row in df_exam_centers.iterrows()
                ]
                current_exam = getattr(msbte_config, 'ACA_NAME_EXAM_W', getattr(msbte_config, 'CURRENT_EXAM', msbte_config.EXAM_CODE))
                context = {
                    'report_title': 'Select Institute - 32 Page Barcode Supplement Sheet Report',
                    'exam_centers': exam_centers,
                    'current_exam': current_exam,
                    'user_name': user_info.get('user_name', 'User'),
                    'print_date': datetime.now().strftime('%d/%m/%Y'),
                    'form_action': reverse('dashboard:stationary:stat_inst:report_32_barcode_supli_stationery'),
                }
                return render(request, 'stat_inst/admin_select_institute.html', context)

        ec_id, dec_id, conn, error_response = _get_stationary_exam_center(
            request, auth, user_info, 'stat_inst/report_32_barcode_supli_stationery.html'
        )
        if error_response:
            if error_response == 'SHOW_FORM':
                return redirect(reverse('dashboard:stationary:stat_inst:report_32_barcode_supli_stationery'))
            return error_response

        # PHP: select D.exam_day,D.d32_code_issue_supl_ans_book,D.duse_book_code_32_supl_rem,S.book_code_32_supl_rem,D.duse_sr_no_32_suppl_code
        #      from DAILY_STATIONERY_DETAILS D, STATIONERY_DETAILS S where dec_id='$dec_id11' and S.ec_id=D.dec_id
        daily_query = f"""
            SELECT
                D.exam_day,
                D.d32_code_issue_supl_ans_book,
                D.duse_book_code_32_supl_rem,
                D.duse_sr_no_32_suppl_code,
                S.book_code_32_supl_rem
            FROM {msbte_config.W25_DAILY_STATIONERY_DETAILS} D
            INNER JOIN {msbte_config.STATIONERY_DETAILS} S ON S.ec_id = D.dec_id
            WHERE D.dec_id = %s
            ORDER BY FIELD(D.exam_day,
                'DAY1_MORNING', 'DAY1_AFTERNOON', 'DAY2_MORNING', 'DAY2_AFTERNOON',
                'DAY3_MORNING', 'DAY3_AFTERNOON', 'DAY4_MORNING', 'DAY4_AFTERNOON',
                'DAY5_MORNING', 'DAY5_AFTERNOON', 'DAY6_MORNING', 'DAY6_AFTERNOON',
                'DAY7_MORNING', 'DAY7_AFTERNOON', 'DAY8_MORNING', 'DAY8_AFTERNOON',
                'DAY9_MORNING', 'DAY9_AFTERNOON', 'DAY10_MORNING', 'DAY10_AFTERNOON',
                'DAY11_MORNING', 'DAY11_AFTERNOON', 'DAY12_MORNING', 'DAY12_AFTERNOON',
                'DAY13_MORNING', 'DAY13_AFTERNOON', 'DAY14_MORNING', 'DAY14_AFTERNOON',
                'DAY15_MORNING', 'DAY15_AFTERNOON', 'DAY16_MORNING', 'DAY16_AFTERNOON',
                'DAY17_MORNING', 'DAY17_AFTERNOON', 'DAY18_MORNING', 'DAY18_AFTERNOON'
            )
        """
        df_daily = pd.read_sql(daily_query, conn, params=[dec_id])

        report_data = []
        total_duse_book_code_32_supl_rem = 0
        final_use_32_answer_book = 0

        for idx, row in df_daily.iterrows():
            exam_day = row['exam_day'] if pd.notna(row['exam_day']) else ''
            duse_sr_no_32_suppl_code = row['duse_sr_no_32_suppl_code'] if pd.notna(row['duse_sr_no_32_suppl_code']) else ''
            book_code_32_supl_rem = int(row['book_code_32_supl_rem']) if pd.notna(row['book_code_32_supl_rem']) else 0
            d32_code_issue_supl_ans_book = int(row['d32_code_issue_supl_ans_book']) if pd.notna(row['d32_code_issue_supl_ans_book']) else 0
            duse_book_code_32_supl_rem = int(row['duse_book_code_32_supl_rem']) if pd.notna(row['duse_book_code_32_supl_rem']) else 0

            # PHP: $book_code_32_supl_rem=$row2['book_code_32_supl_rem'] - $total_duse_book_code_32_supl_rem;
            opening_balance = book_code_32_supl_rem - total_duse_book_code_32_supl_rem
            # PHP: $duse_and_dissued_book_32_total=$row2['d32_code_issue_supl_ans_book'] - $row2['duse_book_code_32_supl_rem'];
            duse_and_dissued_book_32_total = d32_code_issue_supl_ans_book - duse_book_code_32_supl_rem
            # PHP: $total_balance_opening=$book_code_32_supl_rem - $row2['duse_book_code_32_supl_rem'];
            total_balance_opening = opening_balance - duse_book_code_32_supl_rem

            # PHP: $total_duse_book_code_32_supl_rem += $duse_book_code_32_supl_rem;
            total_duse_book_code_32_supl_rem += duse_book_code_32_supl_rem
            # PHP: $final_use_32_answer_book = $duse_book_code_32_supl_rem + $final_use_32_answer_book;
            final_use_32_answer_book += duse_book_code_32_supl_rem

            report_data.append({
                'sr_no': idx + 1,
                'exam_day': exam_day,
                'opening_balance': opening_balance,
                'd32_code_issue_supl_ans_book': d32_code_issue_supl_ans_book,
                'duse_book_code_32_supl_rem': duse_book_code_32_supl_rem,
                'duse_and_dissued_book_32_total': duse_and_dissued_book_32_total,
                'total_balance_opening': total_balance_opening,
                'duse_sr_no_32_suppl_code': duse_sr_no_32_suppl_code,
            })

        current_exam = getattr(msbte_config, 'ACA_NAME_EXAM_W', getattr(msbte_config, 'CURRENT_EXAM', msbte_config.EXAM_CODE))
        inst_name = get_inst_name(ec_id)
        city_name_val = get_city_name(ec_id)
        ec_id_formatted = _format_inst_code(ec_id)

        context = {
            'report_title': 'Report of 32 page Barcode Supplement sheet issued and used.',
            'report_data': report_data,
            'final_use_32_answer_book': final_use_32_answer_book,
            'current_exam': current_exam,
            'ec_id': ec_id_formatted,
            'inst_name': inst_name,
            'city_name': city_name_val,
            'user_name': user_info['user_name'],
            'print_date': datetime.now().strftime('%d/%m/%Y'),
        }

        return render(request, 'stat_inst/report_32_barcode_supli_stationery.html', context)

    except Exception as e:
        logger.exception("Error in report_32_barcode_supli_stationery")
        is_jwt = user_info.get('is_jwt', False) if 'user_info' in locals() else (auth.get('is_jwt', False) if 'auth' in locals() else False)
        user_name = user_info.get('user_name', 'User') if 'user_info' in locals() else (auth.get('user_name', 'User') if 'auth' in locals() else 'User')
        return handle_report_error(
            request, e,
            is_jwt,
            template_name='stat_inst/report_32_barcode_supli_stationery.html',
            context={
                'report_title': 'Error - 32 Page Barcode Supplement Sheet Report',
                'error_message': str(e),
                'current_exam': getattr(msbte_config, 'ACA_NAME_EXAM_W', getattr(msbte_config, 'CURRENT_EXAM', msbte_config.EXAM_CODE)),
                'user_name': user_name,
                'print_date': datetime.now().strftime('%d/%m/%Y'),
            }
        )

@jwt_report_authorized(allowed_roles=['INSTITUTE', 'ADMIN'])
def report_drwing_stationary(request):
    """
    Report of Drawing Sheet issued and used.
    PHP Reference: report_drwing_stationary
    Business Logic (from PHP):
    - PHP: $uid = $_SESSION['USER_ID'] (directly uses USER_ID as institute code)
    - Queries RAC_DC_DETAILS where exam_center=$uid
    - Checks if exam_center==$uid
    - Uses exam_center as ec_id and dec_id
    - Uses drawing fields: drawing_book_rem (S), ddrawing_issue_ans_book, duse_drawing_book_rem, duse_sr_no_drawing_book (D)
    """
    auth, error = get_auth_context(request)
    if error:
        return error

    try:
        user_info, error = get_user_control_info(
            request, auth,
            allowed_roles=['INSTITUTE', 'ADMIN'],
            require_institute_code=False,
            redirect_url='dashboard:stationary:stat_inst:report_drwing_stationary',
            error_message='You are not authorised user to view this report'
        )
        if error:
            return error

        is_admin = user_info.get('is_admin', False)
        if is_admin:
            jwt_inst_code = auth.get('institute_code') if auth.get('is_jwt') else None
            instid_param = request.GET.get('instid', '').strip() or request.POST.get('instid', '').strip()

            if not jwt_inst_code and not instid_param:
                conn = get_db_connection()
                exam_centers_query = f"""
                    SELECT DISTINCT r.exam_center, i.inst_name
                    FROM {msbte_config.W25_RAC_DC_DETAILS} r
                    INNER JOIN {msbte_config.INSTITUTES} i ON i.inst_id = r.exam_center
                    ORDER BY r.exam_center
                """
                df_exam_centers = pd.read_sql(exam_centers_query, conn)
                exam_centers = [
                    {'inst_id': int(row['exam_center']), 'inst_name': row['inst_name'] if pd.notna(row['inst_name']) else f"Institute {int(row['exam_center'])}"}
                    for _, row in df_exam_centers.iterrows()
                ]
                current_exam = getattr(msbte_config, 'ACA_NAME_EXAM_W', getattr(msbte_config, 'CURRENT_EXAM', msbte_config.EXAM_CODE))
                context = {
                    'report_title': 'Select Institute - Drawing Sheet Report',
                    'exam_centers': exam_centers,
                    'current_exam': current_exam,
                    'user_name': user_info.get('user_name', 'User'),
                    'print_date': datetime.now().strftime('%d/%m/%Y'),
                    'form_action': reverse('dashboard:stationary:stat_inst:report_drwing_stationary'),
                }
                return render(request, 'stat_inst/admin_select_institute.html', context)

        ec_id, dec_id, conn, error_response = _get_stationary_exam_center(
            request, auth, user_info, 'stat_inst/report_drwing_stationary.html'
        )
        if error_response:
            if error_response == 'SHOW_FORM':
                return redirect(reverse('dashboard:stationary:stat_inst:report_drwing_stationary'))
            return error_response

        # PHP: select S.drawing_book_rem,D.exam_day,D.ddrawing_issue_ans_book,D.duse_drawing_book_rem,D.duse_sr_no_drawing_book
        #      from DAILY_STATIONERY_DETAILS D, STATIONERY_DETAILS S where dec_id='$dec_id11' and S.ec_id=D.dec_id
        daily_query = f"""
            SELECT
                D.exam_day,
                D.ddrawing_issue_ans_book,
                D.duse_drawing_book_rem,
                D.duse_sr_no_drawing_book,
                S.drawing_book_rem
            FROM {msbte_config.W25_DAILY_STATIONERY_DETAILS} D
            INNER JOIN {msbte_config.STATIONERY_DETAILS} S ON S.ec_id = D.dec_id
            WHERE D.dec_id = %s
            ORDER BY FIELD(D.exam_day,
                'DAY1_MORNING', 'DAY1_AFTERNOON', 'DAY2_MORNING', 'DAY2_AFTERNOON',
                'DAY3_MORNING', 'DAY3_AFTERNOON', 'DAY4_MORNING', 'DAY4_AFTERNOON',
                'DAY5_MORNING', 'DAY5_AFTERNOON', 'DAY6_MORNING', 'DAY6_AFTERNOON',
                'DAY7_MORNING', 'DAY7_AFTERNOON', 'DAY8_MORNING', 'DAY8_AFTERNOON',
                'DAY9_MORNING', 'DAY9_AFTERNOON', 'DAY10_MORNING', 'DAY10_AFTERNOON',
                'DAY11_MORNING', 'DAY11_AFTERNOON', 'DAY12_MORNING', 'DAY12_AFTERNOON',
                'DAY13_MORNING', 'DAY13_AFTERNOON', 'DAY14_MORNING', 'DAY14_AFTERNOON',
                'DAY15_MORNING', 'DAY15_AFTERNOON', 'DAY16_MORNING', 'DAY16_AFTERNOON',
                'DAY17_MORNING', 'DAY17_AFTERNOON', 'DAY18_MORNING', 'DAY18_AFTERNOON'
            )
        """
        df_daily = pd.read_sql(daily_query, conn, params=[dec_id])

        report_data = []
        total_duse_drawing_book_rem = 0
        final_duse_drawing_book_rem = 0

        for idx, row in df_daily.iterrows():
            exam_day = row['exam_day'] if pd.notna(row['exam_day']) else ''
            duse_sr_no_drawing_book = row['duse_sr_no_drawing_book'] if pd.notna(row['duse_sr_no_drawing_book']) else ''
            drawing_book_rem = int(row['drawing_book_rem']) if pd.notna(row['drawing_book_rem']) else 0
            ddrawing_issue_ans_book = int(row['ddrawing_issue_ans_book']) if pd.notna(row['ddrawing_issue_ans_book']) else 0
            duse_drawing_book_rem = int(row['duse_drawing_book_rem']) if pd.notna(row['duse_drawing_book_rem']) else 0

            # PHP: $drawing_book_rem=$row2['drawing_book_rem'] - $total_duse_drawing_book_rem;
            opening_balance = drawing_book_rem - total_duse_drawing_book_rem
            # PHP: $duse_and_dissued_book_32_total=$row2['ddrawing_issue_ans_book'] - $row2['duse_drawing_book_rem'];
            duse_and_dissued_book_32_total = ddrawing_issue_ans_book - duse_drawing_book_rem
            # PHP: $total_balance_opening=$drawing_book_rem - $row2['duse_drawing_book_rem'];
            total_balance_opening = opening_balance - duse_drawing_book_rem

            # PHP: $total_duse_drawing_book_rem += $duse_drawing_book_rem;
            total_duse_drawing_book_rem += duse_drawing_book_rem
            # PHP: $final_duse_drawing_book_rem = $duse_drawing_book_rem + $final_duse_drawing_book_rem;
            final_duse_drawing_book_rem += duse_drawing_book_rem

            report_data.append({
                'sr_no': idx + 1,
                'exam_day': exam_day,
                'opening_balance': opening_balance,
                'ddrawing_issue_ans_book': ddrawing_issue_ans_book,
                'duse_drawing_book_rem': duse_drawing_book_rem,
                'duse_and_dissued_book_32_total': duse_and_dissued_book_32_total,
                'total_balance_opening': total_balance_opening,
                'duse_sr_no_drawing_book': duse_sr_no_drawing_book,
            })

        current_exam = getattr(msbte_config, 'ACA_NAME_EXAM_W', getattr(msbte_config, 'CURRENT_EXAM', msbte_config.EXAM_CODE))
        inst_name = get_inst_name(ec_id)
        city_name_val = get_city_name(ec_id)
        ec_id_formatted = _format_inst_code(ec_id)

        context = {
            'report_title': 'Report Of Drawing Sheet Issued and Used.',
            'report_data': report_data,
            'final_duse_drawing_book_rem': final_duse_drawing_book_rem,
            'current_exam': current_exam,
            'ec_id': ec_id_formatted,
            'inst_name': inst_name,
            'city_name': city_name_val,
            'user_name': user_info['user_name'],
            'print_date': datetime.now().strftime('%d/%m/%Y'),
        }

        return render(request, 'stat_inst/report_drwing_stationary.html', context)

    except Exception as e:
        logger.exception("Error in report_drwing_stationary")
        is_jwt = user_info.get('is_jwt', False) if 'user_info' in locals() else (auth.get('is_jwt', False) if 'auth' in locals() else False)
        user_name = user_info.get('user_name', 'User') if 'user_info' in locals() else (auth.get('user_name', 'User') if 'auth' in locals() else 'User')
        return handle_report_error(
            request, e,
            is_jwt,
            template_name='stat_inst/report_drwing_stationary.html',
            context={
                'report_title': 'Error - Drawing Sheet Report',
                'error_message': str(e),
                'current_exam': getattr(msbte_config, 'ACA_NAME_EXAM_W', getattr(msbte_config, 'CURRENT_EXAM', msbte_config.EXAM_CODE)),
                'user_name': user_name,
                'print_date': datetime.now().strftime('%d/%m/%Y'),
            }
        )

@jwt_report_authorized(allowed_roles=['INSTITUTE', 'ADMIN'])
def drawing_sheet_supli_stationary(request):
    """
    Report of drawing sheet supplement issued and used.
    PHP Reference: drawing_sheet_supli_stationary
    Business Logic (from PHP):
    - PHP: $uid = $_SESSION['USER_ID'] (directly uses USER_ID as institute code)
    - Queries RAC_DC_DETAILS where exam_center=$uid
    - Checks if exam_center==$uid
    - Uses exam_center as ec_id and dec_id
    - Uses drawing supplement fields: drawing_book_supl_rem (S), ddrawing_issue_suppl_ans_book, duse_drawing_book_supl_rem, duse_sr_no_drawing_supl (D)
    """
    auth, error = get_auth_context(request)
    if error:
        return error

    try:
        user_info, error = get_user_control_info(
            request, auth,
            allowed_roles=['INSTITUTE', 'ADMIN'],
            require_institute_code=False,
            redirect_url='dashboard:stationary:stat_inst:drawing_sheet_supli_stationary',
            error_message='You are not authorised user to view this report'
        )
        if error:
            return error

        is_admin = user_info.get('is_admin', False)
        if is_admin:
            jwt_inst_code = auth.get('institute_code') if auth.get('is_jwt') else None
            instid_param = request.GET.get('instid', '').strip() or request.POST.get('instid', '').strip()

            if not jwt_inst_code and not instid_param:
                conn = get_db_connection()
                exam_centers_query = f"""
                    SELECT DISTINCT r.exam_center, i.inst_name
                    FROM {msbte_config.W25_RAC_DC_DETAILS} r
                    INNER JOIN {msbte_config.INSTITUTES} i ON i.inst_id = r.exam_center
                    ORDER BY r.exam_center
                """
                df_exam_centers = pd.read_sql(exam_centers_query, conn)
                exam_centers = [
                    {'inst_id': int(row['exam_center']), 'inst_name': row['inst_name'] if pd.notna(row['inst_name']) else f"Institute {int(row['exam_center'])}"}
                    for _, row in df_exam_centers.iterrows()
                ]
                current_exam = getattr(msbte_config, 'ACA_NAME_EXAM_W', getattr(msbte_config, 'CURRENT_EXAM', msbte_config.EXAM_CODE))
                context = {
                    'report_title': 'Select Institute - Drawing Sheet Supplement Report',
                    'exam_centers': exam_centers,
                    'current_exam': current_exam,
                    'user_name': user_info.get('user_name', 'User'),
                    'print_date': datetime.now().strftime('%d/%m/%Y'),
                    'form_action': reverse('dashboard:stationary:stat_inst:drawing_sheet_supli_stationary'),
                }
                return render(request, 'stat_inst/admin_select_institute.html', context)

        ec_id, dec_id, conn, error_response = _get_stationary_exam_center(
            request, auth, user_info, 'stat_inst/drawing_sheet_supli_stationary.html'
        )
        if error_response:
            if error_response == 'SHOW_FORM':
                return redirect(reverse('dashboard:stationary:stat_inst:drawing_sheet_supli_stationary'))
            return error_response

        # PHP: select S.drawing_book_supl_rem,D.exam_day,D.ddrawing_issue_suppl_ans_book,D.duse_drawing_book_supl_rem,D.duse_sr_no_drawing_supl
        #      from DAILY_STATIONERY_DETAILS D, STATIONERY_DETAILS S where dec_id='$dec_id11' and S.ec_id=D.dec_id
        daily_query = f"""
            SELECT
                D.exam_day,
                D.ddrawing_issue_suppl_ans_book,
                D.duse_drawing_book_supl_rem,
                D.duse_sr_no_drawing_supl,
                S.drawing_book_supl_rem
            FROM {msbte_config.W25_DAILY_STATIONERY_DETAILS} D
            INNER JOIN {msbte_config.STATIONERY_DETAILS} S ON S.ec_id = D.dec_id
            WHERE D.dec_id = %s
            ORDER BY FIELD(D.exam_day,
                'DAY1_MORNING', 'DAY1_AFTERNOON', 'DAY2_MORNING', 'DAY2_AFTERNOON',
                'DAY3_MORNING', 'DAY3_AFTERNOON', 'DAY4_MORNING', 'DAY4_AFTERNOON',
                'DAY5_MORNING', 'DAY5_AFTERNOON', 'DAY6_MORNING', 'DAY6_AFTERNOON',
                'DAY7_MORNING', 'DAY7_AFTERNOON', 'DAY8_MORNING', 'DAY8_AFTERNOON',
                'DAY9_MORNING', 'DAY9_AFTERNOON', 'DAY10_MORNING', 'DAY10_AFTERNOON',
                'DAY11_MORNING', 'DAY11_AFTERNOON', 'DAY12_MORNING', 'DAY12_AFTERNOON',
                'DAY13_MORNING', 'DAY13_AFTERNOON', 'DAY14_MORNING', 'DAY14_AFTERNOON',
                'DAY15_MORNING', 'DAY15_AFTERNOON', 'DAY16_MORNING', 'DAY16_AFTERNOON',
                'DAY17_MORNING', 'DAY17_AFTERNOON', 'DAY18_MORNING', 'DAY18_AFTERNOON'
            )
        """
        df_daily = pd.read_sql(daily_query, conn, params=[dec_id])

        report_data = []
        total_duse_drawing_book_supl_rem = 0
        final_duse_drawing_book_supl_rem = 0

        for idx, row in df_daily.iterrows():
            exam_day = row['exam_day'] if pd.notna(row['exam_day']) else ''
            duse_sr_no_drawing_supl = row['duse_sr_no_drawing_supl'] if pd.notna(row['duse_sr_no_drawing_supl']) else ''
            drawing_book_supl_rem = int(row['drawing_book_supl_rem']) if pd.notna(row['drawing_book_supl_rem']) else 0
            ddrawing_issue_suppl_ans_book = int(row['ddrawing_issue_suppl_ans_book']) if pd.notna(row['ddrawing_issue_suppl_ans_book']) else 0
            duse_drawing_book_supl_rem = int(row['duse_drawing_book_supl_rem']) if pd.notna(row['duse_drawing_book_supl_rem']) else 0

            # PHP: $drawing_book_supl_rem=$row2['drawing_book_supl_rem'] - $total_duse_drawing_book_supl_rem;
            opening_balance = drawing_book_supl_rem - total_duse_drawing_book_supl_rem
            # PHP: $duse_and_dissued_book_32_total=$row2['ddrawing_issue_suppl_ans_book'] - $row2['duse_drawing_book_supl_rem'];
            duse_and_dissued_book_32_total = ddrawing_issue_suppl_ans_book - duse_drawing_book_supl_rem
            # PHP: $total_balance_opening=$drawing_book_supl_rem - $row2['duse_drawing_book_supl_rem'];
            total_balance_opening = opening_balance - duse_drawing_book_supl_rem

            # PHP: $total_duse_drawing_book_supl_rem += $duse_drawing_book_supl_rem;
            total_duse_drawing_book_supl_rem += duse_drawing_book_supl_rem
            # PHP: $final_duse_drawing_book_supl_rem = $duse_drawing_book_supl_rem + $final_duse_drawing_book_supl_rem;
            final_duse_drawing_book_supl_rem += duse_drawing_book_supl_rem

            report_data.append({
                'sr_no': idx + 1,
                'exam_day': exam_day,
                'opening_balance': opening_balance,
                'ddrawing_issue_suppl_ans_book': ddrawing_issue_suppl_ans_book,
                'duse_drawing_book_supl_rem': duse_drawing_book_supl_rem,
                'duse_and_dissued_book_32_total': duse_and_dissued_book_32_total,
                'total_balance_opening': total_balance_opening,
                'duse_sr_no_drawing_supl': duse_sr_no_drawing_supl,
            })

        current_exam = getattr(msbte_config, 'ACA_NAME_EXAM_W', getattr(msbte_config, 'CURRENT_EXAM', msbte_config.EXAM_CODE))
        inst_name = get_inst_name(ec_id)
        city_name_val = get_city_name(ec_id)
        ec_id_formatted = _format_inst_code(ec_id)

        context = {
            'report_title': 'Report of drawing sheet supplement issued and used.',
            'report_data': report_data,
            'final_duse_drawing_book_supl_rem': final_duse_drawing_book_supl_rem,
            'current_exam': current_exam,
            'ec_id': ec_id_formatted,
            'inst_name': inst_name,
            'city_name': city_name_val,
            'user_name': user_info['user_name'],
            'print_date': datetime.now().strftime('%d/%m/%Y'),
        }

        return render(request, 'stat_inst/drawing_sheet_supli_stationary.html', context)

    except Exception as e:
        logger.exception("Error in drawing_sheet_supli_stationary")
        is_jwt = user_info.get('is_jwt', False) if 'user_info' in locals() else (auth.get('is_jwt', False) if 'auth' in locals() else False)
        user_name = user_info.get('user_name', 'User') if 'user_info' in locals() else (auth.get('user_name', 'User') if 'auth' in locals() else 'User')
        return handle_report_error(
            request, e,
            is_jwt,
            template_name='stat_inst/drawing_sheet_supli_stationary.html',
            context={
                'report_title': 'Error - Drawing Sheet Supplement Report',
                'error_message': str(e),
                'current_exam': getattr(msbte_config, 'ACA_NAME_EXAM_W', getattr(msbte_config, 'CURRENT_EXAM', msbte_config.EXAM_CODE)),
                'user_name': user_name,
                'print_date': datetime.now().strftime('%d/%m/%Y'),
            }
        )

@jwt_report_authorized(allowed_roles=['INSTITUTE', 'ADMIN'])
def report_32_qrcode_stationary(request):
    """
    Report of 32 page QR code sheet issued and used.
    PHP Reference: report_32_qrcode_stationary
    Business Logic (from PHP):
    - PHP: $uid = $_SESSION['USER_ID'] (directly uses USER_ID as institute code)
    - Queries RAC_DC_DETAILS where exam_center=$uid
    - Checks if exam_center==$uid
    - Uses exam_center as ec_id and dec_id
    - Uses QR code fields: book_32_qr_rem (S), d32_qr_code_issue_ans_book, duse_book_32_qr_code_rem, duse_sr_no_32_qr_code_book (D)
    """
    auth, error = get_auth_context(request)
    if error:
        return error

    try:
        user_info, error = get_user_control_info(
            request, auth,
            allowed_roles=['INSTITUTE', 'ADMIN'],
            require_institute_code=False,
            redirect_url='dashboard:stationary:stat_inst:report_32_qrcode_stationary',
            error_message='You are not authorised user to view this report'
        )
        if error:
            return error

        is_admin = user_info.get('is_admin', False)
        if is_admin:
            jwt_inst_code = auth.get('institute_code') if auth.get('is_jwt') else None
            instid_param = request.GET.get('instid', '').strip() or request.POST.get('instid', '').strip()

            if not jwt_inst_code and not instid_param:
                conn = get_db_connection()
                exam_centers_query = f"""
                    SELECT DISTINCT r.exam_center, i.inst_name
                    FROM {msbte_config.W25_RAC_DC_DETAILS} r
                    INNER JOIN {msbte_config.INSTITUTES} i ON i.inst_id = r.exam_center
                    ORDER BY r.exam_center
                """
                df_exam_centers = pd.read_sql(exam_centers_query, conn)
                exam_centers = [
                    {'inst_id': int(row['exam_center']), 'inst_name': row['inst_name'] if pd.notna(row['inst_name']) else f"Institute {int(row['exam_center'])}"}
                    for _, row in df_exam_centers.iterrows()
                ]
                current_exam = getattr(msbte_config, 'ACA_NAME_EXAM_W', getattr(msbte_config, 'CURRENT_EXAM', msbte_config.EXAM_CODE))
                context = {
                    'report_title': 'Select Institute - 32 Page QR Code Sheet Report',
                    'exam_centers': exam_centers,
                    'current_exam': current_exam,
                    'user_name': user_info.get('user_name', 'User'),
                    'print_date': datetime.now().strftime('%d/%m/%Y'),
                    'form_action': reverse('dashboard:stationary:stat_inst:report_32_qrcode_stationary'),
                }
                return render(request, 'stat_inst/admin_select_institute.html', context)

        ec_id, dec_id, conn, error_response = _get_stationary_exam_center(
            request, auth, user_info, 'stat_inst/report_32_qrcode_stationary.html'
        )
        if error_response:
            if error_response == 'SHOW_FORM':
                return redirect(reverse('dashboard:stationary:stat_inst:report_32_qrcode_stationary'))
            return error_response

        # PHP: select D.exam_day,D.d32_qr_code_issue_ans_book,D.duse_book_32_qr_code_rem,S.book_32_qr_rem,D.duse_sr_no_32_qr_code_book
        #      from DAILY_STATIONERY_DETAILS D, STATIONERY_DETAILS S where dec_id='$dec_id11' and S.ec_id=D.dec_id
        daily_query = f"""
            SELECT
                D.exam_day,
                D.d32_qr_code_issue_ans_book,
                D.duse_book_32_qr_code_rem,
                D.duse_sr_no_32_qr_code_book,
                S.book_32_qr_rem
            FROM {msbte_config.W25_DAILY_STATIONERY_DETAILS} D
            INNER JOIN {msbte_config.STATIONERY_DETAILS} S ON S.ec_id = D.dec_id
            WHERE D.dec_id = %s
            ORDER BY FIELD(D.exam_day,
                'DAY1_MORNING', 'DAY1_AFTERNOON', 'DAY2_MORNING', 'DAY2_AFTERNOON',
                'DAY3_MORNING', 'DAY3_AFTERNOON', 'DAY4_MORNING', 'DAY4_AFTERNOON',
                'DAY5_MORNING', 'DAY5_AFTERNOON', 'DAY6_MORNING', 'DAY6_AFTERNOON',
                'DAY7_MORNING', 'DAY7_AFTERNOON', 'DAY8_MORNING', 'DAY8_AFTERNOON',
                'DAY9_MORNING', 'DAY9_AFTERNOON', 'DAY10_MORNING', 'DAY10_AFTERNOON',
                'DAY11_MORNING', 'DAY11_AFTERNOON', 'DAY12_MORNING', 'DAY12_AFTERNOON',
                'DAY13_MORNING', 'DAY13_AFTERNOON', 'DAY14_MORNING', 'DAY14_AFTERNOON',
                'DAY15_MORNING', 'DAY15_AFTERNOON', 'DAY16_MORNING', 'DAY16_AFTERNOON',
                'DAY17_MORNING', 'DAY17_AFTERNOON', 'DAY18_MORNING', 'DAY18_AFTERNOON'
            )
        """
        df_daily = pd.read_sql(daily_query, conn, params=[dec_id])

        report_data = []
        total_duse_book_32_qr_rem = 0
        final_use_32_qr_answer_book = 0

        for idx, row in df_daily.iterrows():
            exam_day = row['exam_day'] if pd.notna(row['exam_day']) else ''
            duse_sr_no_32_qr_code_book = row['duse_sr_no_32_qr_code_book'] if pd.notna(row['duse_sr_no_32_qr_code_book']) else ''
            book_32_qr_rem = int(row['book_32_qr_rem']) if pd.notna(row['book_32_qr_rem']) else 0
            d32_qr_code_issue_ans_book = int(row['d32_qr_code_issue_ans_book']) if pd.notna(row['d32_qr_code_issue_ans_book']) else 0
            duse_book_32_qr_code_rem = int(row['duse_book_32_qr_code_rem']) if pd.notna(row['duse_book_32_qr_code_rem']) else 0

            # PHP: $book_32_qr_rem=$row2['book_32_qr_rem'] - $total_duse_book_32_qr_rem;
            opening_balance = book_32_qr_rem - total_duse_book_32_qr_rem
            # PHP: $duse_and_dissued_book_32_qr_total=$row2['d32_qr_code_issue_ans_book'] - $row2['duse_book_32_qr_code_rem'];
            duse_and_dissued_book_32_qr_total = d32_qr_code_issue_ans_book - duse_book_32_qr_code_rem
            # PHP: $total_balance_opening=$book_32_qr_rem - $row2['duse_book_32_qr_code_rem'];
            total_balance_opening = opening_balance - duse_book_32_qr_code_rem

            # PHP: $total_duse_book_32_qr_rem += $duse_book_32_qr_code_rem;
            total_duse_book_32_qr_rem += duse_book_32_qr_code_rem
            # PHP: $final_use_32_qr_answer_book = $duse_book_32_qr_code_rem + $final_use_32_qr_answer_book;
            final_use_32_qr_answer_book += duse_book_32_qr_code_rem

            report_data.append({
                'sr_no': idx + 1,
                'exam_day': exam_day,
                'opening_balance': opening_balance,
                'd32_qr_code_issue_ans_book': d32_qr_code_issue_ans_book,
                'duse_book_32_qr_code_rem': duse_book_32_qr_code_rem,
                'duse_and_dissued_book_32_qr_total': duse_and_dissued_book_32_qr_total,
                'total_balance_opening': total_balance_opening,
                'duse_sr_no_32_qr_code_book': duse_sr_no_32_qr_code_book,
            })

        current_exam = getattr(msbte_config, 'ACA_NAME_EXAM_W', getattr(msbte_config, 'CURRENT_EXAM', msbte_config.EXAM_CODE))
        inst_name = get_inst_name(ec_id)
        city_name_val = get_city_name(ec_id)
        ec_id_formatted = _format_inst_code(ec_id)

        context = {
            'report_title': 'Report of 32 page QR code sheet issued and used.',
            'report_data': report_data,
            'final_use_32_qr_answer_book': final_use_32_qr_answer_book,
            'current_exam': current_exam,
            'ec_id': ec_id_formatted,
            'inst_name': inst_name,
            'city_name': city_name_val,
            'user_name': user_info['user_name'],
            'print_date': datetime.now().strftime('%d/%m/%Y'),
        }

        return render(request, 'stat_inst/report_32_qrcode_stationary.html', context)

    except Exception as e:
        logger.exception("Error in report_32_qrcode_stationary")
        is_jwt = user_info.get('is_jwt', False) if 'user_info' in locals() else (auth.get('is_jwt', False) if 'auth' in locals() else False)
        user_name = user_info.get('user_name', 'User') if 'user_info' in locals() else (auth.get('user_name', 'User') if 'auth' in locals() else 'User')
        return handle_report_error(
            request, e,
            is_jwt,
            template_name='stat_inst/report_32_qrcode_stationary.html',
            context={
                'report_title': 'Error - 32 Page QR Code Sheet Report',
                'error_message': str(e),
                'current_exam': getattr(msbte_config, 'ACA_NAME_EXAM_W', getattr(msbte_config, 'CURRENT_EXAM', msbte_config.EXAM_CODE)),
                'user_name': user_name,
                'print_date': datetime.now().strftime('%d/%m/%Y'),
            }
        )

@jwt_report_authorized(allowed_roles=['INSTITUTE', 'ADMIN'])
def report_32_qrcode_supli_stationary(request):
    """
    Report of 32 page QR code Supplement sheet issued and used.
    PHP Reference: report_32_qrcode_supli_stationary
    Business Logic (from PHP):
    - PHP: $uid = $_SESSION['USER_ID'] (directly uses USER_ID as institute code)
    - Queries RAC_DC_DETAILS where exam_center=$uid
    - Checks if exam_center==$uid
    - Uses exam_center as ec_id and dec_id
    - Uses QR code supplement fields: book_code_32_qr_supl_rem (S), d32_qr_issue_supl_ans_book, duse_book_32_qr_supl_rem, duse_sr_no_32_qr_suppl (D)
    """
    auth, error = get_auth_context(request)
    if error:
        return error

    try:
        user_info, error = get_user_control_info(
            request, auth,
            allowed_roles=['INSTITUTE', 'ADMIN'],
            require_institute_code=False,
            redirect_url='dashboard:stationary:stat_inst:report_32_qrcode_supli_stationary',
            error_message='You are not authorised user to view this report'
        )
        if error:
            return error

        is_admin = user_info.get('is_admin', False)
        if is_admin:
            jwt_inst_code = auth.get('institute_code') if auth.get('is_jwt') else None
            instid_param = request.GET.get('instid', '').strip() or request.POST.get('instid', '').strip()

            if not jwt_inst_code and not instid_param:
                conn = get_db_connection()
                exam_centers_query = f"""
                    SELECT DISTINCT r.exam_center, i.inst_name
                    FROM {msbte_config.W25_RAC_DC_DETAILS} r
                    INNER JOIN {msbte_config.INSTITUTES} i ON i.inst_id = r.exam_center
                    ORDER BY r.exam_center
                """
                df_exam_centers = pd.read_sql(exam_centers_query, conn)
                exam_centers = [
                    {'inst_id': int(row['exam_center']), 'inst_name': row['inst_name'] if pd.notna(row['inst_name']) else f"Institute {int(row['exam_center'])}"}
                    for _, row in df_exam_centers.iterrows()
                ]
                current_exam = getattr(msbte_config, 'ACA_NAME_EXAM_W', getattr(msbte_config, 'CURRENT_EXAM', msbte_config.EXAM_CODE))
                context = {
                    'report_title': 'Select Institute - 32 Page QR Code Supplement Sheet Report',
                    'exam_centers': exam_centers,
                    'current_exam': current_exam,
                    'user_name': user_info.get('user_name', 'User'),
                    'print_date': datetime.now().strftime('%d/%m/%Y'),
                    'form_action': reverse('dashboard:stationary:stat_inst:report_32_qrcode_supli_stationary'),
                }
                return render(request, 'stat_inst/admin_select_institute.html', context)

        ec_id, dec_id, conn, error_response = _get_stationary_exam_center(
            request, auth, user_info, 'stat_inst/report_32_qrcode_supli_stationary.html'
        )
        if error_response:
            if error_response == 'SHOW_FORM':
                return redirect(reverse('dashboard:stationary:stat_inst:report_32_qrcode_supli_stationary'))
            return error_response

        # PHP: select S.book_code_32_qr_supl_rem,D.exam_day,D.d32_qr_issue_supl_ans_book,D.duse_book_32_qr_supl_rem,duse_sr_no_32_qr_suppl
        #      from DAILY_STATIONERY_DETAILS D, STATIONERY_DETAILS S where dec_id='$dec_id11' and S.ec_id=D.dec_id
        daily_query = f"""
            SELECT
                D.exam_day,
                D.d32_qr_issue_supl_ans_book,
                D.duse_book_32_qr_supl_rem,
                D.duse_sr_no_32_qr_suppl,
                S.book_code_32_qr_supl_rem
            FROM {msbte_config.W25_DAILY_STATIONERY_DETAILS} D
            INNER JOIN {msbte_config.STATIONERY_DETAILS} S ON S.ec_id = D.dec_id
            WHERE D.dec_id = %s
            ORDER BY FIELD(D.exam_day,
                'DAY1_MORNING', 'DAY1_AFTERNOON', 'DAY2_MORNING', 'DAY2_AFTERNOON',
                'DAY3_MORNING', 'DAY3_AFTERNOON', 'DAY4_MORNING', 'DAY4_AFTERNOON',
                'DAY5_MORNING', 'DAY5_AFTERNOON', 'DAY6_MORNING', 'DAY6_AFTERNOON',
                'DAY7_MORNING', 'DAY7_AFTERNOON', 'DAY8_MORNING', 'DAY8_AFTERNOON',
                'DAY9_MORNING', 'DAY9_AFTERNOON', 'DAY10_MORNING', 'DAY10_AFTERNOON',
                'DAY11_MORNING', 'DAY11_AFTERNOON', 'DAY12_MORNING', 'DAY12_AFTERNOON',
                'DAY13_MORNING', 'DAY13_AFTERNOON', 'DAY14_MORNING', 'DAY14_AFTERNOON',
                'DAY15_MORNING', 'DAY15_AFTERNOON', 'DAY16_MORNING', 'DAY16_AFTERNOON',
                'DAY17_MORNING', 'DAY17_AFTERNOON', 'DAY18_MORNING', 'DAY18_AFTERNOON'
            )
        """
        df_daily = pd.read_sql(daily_query, conn, params=[dec_id])

        report_data = []
        total_duse_book_32_qr_supli_rem = 0
        final_use_32_qr_answer_supli_book = 0

        for idx, row in df_daily.iterrows():
            exam_day = row['exam_day'] if pd.notna(row['exam_day']) else ''
            duse_sr_no_32_qr_suppl = row['duse_sr_no_32_qr_suppl'] if pd.notna(row['duse_sr_no_32_qr_suppl']) else ''
            book_code_32_qr_supl_rem = int(row['book_code_32_qr_supl_rem']) if pd.notna(row['book_code_32_qr_supl_rem']) else 0
            d32_qr_issue_supl_ans_book = int(row['d32_qr_issue_supl_ans_book']) if pd.notna(row['d32_qr_issue_supl_ans_book']) else 0
            duse_book_32_qr_supl_rem = int(row['duse_book_32_qr_supl_rem']) if pd.notna(row['duse_book_32_qr_supl_rem']) else 0

            # PHP: $book_code_32_qr_supl_rem=$row2['book_code_32_qr_supl_rem'] - $total_duse_book_32_qr_supli_rem;
            opening_balance = book_code_32_qr_supl_rem - total_duse_book_32_qr_supli_rem
            # PHP: $duse_and_dissued_book_32_qr_supli_total=$row2['d32_qr_issue_supl_ans_book'] - $row2['duse_book_32_qr_supl_rem'];
            duse_and_dissued_book_32_qr_supli_total = d32_qr_issue_supl_ans_book - duse_book_32_qr_supl_rem
            # PHP: $total_balance_opening=$book_code_32_qr_supl_rem - $row2['duse_book_32_qr_supl_rem'];
            total_balance_opening = opening_balance - duse_book_32_qr_supl_rem

            # PHP: $total_duse_book_32_qr_supli_rem += $duse_book_32_qr_supl_rem;
            total_duse_book_32_qr_supli_rem += duse_book_32_qr_supl_rem
            # PHP: $final_use_32_qr_answer_supli_book = $duse_book_32_qr_supl_rem + $final_use_32_qr_answer_supli_book;
            final_use_32_qr_answer_supli_book += duse_book_32_qr_supl_rem

            report_data.append({
                'sr_no': idx + 1,
                'exam_day': exam_day,
                'opening_balance': opening_balance,
                'd32_qr_issue_supl_ans_book': d32_qr_issue_supl_ans_book,
                'duse_book_32_qr_supl_rem': duse_book_32_qr_supl_rem,
                'duse_and_dissued_book_32_qr_supli_total': duse_and_dissued_book_32_qr_supli_total,
                'total_balance_opening': total_balance_opening,
                'duse_sr_no_32_qr_suppl': duse_sr_no_32_qr_suppl,
            })

        current_exam = getattr(msbte_config, 'ACA_NAME_EXAM_W', getattr(msbte_config, 'CURRENT_EXAM', msbte_config.EXAM_CODE))
        inst_name = get_inst_name(ec_id)
        city_name_val = get_city_name(ec_id)
        ec_id_formatted = _format_inst_code(ec_id)

        context = {
            'report_title': 'Report of 32 page QR code Supplement sheet issued and used.',
            'report_data': report_data,
            'final_use_32_qr_answer_supli_book': final_use_32_qr_answer_supli_book,
            'current_exam': current_exam,
            'ec_id': ec_id_formatted,
            'inst_name': inst_name,
            'city_name': city_name_val,
            'user_name': user_info['user_name'],
            'print_date': datetime.now().strftime('%d/%m/%Y'),
        }

        return render(request, 'stat_inst/report_32_qrcode_supli_stationary.html', context)

    except Exception as e:
        logger.exception("Error in report_32_qrcode_supli_stationary")
        is_jwt = user_info.get('is_jwt', False) if 'user_info' in locals() else (auth.get('is_jwt', False) if 'auth' in locals() else False)
        user_name = user_info.get('user_name', 'User') if 'user_info' in locals() else (auth.get('user_name', 'User') if 'auth' in locals() else 'User')
        return handle_report_error(
            request, e,
            is_jwt,
            template_name='stat_inst/report_32_qrcode_supli_stationary.html',
            context={
                'report_title': 'Error - 32 Page QR Code Supplement Sheet Report',
                'error_message': str(e),
                'current_exam': getattr(msbte_config, 'ACA_NAME_EXAM_W', getattr(msbte_config, 'CURRENT_EXAM', msbte_config.EXAM_CODE)),
                'user_name': user_name,
                'print_date': datetime.now().strftime('%d/%m/%Y'),
            }
        )

@jwt_report_authorized(allowed_roles=['INSTITUTE', 'ADMIN'])
def cancel_stationery_report(request):
    """
    Report of Cancelled Answer Book.
    PHP Reference: cancel_stationery_report
    Business Logic (from PHP):
    - PHP: $uid = $_SESSION['USER_ID'] (directly uses USER_ID as institute code)
    - Queries RAC_DC_DETAILS where exam_center=$uid
    - Checks if exam_center==$uid
    - Uses exam_center as ec_id and dec_id
    - Queries CANCEL_DAILY_STATIONERY_AB table
    - Shows cancelled answer books and summary by exam day
    """
    auth, error = get_auth_context(request)
    if error:
        return error

    try:
        user_info, error = get_user_control_info(
            request, auth,
            allowed_roles=['INSTITUTE', 'ADMIN'],
            require_institute_code=False,
            redirect_url='dashboard:stationary:stat_inst:cancel_stationery_report',
            error_message='You are not authorised user to view this report'
        )
        if error:
            return error

        is_admin = user_info.get('is_admin', False)
        if is_admin:
            jwt_inst_code = auth.get('institute_code') if auth.get('is_jwt') else None
            instid_param = request.GET.get('instid', '').strip() or request.POST.get('instid', '').strip()

            if not jwt_inst_code and not instid_param:
                conn = get_db_connection()
                exam_centers_query = f"""
                    SELECT DISTINCT r.exam_center, i.inst_name
                    FROM {msbte_config.W25_RAC_DC_DETAILS} r
                    INNER JOIN {msbte_config.INSTITUTES} i ON i.inst_id = r.exam_center
                    ORDER BY r.exam_center
                """
                df_exam_centers = pd.read_sql(exam_centers_query, conn)
                exam_centers = [
                    {'inst_id': int(row['exam_center']), 'inst_name': row['inst_name'] if pd.notna(row['inst_name']) else f"Institute {int(row['exam_center'])}"}
                    for _, row in df_exam_centers.iterrows()
                ]
                current_exam = getattr(msbte_config, 'ACA_NAME_EXAM_W', getattr(msbte_config, 'CURRENT_EXAM', msbte_config.EXAM_CODE))
                context = {
                    'report_title': 'Select Institute - Cancelled Answer Book Report',
                    'exam_centers': exam_centers,
                    'current_exam': current_exam,
                    'user_name': user_info.get('user_name', 'User'),
                    'print_date': datetime.now().strftime('%d/%m/%Y'),
                    'form_action': reverse('dashboard:stationary:stat_inst:cancel_stationery_report'),
                }
                return render(request, 'stat_inst/admin_select_institute.html', context)

        ec_id, dec_id, conn, error_response = _get_stationary_exam_center(
            request, auth, user_info, 'stat_inst/cancel_stationery_report.html'
        )
        if error_response:
            if error_response == 'SHOW_FORM':
                return redirect(reverse('dashboard:stationary:stat_inst:cancel_stationery_report'))
            return error_response

        # Map stationery type numbers to names
        def get_stationery_type_name(stationery_type):
            type_mapping = {
                1: "32 PAGES OLD MAIN ANSWER BOOK",
                2: "DRAWING SHEET MAIN ANSWER BOOK",
                3: "32 PAGES OLD SUPPLIMENT ANSWER BOOK",
                4: "DRAWING SHEET SUPPLIMRNT ANSWER BOOK",
                5: "32 PAGES BARCODE ANSWER BOOK",
                6: "32 PAGES BARCODE SUPPLIMENT ANSWER BOOK",
                7: "32 PAGES QRCODE ANSWER BOOK",
                8: "32 PAGES QRCODE SUPPLIMENT ANSWER BOOK",
            }
            return type_mapping.get(int(stationery_type) if stationery_type else 0, "Type Not Selected")

        # PHP: select exam_day,ab_no,remark,type from CANCEL_DAILY_STATIONERY_AB where ec_id='$dec_id11'
        cancel_query = f"""
            SELECT
                exam_day,
                ab_no,
                remark,
                type
            FROM {msbte_config.CANCEL_DAILY_STATIONERY_AB}
            WHERE ec_id = %s
            ORDER BY FIELD(exam_day,
                'DAY1_MORNING', 'DAY1_AFTERNOON', 'DAY2_MORNING', 'DAY2_AFTERNOON',
                'DAY3_MORNING', 'DAY3_AFTERNOON', 'DAY4_MORNING', 'DAY4_AFTERNOON',
                'DAY5_MORNING', 'DAY5_AFTERNOON', 'DAY6_MORNING', 'DAY6_AFTERNOON',
                'DAY7_MORNING', 'DAY7_AFTERNOON', 'DAY8_MORNING', 'DAY8_AFTERNOON',
                'DAY9_MORNING', 'DAY9_AFTERNOON', 'DAY10_MORNING', 'DAY10_AFTERNOON',
                'DAY11_MORNING', 'DAY11_AFTERNOON', 'DAY12_MORNING', 'DAY12_AFTERNOON',
                'DAY13_MORNING', 'DAY13_AFTERNOON', 'DAY14_MORNING', 'DAY14_AFTERNOON',
                'DAY15_MORNING', 'DAY15_AFTERNOON', 'DAY16_MORNING', 'DAY16_AFTERNOON',
                'DAY17_MORNING', 'DAY17_AFTERNOON', 'DAY18_MORNING', 'DAY18_AFTERNOON'
            )
        """
        df_cancel = pd.read_sql(cancel_query, conn, params=[dec_id])

        # Process cancelled answer books data
        cancel_data = []
        for idx, row in df_cancel.iterrows():
            exam_day = row['exam_day'] if pd.notna(row['exam_day']) else ''
            ab_no = row['ab_no'] if pd.notna(row['ab_no']) else ''
            remark = row['remark'] if pd.notna(row['remark']) else ''
            stationery_type = int(row['type']) if pd.notna(row['type']) else 0
            stationery_type_name = get_stationery_type_name(stationery_type)

            cancel_data.append({
                'sr_no': idx + 1,
                'exam_day': exam_day,
                'ab_no': ab_no,
                'remark': remark,
                'stationery_type_name': stationery_type_name,
            })

        # PHP: select exam_day,COUNT(*) AS cnt from CANCEL_DAILY_STATIONERY_AB where ec_id=? group by exam_day
        summary_query = f"""
            SELECT
                exam_day,
                COUNT(*) AS cnt
            FROM {msbte_config.CANCEL_DAILY_STATIONERY_AB}
            WHERE ec_id = %s
            GROUP BY exam_day
            ORDER BY FIELD(exam_day,
                'DAY1_MORNING', 'DAY1_AFTERNOON', 'DAY2_MORNING', 'DAY2_AFTERNOON',
                'DAY3_MORNING', 'DAY3_AFTERNOON', 'DAY4_MORNING', 'DAY4_AFTERNOON',
                'DAY5_MORNING', 'DAY5_AFTERNOON', 'DAY6_MORNING', 'DAY6_AFTERNOON',
                'DAY7_MORNING', 'DAY7_AFTERNOON', 'DAY8_MORNING', 'DAY8_AFTERNOON',
                'DAY9_MORNING', 'DAY9_AFTERNOON', 'DAY10_MORNING', 'DAY10_AFTERNOON',
                'DAY11_MORNING', 'DAY11_AFTERNOON', 'DAY12_MORNING', 'DAY12_AFTERNOON',
                'DAY13_MORNING', 'DAY13_AFTERNOON', 'DAY14_MORNING', 'DAY14_AFTERNOON',
                'DAY15_MORNING', 'DAY15_AFTERNOON', 'DAY16_MORNING', 'DAY16_AFTERNOON',
                'DAY17_MORNING', 'DAY17_AFTERNOON', 'DAY18_MORNING', 'DAY18_AFTERNOON'
            )
        """
        df_summary = pd.read_sql(summary_query, conn, params=[dec_id])

        # Process summary data
        summary_data = []
        for idx, row in df_summary.iterrows():
            exam_day = row['exam_day'] if pd.notna(row['exam_day']) else ''
            total_count = int(row['cnt']) if pd.notna(row['cnt']) else 0

            summary_data.append({
                'sr_no': idx + 1,
                'exam_day': exam_day,
                'total_count': total_count,
            })

        current_exam = getattr(msbte_config, 'ACA_NAME_EXAM_W', getattr(msbte_config, 'CURRENT_EXAM', msbte_config.EXAM_CODE))
        inst_name = get_inst_name(ec_id)
        city_name_val = get_city_name(ec_id)
        ec_id_formatted = _format_inst_code(ec_id)

        context = {
            'report_title': 'Report of Cancelled Answer Book',
            'cancel_data': cancel_data,
            'summary_data': summary_data,
            'current_exam': current_exam,
            'ec_id': ec_id_formatted,
            'inst_name': inst_name,
            'city_name': city_name_val,
            'user_name': user_info['user_name'],
            'print_date': datetime.now().strftime('%d/%m/%Y'),
        }

        return render(request, 'stat_inst/cancel_stationery_report.html', context)

    except Exception as e:
        logger.exception("Error in cancel_stationery_report")
        is_jwt = user_info.get('is_jwt', False) if 'user_info' in locals() else (auth.get('is_jwt', False) if 'auth' in locals() else False)
        user_name = user_info.get('user_name', 'User') if 'user_info' in locals() else (auth.get('user_name', 'User') if 'auth' in locals() else 'User')
        return handle_report_error(
            request, e,
            is_jwt,
            template_name='stat_inst/cancel_stationery_report.html',
            context={
                'report_title': 'Error - Cancelled Answer Book Report',
                'error_message': str(e),
                'current_exam': getattr(msbte_config, 'ACA_NAME_EXAM_W', getattr(msbte_config, 'CURRENT_EXAM', msbte_config.EXAM_CODE)),
                'user_name': user_name,
                'print_date': datetime.now().strftime('%d/%m/%Y'),
            }
        )