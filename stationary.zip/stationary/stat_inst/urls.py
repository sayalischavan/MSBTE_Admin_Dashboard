from django.urls import path
from . import views

app_name = 'stat_inst'

urlpatterns = [
    path('report_32_stationary/', views.report_32_stationary, name='report_32_stationary'),
    path('report_32_supli_stationery/', views.report_32_supli_stationery, name='report_32_supli_stationery'),
    path('report_32_barcode_stationery/', views.report_32_barcode_stationery, name='report_32_barcode_stationery'),
    path('report_32_barcode_supli_stationery/', views.report_32_barcode_supli_stationery, name='report_32_barcode_supli_stationery'),
    path('report_drwing_stationary/', views.report_drwing_stationary, name='report_drwing_stationary'),
    path('drawing_sheet_supli_stationary/', views.drawing_sheet_supli_stationary, name='drawing_sheet_supli_stationary'),
    path('report_32_qrcode_stationary/', views.report_32_qrcode_stationary, name='report_32_qrcode_stationary'),
    path('report_32_qrcode_supli_stationary/', views.report_32_qrcode_supli_stationary, name='report_32_qrcode_supli_stationary'),
    path('cancel_stationery_report/', views.cancel_stationery_report, name='cancel_stationery_report'),
]