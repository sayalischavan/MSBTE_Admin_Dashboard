from django.db import models

# Models for stationary module
# StationaryTaskExecution model has been moved to data_prepration.stationary_admin.models
