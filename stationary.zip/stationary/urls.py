from django.urls import path, include
from . import views

app_name = 'stationary'

urlpatterns = [
    path('', views.stationary_home, name='stationary_home'),
    path('regionwise_stationery_statistics_report/', views.regionwise_stationery_statistics_report, name='regionwise_stationery_statistics_report'),
    path('exam_center_wise_used_count_report/', views.exam_center_wise_used_count_report, name='exam_center_wise_used_count_report'),
    path('exam_center_wise_balance_report/', views.exam_center_wise_balance_report, name='exam_center_wise_balance_report'),
    path('region_wise_used_count_report/', views.region_wise_used_count_report, name='region_wise_used_count_report'),
    path('region_wise_balance_report/', views.region_wise_balance_report, name='region_wise_balance_report'),
    path('stationery_conf_unconf_summary_report/', views.stationery_conf_unconf_summary_report, name='stationery_conf_unconf_summary_report'),
    path('stationery_conf_details/<str:dist_regcode>/', views.stationery_conf_details, name='stationery_conf_details'),
    path('stationery_unconf_details/<str:dist_regcode>/', views.stationery_unconf_details, name='stationery_unconf_details'),
    path('stationary_statistic_requirement_report/',views.stationary_statistic_requirement_report,name='stationary_statistic_requirement_report'),
    path('rbte_dc_fill_status_report/', views.rbte_dc_fill_status_report, name='rbte_dc_fill_status_report'),
    path('stat_inst/', include('dashboard.stationary.stat_inst.urls')),
    path('stat_rbte/', include('dashboard.stationary.stat_rbte.urls')),
]