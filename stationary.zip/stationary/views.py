from django.shortcuts import render, redirect
from django.urls import reverse
from django.contrib.auth.decorators import login_required
from django.contrib import messages
from django.db import connections
from datetime import datetime
import logging
from dashboard.decorators import allowed_users, jwt_report_authorized
import config.msbte_config as msbte_config
from dashboard.utils import (
    get_db_connection,
    get_auth_context,
    get_user_control_info,
    handle_report_error,
    log_query,
    get_group_id,
    get_course_codename,
    get_region_inst,
    get_region_name,
    safe_int,
    _balance_report_key,
)
import pandas as pd
import base64

logger = logging.getLogger(__name__)

@login_required
def stationary_home(request):
    return render(request, 'stationary_home.html')


@jwt_report_authorized(allowed_roles=['ADMIN'])
def regionwise_stationery_statistics_report(request):
    """
    Regionwise Stationary Statistics Report - Admin only.
    Query: w25_daily_stationery_details grouped by ddist_regcode with SUMs of used books/sheets.
    """
    auth, error = get_auth_context(request, require_institute=False)
    if error:
        return error
    user_info, error = get_user_control_info(
        request,
        auth,
        allowed_roles=['ADMIN'],
        require_institute_code=False,
        require_rbte_code=False,
        redirect_url='dashboard:stationary:stationary_home',
    )
    if error:
        return error

    user_name = user_info.get('user_name', '') or (request.user.username if request.user.is_authenticated else '')
    table_name = getattr(msbte_config, 'W25_DAILY_STATIONERY_DETAILS', None)
    if not table_name:
        messages.error(request, 'Report configuration (W25_DAILY_STATIONERY_DETAILS) is not available.')
        return redirect('dashboard:stationary:stationary_home')

    try:
        conn = get_db_connection()
        q = f"""
            SELECT
                ddist_regcode,
                SUM(duse_book_32_rem) AS used_32_page_main_ab,
                SUM(duse_book_32_supl_rem) AS used_32_page_supplement_ab,
                SUM(duse_drawing_book_rem) AS used_drawing_sheet_main_ab,
                SUM(duse_drawing_book_supl_rem) AS used_drawing_sheet_supplement_ab,
                SUM(duse_book_code_32_rem) AS used_32_page_barcode_main_ab,
                SUM(duse_book_code_32_supl_rem) AS used_32_page_barcode_supplement_ab,
                SUM(duse_book_32_qr_code_rem) AS used_32_page_qrcode_main_ab,
                SUM(duse_book_32_qr_supl_rem) AS used_32_page_qrcode_supplement_ab
            FROM {table_name}
            GROUP BY ddist_regcode
            ORDER BY ddist_regcode
        """
        df = pd.read_sql(q, conn)
        rows_data = []
        for sr, (_, row) in enumerate(df.iterrows(), 1):
            reg_code = row.get('ddist_regcode')
            try:
                reg_code_int = int(float(reg_code)) if reg_code is not None and str(reg_code).strip() != '' else None
            except (ValueError, TypeError):
                reg_code_int = None
            # Display region code as integer (e.g. 5004 not 5004.0)
            try:
                reg_code_display = int(float(reg_code)) if reg_code is not None else '-'
            except (ValueError, TypeError):
                reg_code_display = reg_code if reg_code is not None else '-'
            region_name = get_region_name(reg_code_int) if reg_code_int else (str(reg_code) if reg_code else '-')
            rows_data.append({
                'sr_no': sr,
                'ddist_regcode': reg_code_display,
                'region_name': region_name,
                'used_32_page_main_ab': int(row.get('used_32_page_main_ab') or 0),
                'used_32_page_supplement_ab': int(row.get('used_32_page_supplement_ab') or 0),
                'used_drawing_sheet_main_ab': int(row.get('used_drawing_sheet_main_ab') or 0),
                'used_drawing_sheet_supplement_ab': int(row.get('used_drawing_sheet_supplement_ab') or 0),
                'used_32_page_barcode_main_ab': int(row.get('used_32_page_barcode_main_ab') or 0),
                'used_32_page_barcode_supplement_ab': int(row.get('used_32_page_barcode_supplement_ab') or 0),
                'used_32_page_qrcode_main_ab': int(row.get('used_32_page_qrcode_main_ab') or 0),
                'used_32_page_qrcode_supplement_ab': int(row.get('used_32_page_qrcode_supplement_ab') or 0),
            })

        current_exam = getattr(msbte_config, 'ACA_NAME_EXAM_W', 'Winter 2025')
        context = {
            'report_title': 'Regionwise Stationary Statistics Report',
            'rows_data': rows_data,
            'current_exam': current_exam,
            'user_name': user_name,
            'print_date': datetime.now().strftime('%Y-%m-%d %I:%M:%S %p'),
        }
        return render(request, 'stationary/regionwise_stationery_statistics_report.html', context)
    except Exception as e:
        logger.error(f"Error in regionwise_stationery_statistics_report: {str(e)}", exc_info=True)
        messages.error(request, f'An error occurred while generating the report: {str(e)}')
        return redirect('dashboard:stationary:stationary_home')

@jwt_report_authorized(allowed_roles=['ADMIN'])
def exam_center_wise_used_count_report(request):
    """
    Exam Center Wise Used Count - Admin only.
    Query: w25_daily_stationery_details grouped by ddist_regcode, dec_id with SUMs of used books/sheets.
    """
    auth, error = get_auth_context(request, require_institute=False)
    if error:
        return error
    user_info, error = get_user_control_info(
        request,
        auth,
        allowed_roles=['ADMIN'],
        require_institute_code=False,
        require_rbte_code=False,
        redirect_url='dashboard:stationary:stationary_home',
    )
    if error:
        return error

    user_name = user_info.get('user_name', '') or (request.user.username if request.user.is_authenticated else '')
    table_name = getattr(msbte_config, 'W25_DAILY_STATIONERY_DETAILS', None)
    if not table_name:
        messages.error(request, 'Report configuration (W25_DAILY_STATIONERY_DETAILS) is not available.')
        return redirect('dashboard:stationary:stationary_home')

    try:
        conn = get_db_connection()
        q = f"""
            SELECT
                ddist_regcode,
                dec_id,
                SUM(duse_book_32_rem) AS used_32_page_main_ab,
                SUM(duse_book_32_supl_rem) AS used_32_page_supplement_ab,
                SUM(duse_drawing_book_rem) AS used_drawing_sheet_main_ab,
                SUM(duse_drawing_book_supl_rem) AS used_drawing_sheet_supplement_ab,
                SUM(duse_book_code_32_rem) AS used_32_page_barcode_main_ab,
                SUM(duse_book_code_32_supl_rem) AS used_32_page_barcode_supplement_ab,
                SUM(duse_book_32_qr_code_rem) AS used_32_page_qrcode_main_ab,
                SUM(duse_book_32_qr_supl_rem) AS used_32_page_qrcode_supplement_ab
            FROM {table_name}
            GROUP BY ddist_regcode, dec_id
            ORDER BY ddist_regcode, dec_id ASC
        """
        df = pd.read_sql(q, conn)
        rows_data = []
        for sr, (_, row) in enumerate(df.iterrows(), 1):
            reg_code = row.get('ddist_regcode')
            try:
                reg_code_int = int(float(reg_code)) if reg_code is not None and str(reg_code).strip() != '' else None
            except (ValueError, TypeError):
                reg_code_int = None
            try:
                reg_code_display = int(float(reg_code)) if reg_code is not None else '-'
            except (ValueError, TypeError):
                reg_code_display = reg_code if reg_code is not None else '-'
            region_name = get_region_name(reg_code_int) if reg_code_int else (str(reg_code) if reg_code else '-')
            dec_id = row.get('dec_id')
            dec_id_display = int(dec_id) if dec_id is not None and str(dec_id).strip() != '' else (dec_id if dec_id is not None else '-')
            try:
                dec_id_display = int(float(dec_id)) if dec_id is not None and str(dec_id).strip() != '' else '-'
            except (ValueError, TypeError):
                dec_id_display = dec_id if dec_id is not None else '-'
            rows_data.append({
                'sr_no': sr,
                'ddist_regcode': reg_code_display,
                'region_name': region_name,
                'dec_id': dec_id_display,
                'used_32_page_main_ab': int(row.get('used_32_page_main_ab') or 0),
                'used_32_page_supplement_ab': int(row.get('used_32_page_supplement_ab') or 0),
                'used_drawing_sheet_main_ab': int(row.get('used_drawing_sheet_main_ab') or 0),
                'used_drawing_sheet_supplement_ab': int(row.get('used_drawing_sheet_supplement_ab') or 0),
                'used_32_page_barcode_main_ab': int(row.get('used_32_page_barcode_main_ab') or 0),
                'used_32_page_barcode_supplement_ab': int(row.get('used_32_page_barcode_supplement_ab') or 0),
                'used_32_page_qrcode_main_ab': int(row.get('used_32_page_qrcode_main_ab') or 0),
                'used_32_page_qrcode_supplement_ab': int(row.get('used_32_page_qrcode_supplement_ab') or 0),
            })
            totals_row = {
                'used_32_page_main_ab': sum(r['used_32_page_main_ab'] for r in rows_data),
                'used_32_page_supplement_ab': sum(r['used_32_page_supplement_ab'] for r in rows_data),
                'used_drawing_sheet_main_ab': sum(r['used_drawing_sheet_main_ab'] for r in rows_data),
                'used_drawing_sheet_supplement_ab': sum(r['used_drawing_sheet_supplement_ab'] for r in rows_data),
                'used_32_page_barcode_main_ab': sum(r['used_32_page_barcode_main_ab'] for r in rows_data),
                'used_32_page_barcode_supplement_ab': sum(r['used_32_page_barcode_supplement_ab'] for r in rows_data),
                'used_32_page_qrcode_main_ab': sum(r['used_32_page_qrcode_main_ab'] for r in rows_data),
                'used_32_page_qrcode_supplement_ab': sum(r['used_32_page_qrcode_supplement_ab'] for r in rows_data),
            }

        current_exam = getattr(msbte_config, 'ACA_NAME_EXAM_W', 'Winter 2025')
        context = {
            'report_title': 'Exam Center Wise Used Count',
            'rows_data': rows_data,
            'current_exam': current_exam,
            'user_name': user_name,
            'print_date': datetime.now().strftime('%Y-%m-%d %I:%M:%S %p'),
            'totals_row': totals_row,
        }
        return render(request, 'stationary/exam_center_wise_used_count_report.html', context)
    except Exception as e:
        logger.error(f"Error in exam_center_wise_used_count_report: {str(e)}", exc_info=True)
        messages.error(request, f'An error occurred while generating the report: {str(e)}')
        return redirect('dashboard:stationary:stationary_home')

@jwt_report_authorized(allowed_roles=['ADMIN'])
def exam_center_wise_balance_report(request):
    """
    Exam Center Wise Balance Report - Admin only.
    Calculates: Balance = Total Issued - Used
    """
    auth, error = get_auth_context(request, require_institute=False)
    if error:
        return error

    user_info, error = get_user_control_info(
        request,
        auth,
        allowed_roles=['ADMIN'],
        require_institute_code=False,
        require_rbte_code=False,
        redirect_url='dashboard:stationary:stationary_home',
    )
    if error:
        return error

    user_name = user_info.get('user_name', '') or (
        request.user.username if request.user.is_authenticated else ''
    )

    daily_table = getattr(msbte_config, 'W25_DAILY_STATIONERY_DETAILS', None)
    total_table = getattr(msbte_config, 'STATIONERY_DETAILS', None)

    if not daily_table or not total_table:
        messages.error(request, 'Report configuration is not available.')
        return redirect('dashboard:stationary:stationary_home')

    try:
        conn = get_db_connection()

        # 1. USED QUERY
        used_query = f"""
            SELECT
                ddist_regcode,
                dec_id,
                SUM(duse_book_32_rem) AS used_32,
                SUM(duse_book_32_supl_rem) AS used_32_sup,
                SUM(duse_drawing_book_rem) AS used_drawing,
                SUM(duse_drawing_book_supl_rem) AS used_drawing_sup,
                SUM(duse_book_code_32_rem) AS used_32_code,
                SUM(duse_book_code_32_supl_rem) AS used_32_code_sup,
                SUM(duse_book_32_qr_code_rem) AS used_32_qr,
                SUM(duse_book_32_qr_supl_rem) AS used_32_qr_sup
            FROM {daily_table}
            GROUP BY ddist_regcode, dec_id
        """
        used_df = pd.read_sql(used_query, conn)

        used_dict = {}
        for _, row in used_df.iterrows():
            r = row.get('ddist_regcode')
            d = row.get('dec_id')
            key = _balance_report_key(r, d)
            used_dict[key] = row.to_dict()

        # 2. TOTAL ISSUED QUERY
        total_query = f"""
            SELECT
                dist_regcode,
                ec_id,
                book_32_rem,
                book_32_supl_rem,
                drawing_book_rem,
                drawing_book_supl_rem,
                book_code_32_rem,
                book_code_32_supl_rem,
                book_32_qr_rem,
                book_code_32_qr_supl_rem
            FROM {total_table}
        """
        total_df = pd.read_sql(total_query, conn)

        # 3. CALCULATE BALANCE
        rows_data = []
        for sr, (_, row) in enumerate(total_df.iterrows(), 1):
            dist_code = row.get('dist_regcode')
            ec_id = row.get('ec_id')

            key = _balance_report_key(dist_code, ec_id)
            used = used_dict.get(key, {})

            try:
                reg_code_int = int(float(dist_code)) if dist_code is not None and pd.notna(dist_code) and str(dist_code).strip() != '' else None
            except (ValueError, TypeError):
                reg_code_int = None

            balance_data = {
                'sr_no': sr,
                'ddist_regcode': dist_code,
                'region_name': get_region_name(reg_code_int) if reg_code_int is not None else '-',
                'dec_id': ec_id,
                'balance_32': safe_int(row.get('book_32_rem')) - safe_int(used.get('used_32')),
                'balance_32_sup': safe_int(row.get('book_32_supl_rem')) - safe_int(used.get('used_32_sup')),
                'balance_drawing': safe_int(row.get('drawing_book_rem')) - safe_int(used.get('used_drawing')),
                'balance_drawing_sup': safe_int(row.get('drawing_book_supl_rem')) - safe_int(used.get('used_drawing_sup')),
                'balance_32_code': safe_int(row.get('book_code_32_rem')) - safe_int(used.get('used_32_code')),
                'balance_32_code_sup': safe_int(row.get('book_code_32_supl_rem')) - safe_int(used.get('used_32_code_sup')),
                'balance_32_qr': safe_int(row.get('book_32_qr_rem')) - safe_int(used.get('used_32_qr')),
                'balance_32_qr_sup': safe_int(row.get('book_code_32_qr_supl_rem')) - safe_int(used.get('used_32_qr_sup')),
            }
            rows_data.append(balance_data)

        totals_row = {
            'balance_32': sum(r['balance_32'] for r in rows_data),
            'balance_32_sup': sum(r['balance_32_sup'] for r in rows_data),
            'balance_drawing': sum(r['balance_drawing'] for r in rows_data),
            'balance_drawing_sup': sum(r['balance_drawing_sup'] for r in rows_data),
            'balance_32_code': sum(r['balance_32_code'] for r in rows_data),
            'balance_32_code_sup': sum(r['balance_32_code_sup'] for r in rows_data),
            'balance_32_qr': sum(r['balance_32_qr'] for r in rows_data),
            'balance_32_qr_sup': sum(r['balance_32_qr_sup'] for r in rows_data),
        }

        current_exam = getattr(msbte_config, 'ACA_NAME_EXAM_W', 'Winter 2025')
        context = {
            'report_title': 'Exam Center Wise Balance Report',
            'rows_data': rows_data,
            'current_exam': current_exam,
            'user_name': user_name,
            'print_date': datetime.now().strftime('%Y-%m-%d %I:%M:%S %p'),
            'totals_row': totals_row,
        }
        return render(request, 'stationary/exam_center_wise_balance_report.html', context)

    except Exception as e:
        logger.error(f"Error in exam_center_wise_balance_report: {str(e)}", exc_info=True)
        messages.error(request, f'An error occurred while generating the report: {str(e)}')
        return redirect('dashboard:stationary:stationary_home')

@jwt_report_authorized(allowed_roles=['ADMIN'])
def region_wise_used_count_report(request):
    """
    Region Wise Used Count - Admin only.
    Query: w25_daily_stationery_details grouped by ddist_regcode with SUMs of used books/sheets.
    """
    auth, error = get_auth_context(request, require_institute=False)
    if error:
        return error
    user_info, error = get_user_control_info(
        request,
        auth,
        allowed_roles=['ADMIN'],
        require_institute_code=False,
        require_rbte_code=False,
        redirect_url='dashboard:stationary:stationary_home',
    )
    if error:
        return error

    user_name = user_info.get('user_name', '') or (request.user.username if request.user.is_authenticated else '')
    table_name = getattr(msbte_config, 'W25_DAILY_STATIONERY_DETAILS', None)
    if not table_name:
        messages.error(request, 'Report configuration (W25_DAILY_STATIONERY_DETAILS) is not available.')
        return redirect('dashboard:stationary:stationary_home')

    try:
        conn = get_db_connection()
        q = f"""
            SELECT
                ddist_regcode,
                SUM(duse_book_32_rem) AS used_32_page_main_ab,
                SUM(duse_book_32_supl_rem) AS used_32_page_supplement_ab,
                SUM(duse_drawing_book_rem) AS used_drawing_sheet_main_ab,
                SUM(duse_drawing_book_supl_rem) AS used_drawing_sheet_supplement_ab,
                SUM(duse_book_code_32_rem) AS used_32_page_barcode_main_ab,
                SUM(duse_book_code_32_supl_rem) AS used_32_page_barcode_supplement_ab,
                SUM(duse_book_32_qr_code_rem) AS used_32_page_qrcode_main_ab,
                SUM(duse_book_32_qr_supl_rem) AS used_32_page_qrcode_supplement_ab
            FROM {table_name}
            GROUP BY ddist_regcode
            ORDER BY ddist_regcode ASC
        """
        df = pd.read_sql(q, conn)
        rows_data = []
        for sr, (_, row) in enumerate(df.iterrows(), 1):
            reg_code = row.get('ddist_regcode')
            try:
                reg_code_int = int(float(reg_code)) if reg_code is not None and str(reg_code).strip() != '' else None
            except (ValueError, TypeError):
                reg_code_int = None
            try:
                reg_code_display = int(float(reg_code)) if reg_code is not None else '-'
            except (ValueError, TypeError):
                reg_code_display = reg_code if reg_code is not None else '-'
            region_name = get_region_name(reg_code_int) if reg_code_int else (str(reg_code) if reg_code else '-')
            rows_data.append({
                'sr_no': sr,
                'ddist_regcode': reg_code_display,
                'region_name': region_name,
                'used_32_page_main_ab': safe_int(row.get('used_32_page_main_ab')),
                'used_32_page_supplement_ab': safe_int(row.get('used_32_page_supplement_ab')),
                'used_drawing_sheet_main_ab': safe_int(row.get('used_drawing_sheet_main_ab')),
                'used_drawing_sheet_supplement_ab': safe_int(row.get('used_drawing_sheet_supplement_ab')),
                'used_32_page_barcode_main_ab': safe_int(row.get('used_32_page_barcode_main_ab')),
                'used_32_page_barcode_supplement_ab': safe_int(row.get('used_32_page_barcode_supplement_ab')),
                'used_32_page_qrcode_main_ab': safe_int(row.get('used_32_page_qrcode_main_ab')),
                'used_32_page_qrcode_supplement_ab': safe_int(row.get('used_32_page_qrcode_supplement_ab')),
            })
        totals_row = {
            'used_32_page_main_ab': sum(r['used_32_page_main_ab'] for r in rows_data),
            'used_32_page_supplement_ab': sum(r['used_32_page_supplement_ab'] for r in rows_data),
            'used_drawing_sheet_main_ab': sum(r['used_drawing_sheet_main_ab'] for r in rows_data),
            'used_drawing_sheet_supplement_ab': sum(r['used_drawing_sheet_supplement_ab'] for r in rows_data),
            'used_32_page_barcode_main_ab': sum(r['used_32_page_barcode_main_ab'] for r in rows_data),
            'used_32_page_barcode_supplement_ab': sum(r['used_32_page_barcode_supplement_ab'] for r in rows_data),
            'used_32_page_qrcode_main_ab': sum(r['used_32_page_qrcode_main_ab'] for r in rows_data),
            'used_32_page_qrcode_supplement_ab': sum(r['used_32_page_qrcode_supplement_ab'] for r in rows_data),
        }
        current_exam = getattr(msbte_config, 'ACA_NAME_EXAM_W', 'Winter 2025')
        context = {
            'report_title': 'Region Wise Used Count',
            'rows_data': rows_data,
            'current_exam': current_exam,
            'user_name': user_name,
            'print_date': datetime.now().strftime('%Y-%m-%d %I:%M:%S %p'),
            'totals_row': totals_row,
        }
        return render(request, 'stationary/region_wise_used_count_report.html', context)
    except Exception as e:
        logger.error(f"Error in region_wise_used_count_report: {str(e)}", exc_info=True)
        messages.error(request, f'An error occurred while generating the report: {str(e)}')
        return redirect('dashboard:stationary:stationary_home')

@jwt_report_authorized(allowed_roles=['ADMIN'])
def region_wise_balance_report(request):
    """
    Region Wise Balance Report - Admin only.
    Balance = Total Issued (per region) - Used (per region). Uses SUMs grouped by dist_regcode/ddist_regcode.
    Includes a totals row for each balance column.
    """
    auth, error = get_auth_context(request, require_institute=False)
    if error:
        return error

    user_info, error = get_user_control_info(
        request,
        auth,
        allowed_roles=['ADMIN'],
        require_institute_code=False,
        require_rbte_code=False,
        redirect_url='dashboard:stationary:stationary_home',
    )
    if error:
        return error

    user_name = user_info.get('user_name', '') or (
        request.user.username if request.user.is_authenticated else ''
    )

    daily_table = getattr(msbte_config, 'W25_DAILY_STATIONERY_DETAILS', None)
    total_table = getattr(msbte_config, 'STATIONERY_DETAILS', None)

    if not daily_table or not total_table:
        messages.error(request, 'Report configuration is not available.')
        return redirect('dashboard:stationary:stationary_home')

    try:
        conn = get_db_connection()

        # 1. USED QUERY (per region)
        used_query = f"""
            SELECT
                ddist_regcode,
                SUM(duse_book_32_rem) AS used_32,
                SUM(duse_book_32_supl_rem) AS used_32_sup,
                SUM(duse_drawing_book_rem) AS used_drawing,
                SUM(duse_drawing_book_supl_rem) AS used_drawing_sup,
                SUM(duse_book_code_32_rem) AS used_32_code,
                SUM(duse_book_code_32_supl_rem) AS used_32_code_sup,
                SUM(duse_book_32_qr_code_rem) AS used_32_qr,
                SUM(duse_book_32_qr_supl_rem) AS used_32_qr_sup
            FROM {daily_table}
            GROUP BY ddist_regcode
            ORDER BY ddist_regcode ASC
        """
        used_df = pd.read_sql(used_query, conn)

        used_dict = {}
        for _, row in used_df.iterrows():
            r = row.get('ddist_regcode')
            key = _balance_report_key(r, None)[0]
            used_dict[key] = row.to_dict()

        # 2. TOTAL ISSUED QUERY (per region)
        total_query = f"""
            SELECT
                dist_regcode,
                SUM(book_32_rem) AS total_32,
                SUM(book_32_supl_rem) AS total_32_sup,
                SUM(drawing_book_rem) AS total_drawing,
                SUM(drawing_book_supl_rem) AS total_drawing_sup,
                SUM(book_code_32_rem) AS total_32_code,
                SUM(book_code_32_supl_rem) AS total_32_code_sup,
                SUM(book_32_qr_rem) AS total_32_qr_code,
                SUM(book_code_32_qr_supl_rem) AS total_32_qr_code_sup
            FROM {total_table}
            GROUP BY dist_regcode
            ORDER BY dist_regcode ASC
        """
        total_df = pd.read_sql(total_query, conn)

        # 3. CALCULATE BALANCE PER REGION + TOTALS
        rows_data = []
        tot_32 = tot_32_sup = tot_drawing = tot_drawing_sup = 0
        tot_32_code = tot_32_code_sup = tot_32_qr = tot_32_qr_sup = 0

        for sr, (_, row) in enumerate(total_df.iterrows(), 1):
            dist_code = row.get('dist_regcode')
            key = _balance_report_key(dist_code, None)[0]
            used = used_dict.get(key, {})

            try:
                reg_code_int = int(float(dist_code)) if dist_code is not None and pd.notna(dist_code) and str(dist_code).strip() != '' else None
            except (ValueError, TypeError):
                reg_code_int = None
            reg_code_display = reg_code_int if reg_code_int is not None else (dist_code if dist_code is not None else '-')

            balance_32 = safe_int(row.get('total_32')) - safe_int(used.get('used_32'))
            balance_32_sup = safe_int(row.get('total_32_sup')) - safe_int(used.get('used_32_sup'))
            balance_drawing = safe_int(row.get('total_drawing')) - safe_int(used.get('used_drawing'))
            balance_drawing_sup = safe_int(row.get('total_drawing_sup')) - safe_int(used.get('used_drawing_sup'))
            balance_32_code = safe_int(row.get('total_32_code')) - safe_int(used.get('used_32_code'))
            balance_32_code_sup = safe_int(row.get('total_32_code_sup')) - safe_int(used.get('used_32_code_sup'))
            balance_32_qr = safe_int(row.get('total_32_qr_code')) - safe_int(used.get('used_32_qr'))
            balance_32_qr_sup = safe_int(row.get('total_32_qr_code_sup')) - safe_int(used.get('used_32_qr_sup'))

            tot_32 += balance_32
            tot_32_sup += balance_32_sup
            tot_drawing += balance_drawing
            tot_drawing_sup += balance_drawing_sup
            tot_32_code += balance_32_code
            tot_32_code_sup += balance_32_code_sup
            tot_32_qr += balance_32_qr
            tot_32_qr_sup += balance_32_qr_sup

            balance_data = {
                'sr_no': sr,
                'ddist_regcode': reg_code_display,
                'region_name': get_region_name(reg_code_int) if reg_code_int is not None else '-',
                'balance_32': balance_32,
                'balance_32_sup': balance_32_sup,
                'balance_drawing': balance_drawing,
                'balance_drawing_sup': balance_drawing_sup,
                'balance_32_code': balance_32_code,
                'balance_32_code_sup': balance_32_code_sup,
                'balance_32_qr': balance_32_qr,
                'balance_32_qr_sup': balance_32_qr_sup,
            }
            rows_data.append(balance_data)

        totals_row = {
            'balance_32': tot_32,
            'balance_32_sup': tot_32_sup,
            'balance_drawing': tot_drawing,
            'balance_drawing_sup': tot_drawing_sup,
            'balance_32_code': tot_32_code,
            'balance_32_code_sup': tot_32_code_sup,
            'balance_32_qr': tot_32_qr,
            'balance_32_qr_sup': tot_32_qr_sup,
        }

        current_exam = getattr(msbte_config, 'ACA_NAME_EXAM_W', 'Winter 2025')
        context = {
            'report_title': 'Region Wise Balance Report',
            'rows_data': rows_data,
            'totals_row': totals_row,
            'current_exam': current_exam,
            'user_name': user_name,
            'print_date': datetime.now().strftime('%Y-%m-%d %I:%M:%S %p'),
        }
        return render(request, 'stationary/region_wise_balance_report.html', context)
    except Exception as e:
        logger.error(f"Error in region_wise_balance_report: {str(e)}", exc_info=True)
        messages.error(request, f'An error occurred while generating the report: {str(e)}')
        return redirect('dashboard:stationary:stationary_home')


@jwt_report_authorized(allowed_roles=['ADMIN'])
def stationery_conf_unconf_summary_report(request):
    """
    Region wise summary of confirmed / unconfirmed exam centers for stationery.
    - conf_cnt: count of records in w25_stationery_details with conf = 'Y'
    - unconf_cnt: count of records in w25_stationery_details with conf != 'Y'
                  PLUS count of exam centers from w25_th_input_center_code_25Feb
                  where center_code not present in w25_stationery_details.
    """
    auth, error = get_auth_context(request, require_institute=False)
    if error:
        return error

    user_info, error = get_user_control_info(
        request,
        auth,
        allowed_roles=['ADMIN'],
        require_institute_code=False,
        require_rbte_code=False,
        redirect_url='dashboard:stationary:stationary_home',
    )
    if error:
        return error

    user_name = user_info.get('user_name', '') or (
        request.user.username if request.user.is_authenticated else ''
    )

    try:
        conn = get_db_connection()

        # Base summary from w25_stationery_details
        summary_query = f"""
            SELECT
                dist_regcode,
                SUM(CASE WHEN conf = 'Y' THEN 1 ELSE 0 END) AS conf_cnt,
                SUM(CASE WHEN conf = 'Y' THEN 0 ELSE 1 END) AS unconf_cnt
            FROM {msbte_config.STATIONERY_DETAILS}
            GROUP BY dist_regcode
        """

        df_summary = pd.read_sql(summary_query, conn)

        # Additional unconfirmed exam centers from w25_th_input_center_code_25Feb
        extra_unconf_query = f"""
            SELECT
                reg_code AS dist_regcode,
                COUNT(*) AS extra_unconf_cnt
            FROM {msbte_config.TH_INPUT_CENTER_CODE}
            WHERE center_code NOT IN (SELECT ec_id FROM {msbte_config.STATIONERY_DETAILS})
            GROUP BY reg_code
        """

        try:
            df_extra = pd.read_sql(extra_unconf_query, conn)
        except Exception:
            # If the additional table is not available, fall back to only stationery_details
            df_extra = pd.DataFrame(columns=['dist_regcode', 'extra_unconf_cnt'])

        # Merge and compute final unconfirmed count
        merged = pd.merge(
            df_summary,
            df_extra,
            on='dist_regcode',
            how='outer',
        )

        merged['conf_cnt'] = merged['conf_cnt'].fillna(0).astype(int)
        merged['unconf_base'] = merged['unconf_cnt'].fillna(0).astype(int)
        merged['extra_unconf_cnt'] = merged['extra_unconf_cnt'].fillna(0).astype(int)
        merged['unconf_cnt'] = merged['unconf_base'] + merged['extra_unconf_cnt']

        rows_data = []
        total_conf = total_unconf = 0

        merged = merged.sort_values(by='dist_regcode')

        for sr, (_, row) in enumerate(merged.iterrows(), 1):
            dist_code = row.get('dist_regcode')
            try:
                reg_code_int = (
                    int(dist_code)
                    if dist_code is not None and pd.notna(dist_code) and str(dist_code).strip() != ''
                    else None
                )
            except (ValueError, TypeError):
                reg_code_int = None

            reg_code_display = (
                reg_code_int
                if reg_code_int is not None
                else (dist_code if dist_code is not None else '-')
            )

            region_name = (
                get_region_name(reg_code_int)
                if reg_code_int is not None
                else (str(dist_code) if dist_code is not None else '-')
            )

            conf_cnt = int(row.get('conf_cnt') or 0)
            unconf_cnt = int(row.get('unconf_cnt') or 0)

            total_conf += conf_cnt
            total_unconf += unconf_cnt

            rows_data.append(
                {
                    'sr_no': sr,
                    'ddist_regcode': reg_code_display,
                    'region_name': region_name,
                    'conf_cnt': conf_cnt,
                    'unconf_cnt': unconf_cnt,
                }
            )

        totals_row = {
            'conf_cnt': total_conf,
            'unconf_cnt': total_unconf,
        }

        current_exam = msbte_config.ACA_NAME_EXAM_W
        context = {
            'report_title': 'Region Wise Stationery Confirmation Status',
            'rows_data': rows_data,
            'totals_row': totals_row,
            'current_exam': current_exam,
            'user_name': user_name,
            'print_date': datetime.now().strftime('%Y-%m-%d %I:%M:%S %p'),
        }
        return render(
            request,
            'stationary/stationery_conf_unconf_summary_report.html',
            context,
        )
    except Exception as e:
        logger.error(f"Error in stationery_conf_unconf_summary_report: {str(e)}", exc_info=True)
        messages.error(request, f'An error occurred while generating the report: {str(e)}')
        return redirect('dashboard:stationary:stationary_home')


@jwt_report_authorized(allowed_roles=['ADMIN'])
def stationery_conf_details(request, dist_regcode):
    """
    Detailed list of confirmed exam centers (conf = 'Y') for a given region (dist_regcode).
    """
    auth, error = get_auth_context(request, require_institute=False)
    if error:
        return error

    user_info, error = get_user_control_info(
        request,
        auth,
        allowed_roles=['ADMIN'],
        require_institute_code=False,
        require_rbte_code=False,
        redirect_url='dashboard:stationary:stationary_home',
    )
    if error:
        return error

    user_name = user_info.get('user_name', '') or (
        request.user.username if request.user.is_authenticated else ''
    )

    try:
        conn = get_db_connection()

        details_query = f"""
            SELECT
                a.dist_regcode,
                a.ec_id,
                CONCAT(b.inst_name, ', ', b.city_name) AS inst_name
            FROM {msbte_config.STATIONERY_DETAILS} a
            JOIN {msbte_config.INSTITUTES} b ON a.ec_id = b.inst_id
            WHERE a.conf = 'Y' AND a.dist_regcode = %s
            ORDER BY a.ec_id
        """

        df = pd.read_sql(details_query, conn, params=[dist_regcode])

        rows_data = []
        for sr, (_, row) in enumerate(df.iterrows(), 1):
            rows_data.append(
                {
                    'sr_no': sr,
                    'dist_regcode': row.get('dist_regcode'),
                    'ec_id': row.get('ec_id'),
                    'inst_name': row.get('inst_name'),
                }
            )

        try:
            reg_code_int = (
                int(dist_regcode)
                if dist_regcode is not None and str(dist_regcode).strip() != ''
                else None
            )
        except (ValueError, TypeError):
            reg_code_int = None

        region_name = (
            get_region_name(reg_code_int)
            if reg_code_int is not None
            else (str(dist_regcode) if dist_regcode is not None else '-')
        )

        current_exam = msbte_config.ACA_NAME_EXAM_W
        context = {
            'report_title': f'Confirmed Exam Centers - Region {dist_regcode}',
            'rows_data': rows_data,
            'region_name': region_name,
            'dist_regcode': dist_regcode,
            'current_exam': current_exam,
            'user_name': user_name,
            'print_date': datetime.now().strftime('%Y-%m-%d %I:%M:%S %p'),
        }
        return render(
            request,
            'stationary/stationery_conf_details_report.html',
            context,
        )
    except Exception as e:
        logger.error(f"Error in stationery_conf_details: {str(e)}", exc_info=True)
        messages.error(request, f'An error occurred while generating the report: {str(e)}')
        return redirect('dashboard:stationary:stationary_home')


@jwt_report_authorized(allowed_roles=['ADMIN'])
def stationery_unconf_details(request, dist_regcode):
    """
    Detailed list of unconfirmed exam centers for a given region (dist_regcode).
    Combines:
      - w25_stationery_details with conf != 'Y'
      - w25_th_input_center_code_25Feb where center_code not in w25_stationery_details
    """
    auth, error = get_auth_context(request, require_institute=False)
    if error:
        return error

    user_info, error = get_user_control_info(
        request,
        auth,
        allowed_roles=['ADMIN'],
        require_institute_code=False,
        require_rbte_code=False,
        redirect_url='dashboard:stationary:stationary_home',
    )
    if error:
        return error

    user_name = user_info.get('user_name', '') or (
        request.user.username if request.user.is_authenticated else ''
    )

    try:
        conn = get_db_connection()

        # Unconfirmed from stationery_details
        unconf_stationery_query = f"""
            SELECT
                a.dist_regcode,
                a.ec_id,
                CONCAT(b.inst_name, ', ', b.city_name) AS inst_name,
                'STATIONERY' AS source
            FROM {msbte_config.STATIONERY_DETAILS} a
            JOIN {msbte_config.INSTITUTES} b ON a.ec_id = b.inst_id
            WHERE (a.conf <> 'Y' OR a.conf IS NULL)
              AND a.dist_regcode = %s
        """

        df_unconf_stationery = pd.read_sql(
            unconf_stationery_query,
            conn,
            params=[dist_regcode],
        )

        # Additional centers from w25_th_input_center_code_25Feb
        extra_unconf_query = f"""
            SELECT
                reg_code AS dist_regcode,
                center_code AS ec_id,
                CONCAT(inst_name, ', ', city_name) AS inst_name,
                'EXAM_CENTER' AS source
            FROM {msbte_config.TH_INPUT_CENTER_CODE}
            WHERE center_code NOT IN (SELECT ec_id FROM {msbte_config.STATIONERY_DETAILS})
              AND reg_code = %s
        """

        try:
            df_extra_unconf = pd.read_sql(
                extra_unconf_query,
                conn,
                params=[dist_regcode],
            )
        except Exception:
            df_extra_unconf = pd.DataFrame(columns=['dist_regcode', 'ec_id', 'inst_name', 'source'])

        df_all = pd.concat(
            [df_unconf_stationery, df_extra_unconf],
            ignore_index=True,
        )

        if not df_all.empty:
            df_all = df_all.sort_values(by=['dist_regcode', 'ec_id'])

        rows_data = []
        for sr, (_, row) in enumerate(df_all.iterrows(), 1):
            rows_data.append(
                {
                    'sr_no': sr,
                    'dist_regcode': row.get('dist_regcode'),
                    'ec_id': row.get('ec_id'),
                    'inst_name': row.get('inst_name'),
                    'source': row.get('source'),
                }
            )

        try:
            reg_code_int = (
                int(dist_regcode)
                if dist_regcode is not None and str(dist_regcode).strip() != ''
                else None
            )
        except (ValueError, TypeError):
            reg_code_int = None

        region_name = (
            get_region_name(reg_code_int)
            if reg_code_int is not None
            else (str(dist_regcode) if dist_regcode is not None else '-')
        )

        current_exam = msbte_config.ACA_NAME_EXAM_W
        context = {
            'report_title': f'Unconfirmed Exam Centers - Region {dist_regcode}',
            'rows_data': rows_data,
            'region_name': region_name,
            'dist_regcode': dist_regcode,
            'current_exam': current_exam,
            'user_name': user_name,
            'print_date': datetime.now().strftime('%Y-%m-%d %I:%M:%S %p'),
        }
        return render(
            request,
            'stationary/stationery_unconf_details_report.html',
            context,
        )
    except Exception as e:
        logger.error(f"Error in stationery_unconf_details: {str(e)}", exc_info=True)
        messages.error(request, f'An error occurred while generating the report: {str(e)}')
        return redirect('dashboard:stationary:stationary_home')


@jwt_report_authorized(allowed_roles=['ADMIN'])
def stationary_statistic_requirement_report(request):
    auth, error = get_auth_context(request, require_institute=False)
    if error:
        return error

    user_info, error = get_user_control_info(
        request,
        auth,
        allowed_roles=['ADMIN'],
        require_institute_code=False,
        require_rbte_code=False,
        redirect_url='dashboard:stationary:stationary_home',
    )
    if error:
        return error

    user_name = user_info.get('user_name', '') or (request.user.username if request.user.is_authenticated else '')

    # Exams (match your PHP labels; or pull from msbte_config if you prefer)
    second_last_exam = 'Winter 2024'
    last_exam = 'Summer 2025'
    current_exam = 'Winter 2025'
    next_exam = 'Summer 2026'

    try:
        conn = get_db_connection()

        table_name = f"{msbte_config.EXAM_DB}.w25_stationary"

        q = f"""
            SELECT
                reg_code,
                SUM(`32page_required_w`)           AS require_winter_2025_32Pages,
                SUM(`32page_required_s`)           AS require_summer_2026_32Pages,
                SUM(`32page_bal_w_barcode`)        AS avaiable_32_barcode,
                SUM(`32page_bal_w`)                AS avaiable_32_without_barcode,
                SUM(`32page_net_required`)         AS net_require_32Pages,

                SUM(`mask_stiker_required_w`)      AS require_winter_2025_masking_sticker,
                SUM(`mask_stiker_required_s`)      AS require_summer_2026_masking_sticker,
                SUM(`mask_stiker_bal_w_barcode`)   AS avaiable_masking_barcode,
                SUM(`mask_stiker_bal_w`)           AS avaiable_masking_without_barcode,
                SUM(`mask_stiker_net_required`)    AS net_require_masking_sticker,

                SUM(`drawing_sheet_required_w`)    AS require_winter_2025_drawing_sheet,
                SUM(`drawing_sheet_required_s`)    AS require_summer_2026_drawing_sheet,
                SUM(`drawing_sheet_bal_w_barcode`) AS avaiable_drawing_barcode,
                SUM(`drawing_sheet_bal_w`)         AS avaiable_drawing_without_barcode,
                SUM(`drawing_sheet_net_required`)  AS net_require_drawing_sheet
            FROM {table_name}
            WHERE rbte_conf = 'Y'
            GROUP BY reg_code
            ORDER BY reg_code
        """

        df = pd.read_sql(q, conn)

        rows_data = []
        totals = {
            'require_winter_2025_32Pages': 0,
            'require_winter_2025_drawing_sheet': 0,
            'require_winter_2025_masking_sticker': 0,
            'require_summer_2026_32Pages': 0,
            'require_summer_2026_drawing_sheet': 0,
            'require_summer_2026_masking_sticker': 0,
            'avaiable_32_barcode': 0,
            'avaiable_drawing_barcode': 0,
            'avaiable_masking_barcode': 0,
            'avaiable_32_without_barcode': 0,
            'avaiable_drawing_without_barcode': 0,
            'avaiable_masking_without_barcode': 0,
            'net_require_32Pages': 0,
            'net_require_drawing_sheet': 0,
            'net_require_masking_sticker': 0,
        }

        for sr, (_, row) in enumerate(df.iterrows(), 1):
            reg_code = row.get('reg_code')
            try:
                reg_code_int = int(float(reg_code)) if reg_code is not None and str(reg_code).strip() != '' else None
            except (ValueError, TypeError):
                reg_code_int = None

            rec = {
                'sr_no': sr,
                'reg_code': reg_code_int if reg_code_int is not None else (reg_code if reg_code is not None else '-'),
                'region_name': get_region_name(reg_code_int) if reg_code_int is not None else '-',

                'require_winter_2025_32Pages': safe_int(row.get('require_winter_2025_32Pages')),
                'require_winter_2025_drawing_sheet': safe_int(row.get('require_winter_2025_drawing_sheet')),
                'require_winter_2025_masking_sticker': safe_int(row.get('require_winter_2025_masking_sticker')),

                'require_summer_2026_32Pages': safe_int(row.get('require_summer_2026_32Pages')),
                'require_summer_2026_drawing_sheet': safe_int(row.get('require_summer_2026_drawing_sheet')),
                'require_summer_2026_masking_sticker': safe_int(row.get('require_summer_2026_masking_sticker')),

                'avaiable_32_barcode': safe_int(row.get('avaiable_32_barcode')),
                'avaiable_drawing_barcode': safe_int(row.get('avaiable_drawing_barcode')),
                'avaiable_masking_barcode': safe_int(row.get('avaiable_masking_barcode')),

                'avaiable_32_without_barcode': safe_int(row.get('avaiable_32_without_barcode')),
                'avaiable_drawing_without_barcode': safe_int(row.get('avaiable_drawing_without_barcode')),
                'avaiable_masking_without_barcode': safe_int(row.get('avaiable_masking_without_barcode')),

                'net_require_32Pages': safe_int(row.get('net_require_32Pages')),
                'net_require_drawing_sheet': safe_int(row.get('net_require_drawing_sheet')),
                'net_require_masking_sticker': safe_int(row.get('net_require_masking_sticker')),
            }

            for k in totals:
                totals[k] += rec[k]

            rows_data.append(rec)

        context = {
            'report_title': 'Stationary Statistic Requirement Report',
            'rows_data': rows_data,
            'totals_row': totals,
            'second_last_exam': second_last_exam,
            'last_exam': last_exam,
            'current_exam': current_exam,
            'next_exam': next_exam,
            'user_name': user_name,
            'print_date': datetime.now().strftime('%Y-%m-%d %I:%M:%S %p'),
        }
        return render(request, 'stationary/stationary_statistic_requirement_report.html', context)

    except Exception as e:
        logger.error(f"Error in stationary_statistic_requirement_report: {str(e)}", exc_info=True)
        messages.error(request, f'An error occurred while generating the report: {str(e)}')
        return redirect('dashboard:stationary:stationary_home')


def rbte_dc_fill_status_report(request):
    user_name = request.user.username if request.user.is_authenticated else 'Admin'

    try:
        conn = get_db_connection()
        q = f"""
            SELECT
                reg_code,
                COUNT(DISTINCT dc_code) AS rbte_dc,
                COUNT(DISTINCT CASE WHEN dc_srno != '' THEN dc_code END) AS rbte_filled,
                COUNT(DISTINCT CASE WHEN ec_srno != '' THEN dc_code END) AS dc_filled,
                COUNT(DISTINCT CASE WHEN dc_conf = 'Y' THEN dc_code END) AS dc_conf,
                COUNT(DISTINCT CASE WHEN ec_conf = 'Y' THEN ec_code END) AS ec_conf
            FROM {msbte_config.S26_STATIONERY_SRNO_DETAILS}
            GROUP BY reg_code
            ORDER BY reg_code
        """
        df = pd.read_sql(q, conn)

        rows_data = []
        totals_row = {
            'rbte_dc': 0,
            'rbte_filled': 0,
            'dc_filled': 0,
            'dc_conf': 0,
            'ec_conf': 0,
        }

        for sr, (_, row) in enumerate(df.iterrows(), 1):
            reg_code = row.get('reg_code')
            try:
                reg_code_int = int(float(reg_code)) if reg_code is not None and str(reg_code).strip() != '' else None
            except (ValueError, TypeError):
                reg_code_int = None

            rbte_dc = safe_int(row.get('rbte_dc'))
            rbte_filled = safe_int(row.get('rbte_filled'))
            dc_filled = safe_int(row.get('dc_filled'))
            dc_conf = safe_int(row.get('dc_conf'))
            ec_conf = safe_int(row.get('ec_conf'))

            rows_data.append(
                {
                    'sr_no': sr,
                    'region_name': get_region_name(reg_code_int) if reg_code_int is not None else '-',
                    'rbte_dc': rbte_dc,
                    'rbte_filled': rbte_filled,
                    'dc_filled': dc_filled,
                    'dc_conf': dc_conf,
                    'ec_conf': ec_conf,
                }
            )

            totals_row['rbte_dc'] += rbte_dc
            totals_row['rbte_filled'] += rbte_filled
            totals_row['dc_filled'] += dc_filled
            totals_row['dc_conf'] += dc_conf
            totals_row['ec_conf'] += ec_conf

        context = {
            'report_title': 'RBTE / DC Fill SR NO Status Report',
            'rows_data': rows_data,
            'totals_row': totals_row,
            'current_exam': msbte_config.ACA_NAME_EXAM,
            'user_name': user_name,
            'print_date': datetime.now().strftime('%Y-%m-%d %I:%M:%S %p'),
        }
        return render(request, 'stationary/rbte_dc_fill_status_report.html', context)
    except Exception as e:
        logger.error(f"Error in rbte_dc_fill_status_report: {str(e)}", exc_info=True)
        messages.error(request, f'An error occurred while generating the report: {str(e)}')
        return redirect('dashboard:stationary:stationary_home')