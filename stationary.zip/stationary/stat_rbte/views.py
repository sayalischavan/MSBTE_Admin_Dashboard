from django.shortcuts import render, redirect
from django.http import JsonResponse
from django.db import connections
from django.contrib import messages
from django.urls import reverse
import config.msbte_config as msbte_config
from dashboard.decorators import jwt_report_authorized
import logging
from datetime import datetime
import pandas as pd
from dashboard.utils import (
    get_auth_context,
    handle_report_error,
    get_db_connection,
    get_city_names_batch,
    get_inst_name,
    get_city_name,
    get_course_name,
    get_region_name,
    safe_int_stationery,
)
from dashboard.examform.views import _format_inst_code

logger = logging.getLogger(__name__)


def _resolve_dist_regcode_stationery(request, auth, uid, conn, template_name, report_title, current_exam):
    """
    Resolve dist_regcode for RBTE stationery reports (Admin/RBTE only).
    Returns (dist_regcode_int, None) or (None, error_response).
    """
    empty_ctx = {
        'report_data': [],
        'current_exam': current_exam,
        'user_name': auth['user_name'],
        'print_date': datetime.now().strftime('%d/%m/%Y'),
        'report_title': report_title,
    }
    if uid is None or str(uid).strip() in ('', '-'):
        return None, render(request, template_name, empty_ctx)
    try:
        dist_regcode_param = int(float(str(uid).strip()))
    except (ValueError, TypeError):
        messages.error(request, 'Invalid RBTE Code')
        return None, render(request, template_name, empty_ctx)
    return dist_regcode_param, None
#NORMAL RBTE REPORT
@jwt_report_authorized(allowed_roles=['RBTE', 'ADMIN'])
def rbte_stationery_report_institute_info(request):
    """
    Stationery Report of Institute - RBTE Level
    
    PHP Reference: rbte_stationary_institute_info
    - Shows form to select institute
    - For RBTE: filters institutes by reg_code (USER_ID from token/session)
    - For ADMIN: shows all institutes
    - Joins INSTITUTES with STATIONERY_DETAILS where ec_id = inst_id
    """
    auth, error = get_auth_context(request, require_institute=False)
    if error:
        return error
    
    try:
        conn = get_db_connection()
        
        # Get user ID (reg_code) from token/session
        uid = (
            auth.get('rbte_code')
            or request.session.get('USER_ID')
            or getattr(request, 'jwt_user_id', None)
        )
        
        # Get user role
        user_role = (
            auth.get('role')
            or (request.user.groups.first().name if request.user.is_authenticated and request.user.groups.exists() else None)
            or 'RBTE'
        )
        
        # Check if user is admin
        is_admin = (
            (not auth['is_jwt'] and request.user.is_authenticated and request.user.is_staff)
            or auth.get('role') == 'ADMIN'
        )
        
        logger.info(f"rbte_stationery_report_institute_info - uid: {uid}, user_role: {user_role}, is_admin: {is_admin}")
        
        # Get institutes for dropdown based on role
        if is_admin:
            # Admin can see all institutes that have stationery details
            institutes_query = f"""
                SELECT DISTINCT a.inst_id, a.inst_name 
                FROM {msbte_config.INSTITUTES} a
                INNER JOIN {msbte_config.STATIONERY_DETAILS} b ON b.ec_id = a.inst_id
                ORDER BY a.inst_id
            """
            df_institutes = pd.read_sql(institutes_query, conn)
        else:
            # RBTE: use uid (reg_code) directly
            if not uid:
                messages.error(request, 'Unable to determine RBTE code. Please contact administrator.')
                context = {
                    'institutes': [],
                    'selected_inst': '0',
                    'user_name': auth['user_name'],
                    'print_date': datetime.now().strftime('%d/%m/%Y'),
                    'report_title': 'Stationery Report of Institute',
                }
                return render(request, 'stat_rbte/rbte_stationery_report_institute_info.html', context)
            
            try:
                reg_code_int = int(float(str(uid).strip()))
            except (ValueError, TypeError):
                messages.error(request, 'Invalid RBTE Code')
                context = {
                    'institutes': [],
                    'selected_inst': '0',
                    'user_name': auth['user_name'],
                    'print_date': datetime.now().strftime('%d/%m/%Y'),
                    'report_title': 'Stationery Report of Institute',
                }
                return render(request, 'stat_rbte/rbte_stationery_report_institute_info.html', context)
            
            # Query institutes with stationery details for this reg_code
            institutes_query = f"""
                SELECT DISTINCT a.inst_id, a.inst_name 
                FROM {msbte_config.INSTITUTES} a
                INNER JOIN {msbte_config.STATIONERY_DETAILS} b ON b.ec_id = a.inst_id
                WHERE a.reg_code = %s
                ORDER BY a.inst_id
            """
            df_institutes = pd.read_sql(institutes_query, conn, params=[reg_code_int])
        
        institutes = df_institutes.to_dict('records') if len(df_institutes) > 0 else []
        
        if request.method == 'POST':
            selected_inst = request.POST.get('instid', '0')
            
            # Validate institute selection
            if selected_inst == '0' or not selected_inst:
                messages.error(request, 'Please select an Institute.')
                context = {
                    'institutes': institutes,
                    'selected_inst': selected_inst,
                    'user_name': auth['user_name'],
                    'print_date': datetime.now().strftime('%d/%m/%Y'),
                    'report_title': 'Stationery Report of Institute',
                }
                return render(request, 'stat_rbte/rbte_stationery_report_institute_info.html', context)
            
            
             # Redirect to report page
            return redirect(reverse('dashboard:stationary:stat_rbte:rbte_stationary_institute_info') + f'?instid={selected_inst}')
        else:
            # GET request - show form
            context = {
                'institutes': institutes,
                'selected_inst': '0',
                'user_name': auth['user_name'],
                'print_date': datetime.now().strftime('%d/%m/%Y'),
                'report_title': 'Stationery Report of Institute',
            }
            return render(request, 'stat_rbte/rbte_stationery_report_institute_info.html', context)
        
    except Exception as e:
        logger.exception("Error in rbte_stationery_report_institute_info")
        return handle_report_error(request, e, auth['is_jwt'])

@jwt_report_authorized(allowed_roles=['RBTE', 'ADMIN'])
def rbte_stationary_institute_info(request):
    """
    Consolidate report of Stationary Details for Institute - RBTE Level
    
    PHP Reference: rbte_stationary_institute_info
    - Shows consolidated stationary report for selected institute
    - Gets opening balance from STATIONERY_DETAILS
    - Gets used books from DAILY_STATIONERY_DETAILS (summed)
    - Calculates remaining balance = opening - used
    """
    auth, error = get_auth_context(request, require_institute=False)
    if error:
        return error
    
    try:
        conn = get_db_connection()
        
        # Get institute code from request
        inst_code_param = request.GET.get('instid') or request.POST.get('instid')
        
        if not inst_code_param or inst_code_param == '0':
            messages.error(request, 'Please select an Institute.')
            return redirect('dashboard:stationary:stat_rbte:rbte_stationery_report_institute_info')
        
        try:
            inst_code = int(float(str(inst_code_param).lstrip('0')))
        except (ValueError, TypeError):
            messages.error(request, 'Invalid Institute Code')
            return redirect('dashboard:stationary:stat_rbte:rbte_stationery_report_institute_info')
        
        # Get institute details
        inst_query = f"""
            SELECT inst_id, inst_name, reg_code 
            FROM {msbte_config.INSTITUTES} 
            WHERE inst_id = %s
        """
        df_inst = pd.read_sql(inst_query, conn, params=[inst_code])
        
        if len(df_inst) == 0:
            messages.error(request, 'Institute not found.')
            return redirect('dashboard:stationary:stat_rbte:rbte_stationery_report_institute_info')
        
        inst_data = df_inst.iloc[0]
        inst_codef = inst_data['inst_id']
        inst_name = get_inst_name(inst_codef)
        inst_reg = int(inst_data['reg_code']) if pd.notna(inst_data['reg_code']) else None
        
        # Get current exam name
        current_exam = getattr(msbte_config, 'ACA_NAME_EXAM_W', getattr(msbte_config, 'CURRENT_EXAM', msbte_config.EXAM_CODE))
        
        # Query 1: Get opening balance from STATIONERY_DETAILS
        ec_id = inst_code
        query1 = f"""
            SELECT * FROM {msbte_config.STATIONERY_DETAILS} 
            WHERE ec_id = %s
        """
        df_stationery = pd.read_sql(query1, conn, params=[ec_id])
        
        if len(df_stationery) == 0:
            messages.error(request, 'No stationery details found for this institute.')
            return redirect('dashboard:stationary:stat_rbte:rbte_stationery_report_institute_info')
        
        stationery_data = df_stationery.iloc[0]
        
        # Query 2: Get used books (summed) from DAILY_STATIONERY_DETAILS
        query2 = f"""
            SELECT 
                SUM(d32_issue_ans_book) AS d32_issue_ans_book,
                SUM(ddrawing_issue_ans_book) AS ddrawing_issue_ans_book,
                SUM(d32_issue_supl_ans_book) AS d32_issue_supl_ans_book,
                SUM(ddrawing_issue_suppl_ans_book) AS ddrawing_issue_suppl_ans_book,
                SUM(duse_book_32_rem) AS duse_book_32_rem,
                SUM(duse_drawing_book_rem) AS duse_drawing_book_rem,
                SUM(duse_book_32_supl_rem) AS duse_book_32_supl_rem,
                SUM(duse_drawing_book_supl_rem) AS duse_drawing_book_supl_rem,
                SUM(duse_book_code_32_rem) AS duse_book_code_32_rem,
                SUM(duse_book_code_32_supl_rem) AS duse_book_code_32_supl_rem,
                SUM(duse_book_32_qr_code_rem) AS duse_book_32_qr_code_rem,
                SUM(d32_qr_code_issue_ans_book) AS d32_qr_code_issue_ans_book,
                SUM(d32_qr_issue_supl_ans_book) AS d32_qr_issue_supl_ans_book,
                SUM(duse_book_32_qr_supl_rem) AS duse_book_32_qr_supl_rem
            FROM {msbte_config.W25_DAILY_STATIONERY_DETAILS} 
            WHERE dec_id = %s
        """
        df_daily = pd.read_sql(query2, conn, params=[ec_id])
        
        # Initialize totals
        if len(df_daily) > 0:
            daily_data = df_daily.iloc[0]
            d32_issue_ans_book_total = int(daily_data['d32_issue_ans_book']) if pd.notna(daily_data['d32_issue_ans_book']) else 0
            ddrawing_issue_ans_book_total = int(daily_data['ddrawing_issue_ans_book']) if pd.notna(daily_data['ddrawing_issue_ans_book']) else 0
            d32_issue_supl_ans_book_total = int(daily_data['d32_issue_supl_ans_book']) if pd.notna(daily_data['d32_issue_supl_ans_book']) else 0
            ddrawing_issue_suppl_ans_book_total = int(daily_data['ddrawing_issue_suppl_ans_book']) if pd.notna(daily_data['ddrawing_issue_suppl_ans_book']) else 0
            d32_qr_issue_ans_book_total = int(daily_data['d32_qr_code_issue_ans_book']) if pd.notna(daily_data['d32_qr_code_issue_ans_book']) else 0
            d32_qr_issue_supl_ans_book_total = int(daily_data['d32_qr_issue_supl_ans_book']) if pd.notna(daily_data['d32_qr_issue_supl_ans_book']) else 0
            
            duse_book_32_rem_total = int(daily_data['duse_book_32_rem']) if pd.notna(daily_data['duse_book_32_rem']) else 0
            duse_book_code_32_rem_total = int(daily_data['duse_book_code_32_rem']) if pd.notna(daily_data['duse_book_code_32_rem']) else 0
            duse_drawing_book_rem_total = int(daily_data['duse_drawing_book_rem']) if pd.notna(daily_data['duse_drawing_book_rem']) else 0
            duse_book_32_supl_rem_total = int(daily_data['duse_book_32_supl_rem']) if pd.notna(daily_data['duse_book_32_supl_rem']) else 0
            duse_book_code_32_supl_rem_total = int(daily_data['duse_book_code_32_supl_rem']) if pd.notna(daily_data['duse_book_code_32_supl_rem']) else 0
            duse_drawing_book_supl_rem_total = int(daily_data['duse_drawing_book_supl_rem']) if pd.notna(daily_data['duse_drawing_book_supl_rem']) else 0
            duse_book_32_qr_rem_total = int(daily_data['duse_book_32_qr_code_rem']) if pd.notna(daily_data['duse_book_32_qr_code_rem']) else 0
            duse_book_code_32_qr_supl_rem_total = int(daily_data['duse_book_32_qr_supl_rem']) if pd.notna(daily_data['duse_book_32_qr_supl_rem']) else 0
        else:
            d32_issue_ans_book_total = 0
            ddrawing_issue_ans_book_total = 0
            d32_issue_supl_ans_book_total = 0
            ddrawing_issue_suppl_ans_book_total = 0
            d32_qr_issue_ans_book_total = 0
            d32_qr_issue_supl_ans_book_total = 0
            duse_book_32_rem_total = 0
            duse_book_code_32_rem_total = 0
            duse_drawing_book_rem_total = 0
            duse_book_32_supl_rem_total = 0
            duse_book_code_32_supl_rem_total = 0
            duse_drawing_book_supl_rem_total = 0
            duse_book_32_qr_rem_total = 0
            duse_book_code_32_qr_supl_rem_total = 0
        
        # Get opening balances
        book_32_rem = int(stationery_data['book_32_rem']) if pd.notna(stationery_data['book_32_rem']) else 0
        book_code_32_rem = int(stationery_data['book_code_32_rem']) if pd.notna(stationery_data['book_code_32_rem']) else 0
        drawing_book_rem = int(stationery_data['drawing_book_rem']) if pd.notna(stationery_data['drawing_book_rem']) else 0
        book_32_supl_rem = int(stationery_data['book_32_supl_rem']) if pd.notna(stationery_data['book_32_supl_rem']) else 0
        book_code_32_supl_rem = int(stationery_data['book_code_32_supl_rem']) if pd.notna(stationery_data['book_code_32_supl_rem']) else 0
        drawing_book_supl_rem = int(stationery_data['drawing_book_supl_rem']) if pd.notna(stationery_data['drawing_book_supl_rem']) else 0
        book_32_qr_rem = int(stationery_data['book_32_qr_rem']) if pd.notna(stationery_data['book_32_qr_rem']) else 0
        book_code_32_qr_supl_rem = int(stationery_data['book_code_32_qr_supl_rem']) if pd.notna(stationery_data['book_code_32_qr_supl_rem']) else 0
        
        # Calculate remaining balances
        final_total_32_ab = duse_book_32_rem_total
        final_total_32_code_ab = duse_book_code_32_rem_total
        final_total_drawing_ab = duse_drawing_book_rem_total
        final_total_32_suplement_ab = duse_book_32_supl_rem_total
        final_total_32_code_suplement_ab = duse_book_code_32_supl_rem_total
        final_total_drawing_suplement_ab = duse_drawing_book_supl_rem_total
        final_total_32_qr_ab = duse_book_32_qr_rem_total
        final_total_32_qr_code_suplement_ab = duse_book_code_32_qr_supl_rem_total
        
        remaining_balance_32_ab = book_32_rem - final_total_32_ab
        remaining_balance_32_code_ab = book_code_32_rem - final_total_32_code_ab
        remaining_balance_drawing_ab = drawing_book_rem - final_total_drawing_ab
        remaining_balance_32_suplement_ab = book_32_supl_rem - final_total_32_suplement_ab
        remaining_balance_32_code_suplement_ab = book_code_32_supl_rem - final_total_32_code_suplement_ab
        remaining_balance_drawing_suplement_ab = drawing_book_supl_rem - final_total_drawing_suplement_ab
        remaining_balance_32_qr_ab = book_32_qr_rem - final_total_32_qr_ab
        remaining_balance_32_qr_suplement_ab = book_code_32_qr_supl_rem - final_total_32_qr_code_suplement_ab
        
        # Get confirmation status
        conf_query = f"""
            SELECT conf FROM {msbte_config.STATIONERY_DETAILS} 
            WHERE ec_id = %s
        """
        df_conf = pd.read_sql(conf_query, conn, params=[ec_id])
        conf = df_conf.iloc[0]['conf'] if len(df_conf) > 0 and pd.notna(df_conf.iloc[0]['conf']) else 'N'
        
        # Get region name
        region_name = get_region_name(inst_reg) if inst_reg else ''
        
        # Prepare report data
        report_data = [
            {
                'sr_no': 1,
                'stationery_type': '32 Pages (Old Answer Books)',
                'opening_balance': book_32_rem,
                'used_books': duse_book_32_rem_total,
                'remaining_balance': remaining_balance_32_ab,
            },
            {
                'sr_no': 2,
                'stationery_type': '32 Pages Old Supplement Answer Book',
                'opening_balance': book_32_supl_rem,
                'used_books': duse_book_32_supl_rem_total,
                'remaining_balance': remaining_balance_32_suplement_ab,
            },
            {
                'sr_no': 3,
                'stationery_type': 'Drawing Sheet (Main Answer Books)',
                'opening_balance': drawing_book_rem,
                'used_books': duse_drawing_book_rem_total,
                'remaining_balance': remaining_balance_drawing_ab,
            },
            {
                'sr_no': 4,
                'stationery_type': 'Drawing Sheet Supplement Answer Book',
                'opening_balance': drawing_book_supl_rem,
                'used_books': duse_drawing_book_supl_rem_total,
                'remaining_balance': remaining_balance_drawing_suplement_ab,
            },
            {
                'sr_no': 5,
                'stationery_type': '32 Pages Barcode (Main Answer Books)',
                'opening_balance': book_code_32_rem,
                'used_books': duse_book_code_32_rem_total,
                'remaining_balance': remaining_balance_32_code_ab,
            },
            {
                'sr_no': 6,
                'stationery_type': '32 Pages Barcode Supplement Answer Book',
                'opening_balance': book_code_32_supl_rem,
                'used_books': duse_book_code_32_supl_rem_total,
                'remaining_balance': remaining_balance_32_code_suplement_ab,
            },
            {
                'sr_no': 7,
                'stationery_type': '32 Page QR Code Answer Book',
                'opening_balance': book_32_qr_rem,
                'used_books': duse_book_32_qr_rem_total,
                'remaining_balance': remaining_balance_32_qr_ab,
            },
            {
                'sr_no': 8,
                'stationery_type': '32 Page QR Code Supplement Answer Book',
                'opening_balance': book_code_32_qr_supl_rem,
                'used_books': duse_book_code_32_qr_supl_rem_total,
                'remaining_balance': remaining_balance_32_qr_suplement_ab,
            },
        ]
        
        # Determine if showing for different institute (RBTE viewing institute report)
        is_different_inst = (auth.get('role') != 'INSTITUTE' or str(inst_code) != str(auth.get('inst_code', '')))
        
        context = {
            'report_data': report_data,
            'inst_codef': inst_codef,
            'inst_name': inst_name,
            'inst_reg': inst_reg,
            'region_name': region_name,
            'current_exam': current_exam,
            'conf': conf,
            'is_different_inst': is_different_inst,
            'user_name': auth['user_name'],
            'user_role': auth.get('role', 'RBTE'),
            'print_date': datetime.now().strftime('%d/%m/%Y'),
            'report_title': f'Consolidate report of Stationary Details for {current_exam}',
        }
        
        return render(request, 'stat_rbte/rbte_stationary_institute_info.html', context)
        
    except Exception as e:
        logger.exception("Error in rbte_stationary_institute_info")
        return handle_report_error(request, e, auth['is_jwt'])

@jwt_report_authorized(allowed_roles=['RBTE', 'ADMIN'])
def rbte_cancel_stationery_report_institute_info(request):
    """
    Cancelled Stationery Report of Institute - RBTE Level
    
    PHP Reference: rbte_cancelation_stationery_report
    - Shows form to select institute
    - For RBTE: filters institutes by reg_code and conf='Y' in STATIONERY_DETAILS
    - For ADMIN: shows all institutes
    - Joins INSTITUTES with STATIONERY_DETAILS where ec_id = inst_id
    """
    auth, error = get_auth_context(request, require_institute=False)
    if error:
        return error
    
    try:
        conn = get_db_connection()
        
        # Get user ID (reg_code) from token/session
        uid = (
            auth.get('rbte_code')
            or request.session.get('USER_ID')
            or getattr(request, 'jwt_user_id', None)
        )
        
        # Get user role
        user_role = (
            auth.get('role')
            or (request.user.groups.first().name if request.user.is_authenticated and request.user.groups.exists() else None)
            or 'RBTE'
        )
        
        # Check if user is admin
        is_admin = (
            (not auth['is_jwt'] and request.user.is_authenticated and request.user.is_staff)
            or auth.get('role') == 'ADMIN'
        )
        
        logger.info(f"rbte_cancel_stationery_report_institute_info - uid: {uid}, user_role: {user_role}, is_admin: {is_admin}")
        
        # Get institutes for dropdown based on role
        if is_admin:
            # Admin can see all institutes that have stationery details
            institutes_query = f"""
                SELECT DISTINCT a.inst_id, a.inst_name 
                FROM {msbte_config.INSTITUTES} a
                INNER JOIN {msbte_config.STATIONERY_DETAILS} b ON b.ec_id = a.inst_id
                ORDER BY a.inst_id
            """
            df_institutes = pd.read_sql(institutes_query, conn)
        else:
            # RBTE: use uid (reg_code) directly and filter by conf='Y'
            if not uid:
                messages.error(request, 'Unable to determine RBTE code. Please contact administrator.')
                context = {
                    'institutes': [],
                    'selected_inst': '0',
                    'user_name': auth['user_name'],
                    'print_date': datetime.now().strftime('%d/%m/%Y'),
                    'report_title': 'Cancelled Stationery Report',
                }
                return render(request, 'stat_rbte/rbte_cancel_stationery_report_institute_info.html', context)
            
            try:
                reg_code_int = int(float(str(uid).strip()))
            except (ValueError, TypeError):
                messages.error(request, 'Invalid RBTE Code')
                context = {
                    'institutes': [],
                    'selected_inst': '0',
                    'user_name': auth['user_name'],
                    'print_date': datetime.now().strftime('%d/%m/%Y'),
                    'report_title': 'Cancelled Stationery Report',
                }
                return render(request, 'stat_rbte/rbte_cancel_stationery_report_institute_info.html', context)
            
            # Query institutes with stationery details for this reg_code AND conf='Y'
            institutes_query = f"""
                SELECT DISTINCT a.inst_id, a.inst_name 
                FROM {msbte_config.INSTITUTES} a
                INNER JOIN {msbte_config.STATIONERY_DETAILS} b ON b.ec_id = a.inst_id
                WHERE a.reg_code = %s AND b.conf = 'Y'
                ORDER BY a.inst_id
            """
            df_institutes = pd.read_sql(institutes_query, conn, params=[reg_code_int])
        
        institutes = df_institutes.to_dict('records') if len(df_institutes) > 0 else []
        
        if request.method == 'POST':
            selected_inst = request.POST.get('instid', '0')
            
            # Validate institute selection
            if selected_inst == '0' or not selected_inst:
                messages.error(request, 'Please select an Institute.')
                context = {
                    'institutes': institutes,
                    'selected_inst': selected_inst,
                    'user_name': auth['user_name'],
                    'print_date': datetime.now().strftime('%d/%m/%Y'),
                    'report_title': 'Cancelled Stationery Report',
                }
                return render(request, 'stat_rbte/rbte_cancel_stationery_report_institute_info.html', context)
            # Redirect to cancellation report page (to be created separately if needed)
            # For now, redirect to the institute-level cancellation report
            return redirect(reverse('dashboard:stationary:stat_rbte:rbte_cancelation_stationery_report') + f'?instid={selected_inst}')
        else:
            # GET request - show form
            context = {
                'institutes': institutes,
                'selected_inst': '0',
                'user_name': auth['user_name'],
                'print_date': datetime.now().strftime('%d/%m/%Y'),
                'report_title': 'Cancelled Stationery Report',
            }
            return render(request, 'stat_rbte/rbte_cancel_stationery_report_institute_info.html', context)
        
    except Exception as e:
        logger.exception("Error in rbte_cancel_stationery_report_institute_info")
        return handle_report_error(request, e, auth['is_jwt'])
 
        

@jwt_report_authorized(allowed_roles=['RBTE', 'ADMIN'])
def rbte_cancelation_stationery_report(request):
    """
    Consolidate report of Cancelled Stationery Details for Institute - RBTE Level
    
    PHP Reference: rbte_cancelation_stationery_report
    - Shows summary of cancelled stationery grouped by exam_day
    - Gets counts from CANCEL_DAILY_STATIONERY_AB grouped by exam_day
    - Shows institute code, name, and region
    """
    auth, error = get_auth_context(request, require_institute=False)
    if error:
        return error
    
    try:
        conn = get_db_connection()
        
        # Get institute code from request
        inst_code_param = request.GET.get('instid') or request.POST.get('instid')
        
        if not inst_code_param or inst_code_param == '0':
            messages.error(request, 'Please select an Institute.')
            return redirect('dashboard:stationary:stat_rbte:rbte_cancel_stationery_report_institute_info')
        
        try:
            inst_code = int(float(str(inst_code_param).lstrip('0')))
        except (ValueError, TypeError):
            messages.error(request, 'Invalid Institute Code')
            return redirect('dashboard:stationary:stat_rbte:rbte_cancel_stationery_report_institute_info')
        
        # Get institute details
        inst_query = f"""
            SELECT inst_id, inst_name, reg_code 
            FROM {msbte_config.INSTITUTES} 
            WHERE inst_id = %s
        """
        df_inst = pd.read_sql(inst_query, conn, params=[inst_code])
        
        if len(df_inst) == 0:
            messages.error(request, 'Institute not found.')
            return redirect('dashboard:stationary:stat_rbte:rbte_cancel_stationery_report_institute_info')
        
        inst_data = df_inst.iloc[0]
        inst_codef = inst_data['inst_id']
        inst_name = get_inst_name(inst_codef)
        inst_reg = int(inst_data['reg_code']) if pd.notna(inst_data['reg_code']) else None
        
        # Get current exam name
        current_exam = getattr(msbte_config, 'ACA_NAME_EXAM_W', getattr(msbte_config, 'CURRENT_EXAM', msbte_config.EXAM_CODE))
        
        # Query: Get cancelled stationery counts grouped by exam_day
        ec_id = inst_code
        summary_query = f"""
            SELECT 
                exam_day,
                COUNT(*) AS cnt
            FROM {msbte_config.CANCEL_DAILY_STATIONERY_AB}
            WHERE ec_id = %s
            GROUP BY exam_day
            ORDER BY FIELD(exam_day,
                'Day1_Morning', 'Day1_Afternoon',
                'Day2_Morning', 'Day2_Afternoon',
                'Day3_Morning', 'Day3_Afternoon',
                'Day4_Morning', 'Day4_Afternoon',
                'Day5_Morning', 'Day5_Afternoon',
                'Day6_Morning', 'Day6_Afternoon',
                'Day7_Morning', 'Day7_Afternoon',
                'Day8_Morning', 'Day8_Afternoon',
                'Day9_Morning', 'Day9_Afternoon',
                'Day10_Morning', 'Day10_Afternoon',
                'Day11_Morning', 'Day11_Afternoon',
                'Day12_Morning', 'Day12_Afternoon',
                'Day13_Morning', 'Day13_Afternoon',
                'Day14_Morning', 'Day14_Afternoon',
                'Day15_Morning', 'Day15_Afternoon',
                'Day16_Morning', 'Day16_Afternoon',
                'Day17_Morning', 'Day17_Afternoon',
                'Day18_Morning', 'Day18_Afternoon'
            )
        """
        df_summary = pd.read_sql(summary_query, conn, params=[ec_id])
        
        # Process summary data
        summary_data = []
        count = 0
        for idx, row in df_summary.iterrows():
            exam_day = row['exam_day'] if pd.notna(row['exam_day']) else ''
            total_count = int(row['cnt']) if pd.notna(row['cnt']) else 0
            
            count += 1
            summary_data.append({
                'sr_no': count,
                'exam_day': exam_day,
                'total_count': total_count,
            })
        
        if len(summary_data) == 0:
            messages.info(request, 'No cancelled stationery records found for this institute.')
            return redirect('dashboard:stationary:stat_rbte:rbte_cancel_stationery_report_institute_info')
        
        # Get region name
        region_name = get_region_name(inst_reg) if inst_reg else ''
        
        # Determine if showing for different institute (RBTE viewing institute report)
        is_different_inst = (auth.get('role') != 'INSTITUTE' or str(inst_code) != str(auth.get('inst_code', '')))
        
        context = {
            'summary_data': summary_data,
            'inst_codef': inst_codef,
            'inst_name': inst_name,
            'inst_reg': inst_reg,
            'region_name': region_name,
            'current_exam': current_exam,
            'is_different_inst': is_different_inst,
            'user_name': auth['user_name'],
            'user_role': auth.get('role', 'RBTE'),
            'print_date': datetime.now().strftime('%d/%m/%Y'),
            'report_title': f'Consolidate report of {current_exam} Examination Stationary Details for {current_exam}',
        }
        
        return render(request, 'stat_rbte/rbte_cancelation_stationery_report.html', context)
        
    except Exception as e:
        logger.exception("Error in rbte_cancelation_stationery_report")
        return handle_report_error(request, e, auth['is_jwt'])

@jwt_report_authorized(allowed_roles=['RBTE', 'ADMIN'])
def stationery_wise_reports(request):
    """
    Institute Stationery wise Report Menu - RBTE Level
    
    PHP Reference: rbte_stationary_institute_info (menu page)
    - Shows menu/list of different stationery report links
    - Links to various institute-level stationery reports
    """
    auth, error = get_auth_context(request, require_institute=False)
    if error:
        return error
    
    try:
        # Prepare report links data
        report_links = [
            {
                'sr_no': 1,
                'title': '32 Pages Old Answer Book Report',
                'url': reverse('dashboard:stationary:stat_rbte:stationery_wise_32'),
                'description': 'Stationery Report'
            },
            {
                'sr_no': 2,
                'title': '32 Page Old Suppliment Answer Book Report',
                'url': reverse('dashboard:stationary:stat_rbte:stationery_wise_32_supliment'),
                'description': 'Stationery Report'
            },
            {
                'sr_no': 3,
                'title': 'Drawing Pages Main Answer Book Report',
                'url': reverse('dashboard:stationary:stat_rbte:stationery_wise_drawing'),
                'description': 'Stationery Report'
            },
            {
                'sr_no': 4,
                'title': 'Drawing Suppliment Pages Answer Book Report',
                'url': reverse('dashboard:stationary:stat_rbte:stationery_wise_drawing_supliment'),
                'description': 'Stationery Report'
            },
            {
                'sr_no': 5,
                'title': '32 Barcode Answer Book Report',
                'url': reverse('dashboard:stationary:stat_rbte:stationery_wise_32_barcode'),
                'description': 'Stationery Report'
            },
            {
                'sr_no': 6,
                'title': '32 Barcode Suppliment Answer Book Report',
                'url': reverse('dashboard:stationary:stat_rbte:stationery_wise_32_barcode_supliment'),
                'description': 'Stationery Report'
            },
            {
                'sr_no': 7,
                'title': '32 QR Code Answer Book Report',
                'url': reverse('dashboard:stationary:stat_rbte:stationery_wise_32_qrcode'),
                'description': 'Stationery Report'
            },
            {
                'sr_no': 8,
                'title': '32 QR Code Suppliment Answer Book Report',
                'url': reverse('dashboard:stationary:stat_rbte:stationery_wise_32_qrcode_supliment'),
                'description': 'Stationery Report'
            },
        ]
        
        context = {
            'report_links': report_links,
            'user_name': auth['user_name'],
            'print_date': datetime.now().strftime('%d/%m/%Y'),
            'report_title': 'Institute Stationery wise Report',
        }
        
        return render(request, 'stat_rbte/stationery_wise_reports.html', context)
        
    except Exception as e:
        logger.exception("Error in stationery_wise_reports")
        return handle_report_error(request, e, auth['is_jwt'])

@jwt_report_authorized(allowed_roles=['RBTE', 'ADMIN'])
def stationery_wise_32(request):
    """
    32 Pages Old Answer Book Report - RBTE Level
    
    PHP Reference: report_32_stationary (RBTE version)
    - Shows report of 32 page old answer books for all institutes under RBTE
    - Gets opening balance from STATIONERY_DETAILS
    - Gets used books (summed) from DAILY_STATIONERY_DETAILS
    - Calculates remaining balance = opening - used
    - Shows confirmation status
    """
    auth, error = get_auth_context(request, require_institute=False)
    if error:
        return error
    
    try:
        conn = get_db_connection()
        
        # Get user ID (reg_code) from token/session
        uid = (
            auth.get('rbte_code')
            or request.session.get('USER_ID')
            or getattr(request, 'jwt_user_id', None)
        )
        
        # Get user role
        user_role = (
            auth.get('role')
            or (request.user.groups.first().name if request.user.is_authenticated and request.user.groups.exists() else None)
            or 'RBTE'
        )
        
        # Check if user is admin
        is_admin = (
            (not auth['is_jwt'] and request.user.is_authenticated and request.user.is_staff)
            or auth.get('role') == 'ADMIN'
        )
        
        logger.info(f"stationery_wise_32 - uid: {uid}, user_role: {user_role}, is_admin: {is_admin}")
        
        current_exam = getattr(msbte_config, 'ACA_NAME_EXAM_W', getattr(msbte_config, 'CURRENT_EXAM', msbte_config.EXAM_CODE))
        
        # Build query based on role
        if is_admin:
            # Admin can see all institutes
            query = f"""
                SELECT 
                    a.ec_id,
                    a.book_32_rem,
                    a.conf,
                    COALESCE(SUM(b.duse_book_32_rem), 0) as sum_32_pages
                FROM {msbte_config.STATIONERY_DETAILS} a
                LEFT JOIN {msbte_config.W25_DAILY_STATIONERY_DETAILS} b ON a.ec_id = b.dec_id
                GROUP BY a.ec_id, a.book_32_rem, a.conf
                ORDER BY a.ec_id ASC
            """
            df_result = pd.read_sql(query, conn)
        else:
            # RBTE only
            dist_regcode_param, err = _resolve_dist_regcode_stationery(
                request, auth, uid, conn,
                'stat_rbte/stationery_wise_32.html',
                '32 Pages Old Answer Book Report',
                current_exam,
            )
            if err is not None:
                return err
            query = f"""
                SELECT a.ec_id, a.book_32_rem, a.conf, SUM(b.duse_book_32_rem) as sum_32_pages
                FROM {msbte_config.STATIONERY_DETAILS} a
                INNER JOIN {msbte_config.W25_DAILY_STATIONERY_DETAILS} b ON a.ec_id = b.dec_id
                WHERE a.dist_regcode = %s
                GROUP BY b.dec_id
                ORDER BY a.ec_id ASC
            """
            df_result = pd.read_sql(query, conn, params=[dist_regcode_param])
        # Process report data
        report_data = []
        i = 0
        for idx, row in df_result.iterrows():
            ec_id = row['ec_id']
            book_32_rem = safe_int_stationery(row.get('book_32_rem'))
            conf = row['conf'] if pd.notna(row['conf']) else 'N'
            sum_32_pages = safe_int_stationery(row.get('sum_32_pages'))
            
            if conf == 'Y':
                conf_y = 'Confirmed'
            else:
                conf_y = 'Not Confirmed'
            
            # Calculate remaining balance
            total_remaining = book_32_rem - sum_32_pages
            
            i += 1
            report_data.append({
                'sr_no': i,
                'ec_id': ec_id,
                'book_32_rem': book_32_rem,
                'sum_32_pages': sum_32_pages,
                'total_remaining': total_remaining,
                'conf_y': conf_y,
            })
        
        
        context = {
            'report_data': report_data,
            'current_exam': current_exam,
            'user_name': auth['user_name'],
            'user_role': auth.get('role', 'RBTE'),
            'print_date': datetime.now().strftime('%d/%m/%Y'),
            'report_title': '32 Pages Old Answer Book Report',
        }
        
        return render(request, 'stat_rbte/stationery_wise_32.html', context)
        
    except Exception as e:
        logger.exception("Error in stationery_wise_32")
        return handle_report_error(request, e, auth['is_jwt'])

@jwt_report_authorized(allowed_roles=['RBTE', 'ADMIN'])
def stationery_wise_32_supliment(request):
    """
    32 Pages Old Supplement Answer Book Report - RBTE Level
    
    PHP Reference: report_32_supli_stationery (RBTE version)
    - Shows report of 32 page old supplement answer books for all institutes under RBTE
    - Gets opening balance from STATIONERY_DETAILS (book_32_supl_rem)
    - Gets used books (summed) from DAILY_STATIONERY_DETAILS (duse_book_32_supl_rem)
    - Calculates remaining balance = opening - used
    - Shows confirmation status
    """
    auth, error = get_auth_context(request, require_institute=False)
    if error:
        return error
    
    try:
        conn = get_db_connection()
        
        # Get user ID (reg_code) from token/session
        uid = (
            auth.get('rbte_code')
            or request.session.get('USER_ID')
            or getattr(request, 'jwt_user_id', None)
        )
        
        # Get user role
        user_role = (
            auth.get('role')
            or (request.user.groups.first().name if request.user.is_authenticated and request.user.groups.exists() else None)
            or 'RBTE'
        )
        
        # Check if user is admin
        is_admin = (
            (not auth['is_jwt'] and request.user.is_authenticated and request.user.is_staff)
            or auth.get('role') == 'ADMIN'
        )
        
        logger.info(f"stationery_wise_32_supliment - uid: {uid}, user_role: {user_role}, is_admin: {is_admin}")
        
        current_exam = getattr(msbte_config, 'ACA_NAME_EXAM_W', getattr(msbte_config, 'CURRENT_EXAM', msbte_config.EXAM_CODE))
        
        # Build query based on role
        if is_admin:
            # Admin can see all institutes
            query = f"""
                SELECT 
                    a.ec_id,
                    a.book_32_supl_rem,
                    a.conf,
                    COALESCE(SUM(b.duse_book_32_supl_rem), 0) as sum_32_supl_pages
                FROM {msbte_config.STATIONERY_DETAILS} a
                LEFT JOIN {msbte_config.W25_DAILY_STATIONERY_DETAILS} b ON a.ec_id = b.dec_id
                GROUP BY a.ec_id, a.book_32_supl_rem, a.conf
                ORDER BY a.ec_id ASC
            """
            df_result = pd.read_sql(query, conn)
        
        else:
            # RBTE only
            dist_regcode_param, err = _resolve_dist_regcode_stationery(
                request, auth, uid, conn,
                'stat_rbte/stationery_wise_32_supliment.html',
                '32 Pages Old Supplement Answer Book Report',
                current_exam,
            )
            if err is not None:
                return err  
            query = f"""
                SELECT a.ec_id, a.book_32_supl_rem, a.conf, SUM(b.duse_book_32_supl_rem) as sum_32_supl_pages
                FROM {msbte_config.STATIONERY_DETAILS} a
                INNER JOIN {msbte_config.W25_DAILY_STATIONERY_DETAILS} b ON a.ec_id = b.dec_id
                WHERE a.dist_regcode = %s
                GROUP BY b.dec_id
                ORDER BY a.ec_id ASC
            """
            df_result = pd.read_sql(query, conn, params=[dist_regcode_param])
        # Process report data
        report_data = []
        i = 0
        for idx, row in df_result.iterrows():
            ec_id = row['ec_id']
            book_32_supl_rem = safe_int_stationery(row.get('book_32_supl_rem'))
            conf = row['conf'] if pd.notna(row['conf']) else 'N'
            sum_32_supl_pages = safe_int_stationery(row.get('sum_32_supl_pages'))
            if conf == 'Y':
                conf_y = 'Confirmed'
            else:
                conf_y = 'Not Confirmed'
            total_remaining = book_32_supl_rem - sum_32_supl_pages
            i += 1
            report_data.append({
                'sr_no': i,
                'ec_id': ec_id,
                'book_32_supl_rem': book_32_supl_rem,
                'sum_32_supl_pages': sum_32_supl_pages,
                'total_remaining': total_remaining,
                'conf_y': conf_y,
            })
        context = {
            'report_data': report_data,
            'current_exam': current_exam,
            'user_name': auth['user_name'],
            'user_role': auth.get('role', 'RBTE'),
            'print_date': datetime.now().strftime('%d/%m/%Y'),
            'report_title': '32 Pages Old Supplement Answer Book Report',
        }
        
        return render(request, 'stat_rbte/stationery_wise_32_supliment.html', context)
        
    except Exception as e:
        logger.exception("Error in stationery_wise_32_supliment")
        return handle_report_error(request, e, auth['is_jwt'])


@jwt_report_authorized(allowed_roles=['RBTE', 'ADMIN'])
def stationery_wise_drawing(request):
    """
    Drawing Sheet Pages Report - RBTE Level

    PHP Reference: report_drawing_stationary (RBTE version)
    - Uses a.dist_regcode = ? (uid) and INNER JOIN with DAILY_STATIONERY_DETAILS
    - GROUP BY b.dec_id, no INSTITUTES join
    - Admin and RBTE only (no SUBRBTE).
    """
    auth, error = get_auth_context(request, require_institute=False)
    if error:
        return error

    try:
        conn = get_db_connection()

        uid = (
            auth.get('rbte_code')
            or request.session.get('USER_ID')
            or getattr(request, 'jwt_user_id', None)
        )

        is_admin = (
            (not auth['is_jwt'] and request.user.is_authenticated and request.user.is_staff)
            or auth.get('role') == 'ADMIN'
        )

        logger.info(f"stationery_wise_drawing - uid: {uid}, is_admin: {is_admin}")

        current_exam = getattr(msbte_config, 'ACA_NAME_EXAM_W', getattr(msbte_config, 'CURRENT_EXAM', msbte_config.EXAM_CODE))

        if is_admin:
            query = f"""
                SELECT
                    a.ec_id,
                    a.drawing_book_rem,
                    a.conf,
                    COALESCE(SUM(b.duse_drawing_book_rem), 0) as sum_drawing_pages
                FROM {msbte_config.STATIONERY_DETAILS} a
                LEFT JOIN {msbte_config.W25_DAILY_STATIONERY_DETAILS} b ON a.ec_id = b.dec_id
                GROUP BY a.ec_id, a.drawing_book_rem, a.conf
                ORDER BY a.ec_id ASC
            """
            df_result = pd.read_sql(query, conn)
        else:
            dist_regcode_param, err = _resolve_dist_regcode_stationery(
                request, auth, uid, conn,
                'stat_rbte/stationery_wise_drawing.html',
                'Drawing Sheet Pages Report',
                current_exam,
            )
            if err is not None:
                return err
            query = f"""
                SELECT
                    a.ec_id,
                    a.drawing_book_rem,
                    a.conf,
                    SUM(b.duse_drawing_book_rem) as sum_drawing_pages
                FROM {msbte_config.STATIONERY_DETAILS} a
                INNER JOIN {msbte_config.W25_DAILY_STATIONERY_DETAILS} b ON a.ec_id = b.dec_id
                WHERE a.dist_regcode = %s
                GROUP BY b.dec_id
                ORDER BY a.ec_id ASC
            """
            df_result = pd.read_sql(query, conn, params=[dist_regcode_param])

        report_data = []
        i = 0
        for idx, row in df_result.iterrows():
            ec_id = row['ec_id']
            drawing_book_rem = safe_int_stationery(row.get('drawing_book_rem'))
            conf = row['conf'] if pd.notna(row['conf']) else 'N'
            sum_drawing_pages = safe_int_stationery(row.get('sum_drawing_pages'))

            conf_y = 'Confirmed' if conf == 'Y' else 'Not Confirmed'
            total_remaining = drawing_book_rem - sum_drawing_pages

            i += 1
            report_data.append({
                'sr_no': i,
                'ec_id': ec_id,
                'drawing_book_rem': drawing_book_rem,
                'sum_drawing_pages': sum_drawing_pages,
                'total_remaining': total_remaining,
                'conf_y': conf_y,
            })

        context = {
            'report_data': report_data,
            'current_exam': current_exam,
            'user_name': auth['user_name'],
            'user_role': auth.get('role', 'RBTE'),
            'print_date': datetime.now().strftime('%d/%m/%Y'),
            'report_title': 'Drawing Sheet Pages Report',
        }

        return render(request, 'stat_rbte/stationery_wise_drawing.html', context)

    except Exception as e:
        logger.exception("Error in stationery_wise_drawing")
        return handle_report_error(request, e, auth['is_jwt'])

@jwt_report_authorized(allowed_roles=['RBTE', 'ADMIN'])
def stationery_wise_drawing_supliment(request):
    """
    Drawing Supplement Sheet Pages Report - RBTE Level (Admin and RBTE only).
    PHP Reference: report_drawing_supli_stationery - a.dist_regcode, INNER JOIN, GROUP BY b.dec_id.
    """
    auth, error = get_auth_context(request, require_institute=False)
    if error:
        return error
    
    try:
        conn = get_db_connection()
        uid = (
            auth.get('rbte_code')
            or request.session.get('USER_ID')
            or getattr(request, 'jwt_user_id', None)
        )
        is_admin = (
            (not auth['is_jwt'] and request.user.is_authenticated and request.user.is_staff)
            or auth.get('role') == 'ADMIN'
        )
        logger.info(f"stationery_wise_drawing_supliment - uid: {uid}, is_admin: {is_admin}")
        current_exam = getattr(msbte_config, 'ACA_NAME_EXAM_W', getattr(msbte_config, 'CURRENT_EXAM', msbte_config.EXAM_CODE))
        
        if is_admin:
            query = f"""
                SELECT 
                    a.ec_id,
                    a.drawing_book_supl_rem,
                    a.conf,
                    COALESCE(SUM(b.duse_drawing_book_supl_rem), 0) as sum_drawing_pages_supl
                FROM {msbte_config.STATIONERY_DETAILS} a
                LEFT JOIN {msbte_config.W25_DAILY_STATIONERY_DETAILS} b ON a.ec_id = b.dec_id
                GROUP BY a.ec_id, a.drawing_book_supl_rem, a.conf
                ORDER BY a.ec_id ASC
            """
            df_result = pd.read_sql(query, conn)
        else:
            dist_regcode_param, err = _resolve_dist_regcode_stationery(
                request, auth, uid, conn,
                'stat_rbte/stationery_wise_drawing_supliment.html',
                'Drawing Supplement Sheet Pages Report',
                current_exam,
            )
            if err is not None:
                return err
            query = f"""
                SELECT a.ec_id, a.drawing_book_supl_rem, a.conf, SUM(b.duse_drawing_book_supl_rem) as sum_drawing_pages_supl
                FROM {msbte_config.STATIONERY_DETAILS} a
                INNER JOIN {msbte_config.W25_DAILY_STATIONERY_DETAILS} b ON a.ec_id = b.dec_id
                WHERE a.dist_regcode = %s
                GROUP BY b.dec_id
                ORDER BY a.ec_id ASC
            """
            df_result = pd.read_sql(query, conn, params=[dist_regcode_param])
        
        report_data = []
        i = 0
        for idx, row in df_result.iterrows():
            ec_id = row['ec_id']
            drawing_book_supl_rem = safe_int_stationery(row.get('drawing_book_supl_rem'))
            conf = row['conf'] if pd.notna(row['conf']) else 'N'
            sum_drawing_pages_supl = safe_int_stationery(row.get('sum_drawing_pages_supl'))
            if conf == 'Y':
                conf_y = 'Confirmed'
            else:
                conf_y = 'Not Confirmed'
            total_remaining = drawing_book_supl_rem - sum_drawing_pages_supl
            i += 1
            report_data.append({
                'sr_no': i,
                'ec_id': ec_id,
                'drawing_book_supl_rem': drawing_book_supl_rem,
                'sum_drawing_pages_supl': sum_drawing_pages_supl,
                'total_remaining': total_remaining,
                'conf_y': conf_y,
            })
        
        context = {
            'report_data': report_data,
            'current_exam': current_exam,
            'user_name': auth['user_name'],
            'user_role': auth.get('role', 'RBTE'),
            'print_date': datetime.now().strftime('%d/%m/%Y'),
            'report_title': 'Drawing Supplement Sheet Pages Report',
        }
        
        return render(request, 'stat_rbte/stationery_wise_drawing_supliment.html', context)
        
    except Exception as e:
        logger.exception("Error in stationery_wise_drawing_supliment")
        return handle_report_error(request, e, auth['is_jwt'])

@jwt_report_authorized(allowed_roles=['RBTE', 'ADMIN'])
def stationery_wise_32_barcode(request):
    """
    32 Pages Barcode Answer Book Report - RBTE Level
    
    PHP Reference: report_32_barcode_stationery (RBTE version)
    - Shows report of 32 page barcode answer books for all institutes under RBTE
    - Gets opening balance from STATIONERY_DETAILS (book_code_32_rem)
    - Gets used books (summed) from DAILY_STATIONERY_DETAILS (duse_book_code_32_rem)
    - Calculates remaining balance = opening - used
    - Shows confirmation status
    """
    auth, error = get_auth_context(request, require_institute=False)
    if error:
        return error
    
    try:
        conn = get_db_connection()
        
        # Get user ID (reg_code) from token/session
        uid = (
            auth.get('rbte_code')
            or request.session.get('USER_ID')
            or getattr(request, 'jwt_user_id', None)
        )
        
        # Get user role
        user_role = (
            auth.get('role')
            or (request.user.groups.first().name if request.user.is_authenticated and request.user.groups.exists() else None)
            or 'RBTE'
        )
        
        # Check if user is admin
        is_admin = (
            (not auth['is_jwt'] and request.user.is_authenticated and request.user.is_staff)
            or auth.get('role') == 'ADMIN'
        )
        
        logger.info(f"stationery_wise_32_barcode - uid: {uid}, user_role: {user_role}, is_admin: {is_admin}")
        current_exam = getattr(msbte_config, 'ACA_NAME_EXAM_W', getattr(msbte_config, 'CURRENT_EXAM', msbte_config.EXAM_CODE))
        
        if is_admin:
            query = f"""
                SELECT 
                    a.ec_id,
                    a.book_code_32_rem,
                    a.conf,
                    COALESCE(SUM(b.duse_book_code_32_rem), 0) as sum_32_pages
                FROM {msbte_config.STATIONERY_DETAILS} a
                LEFT JOIN {msbte_config.W25_DAILY_STATIONERY_DETAILS} b ON a.ec_id = b.dec_id
                GROUP BY a.ec_id, a.book_code_32_rem, a.conf
                ORDER BY a.ec_id ASC
            """
            df_result = pd.read_sql(query, conn)
        else:
            dist_regcode_param, err = _resolve_dist_regcode_stationery(
                request, auth, uid, conn,
                'stat_rbte/stationery_wise_32_barcode.html',
                '32 Pages Barcode Answer Book Report',
                current_exam,
            )
            if err is not None:
                return err
            query = f"""
                SELECT a.ec_id, a.book_code_32_rem, a.conf, SUM(b.duse_book_code_32_rem) as sum_32_pages
                FROM {msbte_config.STATIONERY_DETAILS} a
                INNER JOIN {msbte_config.W25_DAILY_STATIONERY_DETAILS} b ON a.ec_id = b.dec_id
                WHERE a.dist_regcode = %s
                GROUP BY b.dec_id
                ORDER BY a.ec_id ASC
            """
            df_result = pd.read_sql(query, conn, params=[dist_regcode_param])
        
        report_data = []
        i = 0
        for idx, row in df_result.iterrows():
            ec_id = row['ec_id']
            book_code_32_rem = safe_int_stationery(row.get('book_code_32_rem'))
            conf = row['conf'] if pd.notna(row['conf']) else 'N'
            sum_32_pages = safe_int_stationery(row.get('sum_32_pages'))
            if conf == 'Y':
                conf_y = 'Confirmed'
            else:
                conf_y = 'Not Confirmed'
            total_remaining = book_code_32_rem - sum_32_pages
            i += 1
            report_data.append({
                'sr_no': i,
                'ec_id': ec_id,
                'book_code_32_rem': book_code_32_rem,
                'sum_32_pages': sum_32_pages,
                'total_remaining': total_remaining,
                'conf_y': conf_y,
            })
        
        context = {
            'report_data': report_data,
            'current_exam': current_exam,
            'user_name': auth['user_name'],
            'user_role': auth.get('role', 'RBTE'),
            'print_date': datetime.now().strftime('%d/%m/%Y'),
            'report_title': '32 Pages Barcode Answer Book Report',
        }
        
        return render(request, 'stat_rbte/stationery_wise_32_barcode.html', context)
        
    except Exception as e:
        logger.exception("Error in stationery_wise_32_barcode")
        return handle_report_error(request, e, auth['is_jwt'])

@jwt_report_authorized(allowed_roles=['RBTE', 'ADMIN'])
def stationery_wise_32_barcode_supliment(request):
    """
    32 Pages Barcode Supplement Answer Book Report - RBTE Level
    
    PHP Reference: report_32_barcode_supli_stationery (RBTE version)
    - Shows report of 32 page barcode supplement answer books for all institutes under RBTE
    - Gets opening balance from STATIONERY_DETAILS (book_code_32_supl_rem)
    - Gets used books (summed) from DAILY_STATIONERY_DETAILS (duse_book_code_32_supl_rem)
    - Calculates remaining balance = opening - used
    - Shows confirmation status
    """
    auth, error = get_auth_context(request, require_institute=False)
    if error:
        return error
    
    try:
        conn = get_db_connection()
        
        # Get user ID (reg_code) from token/session
        uid = (
            auth.get('rbte_code')
            or request.session.get('USER_ID')
            or getattr(request, 'jwt_user_id', None)
        )
        
        # Get user role
        user_role = (
            auth.get('role')
            or (request.user.groups.first().name if request.user.is_authenticated and request.user.groups.exists() else None)
            or 'RBTE'
        )
        
        # Check if user is admin
        is_admin = (
            (not auth['is_jwt'] and request.user.is_authenticated and request.user.is_staff)
            or auth.get('role') == 'ADMIN'
        )
        
        logger.info(f"stationery_wise_32_barcode_supliment - uid: {uid}, user_role: {user_role}, is_admin: {is_admin}")
        current_exam = getattr(msbte_config, 'ACA_NAME_EXAM_W', getattr(msbte_config, 'CURRENT_EXAM', msbte_config.EXAM_CODE))
        
        if is_admin:
            query = f"""
                SELECT 
                    a.ec_id,
                    a.book_code_32_supl_rem,
                    a.conf,
                    COALESCE(SUM(b.duse_book_code_32_supl_rem), 0) as sum_32_pages
                FROM {msbte_config.STATIONERY_DETAILS} a
                LEFT JOIN {msbte_config.W25_DAILY_STATIONERY_DETAILS} b ON a.ec_id = b.dec_id
                GROUP BY a.ec_id, a.book_code_32_supl_rem, a.conf
                ORDER BY a.ec_id ASC
            """
            df_result = pd.read_sql(query, conn)
        else:
            dist_regcode_param, err = _resolve_dist_regcode_stationery(
                request, auth, uid, conn,
                'stat_rbte/stationery_wise_32_barcode_supliment.html',
                '32 Pages Barcode Supplement Answer Book Report',
                current_exam,
            )
            if err is not None:
                return err
            query = f"""
                SELECT a.ec_id, a.book_code_32_supl_rem, a.conf, SUM(b.duse_book_code_32_supl_rem) as sum_32_pages
                FROM {msbte_config.STATIONERY_DETAILS} a
                INNER JOIN {msbte_config.W25_DAILY_STATIONERY_DETAILS} b ON a.ec_id = b.dec_id
                WHERE a.dist_regcode = %s
                GROUP BY b.dec_id
                ORDER BY a.ec_id ASC
            """
            df_result = pd.read_sql(query, conn, params=[dist_regcode_param])
        
        report_data = []
        i = 0
        for idx, row in df_result.iterrows():
            ec_id = row['ec_id']
            book_code_32_supl_rem = safe_int_stationery(row.get('book_code_32_supl_rem'))
            conf = row['conf'] if pd.notna(row['conf']) else 'N'
            sum_32_pages = safe_int_stationery(row.get('sum_32_pages'))
            if conf == 'Y':
                conf_y = 'Confirmed'
            else:
                conf_y = 'Not Confirmed'
            total_remaining = book_code_32_supl_rem - sum_32_pages
            i += 1
            report_data.append({
                'sr_no': i,
                'ec_id': ec_id,
                'book_code_32_supl_rem': book_code_32_supl_rem,
                'sum_32_pages': sum_32_pages,
                'total_remaining': total_remaining,
                'conf_y': conf_y,
            })
        
        context = {
            'report_data': report_data,
            'current_exam': current_exam,
            'user_name': auth['user_name'],
            'user_role': auth.get('role', 'RBTE'),
            'print_date': datetime.now().strftime('%d/%m/%Y'),
            'report_title': '32 Pages Barcode Supplement Answer Book Report',
        }
        
        return render(request, 'stat_rbte/stationery_wise_32_barcode_supliment.html', context)
        
    except Exception as e:
        logger.exception("Error in stationery_wise_32_barcode_supliment")
        return handle_report_error(request, e, auth['is_jwt'])


@jwt_report_authorized(allowed_roles=['RBTE', 'ADMIN'])
def stationery_wise_32_qrcode(request):
    """
    32 Pages QR Code Answer Book Report - RBTE Level
    
    PHP Reference: report_32_qrcode_stationery (RBTE version)
    - Shows report of 32 page QR code answer books for all institutes under RBTE
    - Gets opening balance from STATIONERY_DETAILS (book_32_qr_rem)
    - Gets used books (summed) from DAILY_STATIONERY_DETAILS (duse_book_32_qr_code_rem)
    - Calculates remaining balance = opening - used
    - Shows confirmation status
    """
    auth, error = get_auth_context(request, require_institute=False)
    if error:
        return error
    
    try:
        conn = get_db_connection()
        
        # Get user ID (reg_code) from token/session
        uid = (
            auth.get('rbte_code')
            or request.session.get('USER_ID')
            or getattr(request, 'jwt_user_id', None)
        )
        
        # Get user role
        user_role = (
            auth.get('role')
            or (request.user.groups.first().name if request.user.is_authenticated and request.user.groups.exists() else None)
            or 'RBTE'
        )
        
        # Check if user is admin
        is_admin = (
            (not auth['is_jwt'] and request.user.is_authenticated and request.user.is_staff)
            or auth.get('role') == 'ADMIN'
        )
        
        logger.info(f"stationery_wise_32_qrcode - uid: {uid}, user_role: {user_role}, is_admin: {is_admin}")
        current_exam = getattr(msbte_config, 'ACA_NAME_EXAM_W', getattr(msbte_config, 'CURRENT_EXAM', msbte_config.EXAM_CODE))
        
        if is_admin:
            query = f"""
                SELECT 
                    a.ec_id,
                    a.book_32_qr_rem,
                    a.conf,
                    COALESCE(SUM(b.duse_book_32_qr_code_rem), 0) as sum_32_qr_pages
                FROM {msbte_config.STATIONERY_DETAILS} a
                LEFT JOIN {msbte_config.W25_DAILY_STATIONERY_DETAILS} b ON a.ec_id = b.dec_id
                GROUP BY a.ec_id, a.book_32_qr_rem, a.conf
                ORDER BY a.ec_id ASC
            """
            df_result = pd.read_sql(query, conn)
        else:
            dist_regcode_param, err = _resolve_dist_regcode_stationery(
                request, auth, uid, conn,
                'stat_rbte/stationery_wise_32_qrcode.html',
                '32 Pages QR Code Answer Book Report',
                current_exam,
            )
            if err is not None:
                return err
            query = f"""
                SELECT a.ec_id, a.book_32_qr_rem, a.conf, SUM(b.duse_book_32_qr_code_rem) as sum_32_qr_pages
                FROM {msbte_config.STATIONERY_DETAILS} a
                INNER JOIN {msbte_config.W25_DAILY_STATIONERY_DETAILS} b ON a.ec_id = b.dec_id
                WHERE a.dist_regcode = %s
                GROUP BY b.dec_id
                ORDER BY a.ec_id ASC
            """
            df_result = pd.read_sql(query, conn, params=[dist_regcode_param])
        
        report_data = []
        i = 0
        for idx, row in df_result.iterrows():
            ec_id = row['ec_id']
            book_32_qr_rem = safe_int_stationery(row.get('book_32_qr_rem'))
            conf = row['conf'] if pd.notna(row['conf']) else 'N'
            sum_32_qr_pages = safe_int_stationery(row.get('sum_32_qr_pages'))
            if conf == 'Y':
                conf_y = 'Confirmed'
            else:
                conf_y = 'Not Confirmed'
            total_remaining = book_32_qr_rem - sum_32_qr_pages
            i += 1
            report_data.append({
                'sr_no': i,
                'ec_id': ec_id,
                'book_32_qr_rem': book_32_qr_rem,
                'sum_32_qr_pages': sum_32_qr_pages,
                'total_remaining': total_remaining,
                'conf_y': conf_y,
            })
        
        context = {
            'report_data': report_data,
            'current_exam': current_exam,
            'user_name': auth['user_name'],
            'user_role': auth.get('role', 'RBTE'),
            'print_date': datetime.now().strftime('%d/%m/%Y'),
            'report_title': '32 Pages QR Code Answer Book Report',
        }
        
        return render(request, 'stat_rbte/stationery_wise_32_qrcode.html', context)
        
    except Exception as e:
        logger.exception("Error in stationery_wise_32_qrcode")
        return handle_report_error(request, e, auth['is_jwt'])

@jwt_report_authorized(allowed_roles=['RBTE', 'ADMIN'])
def stationery_wise_32_qrcode_supliment(request):
    """
    32 Pages QR Code Supplement Answer Book Report - RBTE Level
    
    PHP Reference: report_32_qrcode_supli_stationery (RBTE version)
    - Shows report of 32 page QR code supplement answer books for all institutes under RBTE
    - Gets opening balance from STATIONERY_DETAILS (book_code_32_qr_supl_rem)
    - Gets used books (summed) from DAILY_STATIONERY_DETAILS (duse_book_32_qr_supl_rem)
    - Calculates remaining balance = opening - used
    - Shows confirmation status
    """
    auth, error = get_auth_context(request, require_institute=False)
    if error:
        return error
    
    try:
        conn = get_db_connection()
        
        # Get user ID (reg_code) from token/session
        uid = (
            auth.get('rbte_code')
            or request.session.get('USER_ID')
            or getattr(request, 'jwt_user_id', None)
        )
        
        # Get user role
        user_role = (
            auth.get('role')
            or (request.user.groups.first().name if request.user.is_authenticated and request.user.groups.exists() else None)
            or 'RBTE'
        )
        
        # Check if user is admin
        is_admin = (
            (not auth['is_jwt'] and request.user.is_authenticated and request.user.is_staff)
            or auth.get('role') == 'ADMIN'
        )
        
        logger.info(f"stationery_wise_32_qrcode_supliment - uid: {uid}, user_role: {user_role}, is_admin: {is_admin}")
        current_exam = getattr(msbte_config, 'ACA_NAME_EXAM_W', getattr(msbte_config, 'CURRENT_EXAM', msbte_config.EXAM_CODE))
        
        if is_admin:
            query = f"""
                SELECT 
                    a.ec_id,
                    a.book_code_32_qr_supl_rem,
                    a.conf,
                    COALESCE(SUM(b.duse_book_32_qr_supl_rem), 0) as sum_32_supl_pages
                FROM {msbte_config.STATIONERY_DETAILS} a
                LEFT JOIN {msbte_config.W25_DAILY_STATIONERY_DETAILS} b ON a.ec_id = b.dec_id
                GROUP BY a.ec_id, a.book_code_32_qr_supl_rem, a.conf
                ORDER BY a.ec_id ASC
            """
            df_result = pd.read_sql(query, conn)
        else:
            dist_regcode_param, err = _resolve_dist_regcode_stationery(
                request, auth, uid, conn,
                'stat_rbte/stationery_wise_32_qrcode_supliment.html',
                '32 Pages QR Code Supplement Answer Book Report',
                current_exam,
            )
            if err is not None:
                return err
            query = f"""
                SELECT a.ec_id, a.book_code_32_qr_supl_rem, a.conf, SUM(b.duse_book_32_qr_supl_rem) as sum_32_supl_pages
                FROM {msbte_config.STATIONERY_DETAILS} a
                INNER JOIN {msbte_config.W25_DAILY_STATIONERY_DETAILS} b ON a.ec_id = b.dec_id
                WHERE a.dist_regcode = %s
                GROUP BY b.dec_id
                ORDER BY a.ec_id ASC
            """
            df_result = pd.read_sql(query, conn, params=[dist_regcode_param])
        
        report_data = []
        i = 0
        for idx, row in df_result.iterrows():
            ec_id = row['ec_id']
            book_code_32_qr_supl_rem = safe_int_stationery(row.get('book_code_32_qr_supl_rem'))
            conf = row['conf'] if pd.notna(row['conf']) else 'N'
            sum_32_supl_pages = safe_int_stationery(row.get('sum_32_supl_pages'))
            if conf == 'Y':
                conf_y = 'Confirmed'
            else:
                conf_y = 'Not Confirmed'
            total_remaining_qr = book_code_32_qr_supl_rem - sum_32_supl_pages
            i += 1
            report_data.append({
                'sr_no': i,
                'ec_id': ec_id,
                'book_code_32_qr_supl_rem': book_code_32_qr_supl_rem,
                'sum_32_supl_pages': sum_32_supl_pages,
                'total_remaining_qr': total_remaining_qr,
                'conf_y': conf_y,
            })
        
        context = {
            'report_data': report_data,
            'current_exam': current_exam,
            'user_name': auth['user_name'],
            'user_role': auth.get('role', 'RBTE'),
            'print_date': datetime.now().strftime('%d/%m/%Y'),
            'report_title': '32 Pages QR Code Supplement Answer Book Report',
        }
        
        return render(request, 'stat_rbte/stationery_wise_32_qrcode_supliment.html', context)
        
    except Exception as e:
        logger.exception("Error in stationery_wise_32_qrcode_supliment")
        return handle_report_error(request, e, auth['is_jwt'])