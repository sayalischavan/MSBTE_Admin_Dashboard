"""
RBTE-specific scholarship views and reports
"""

