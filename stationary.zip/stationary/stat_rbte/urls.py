from django.urls import path
from . import views

app_name = 'stat_rbte'

urlpatterns = [
    path('rbte_stationery_report_institute_info/', views.rbte_stationery_report_institute_info, name='rbte_stationery_report_institute_info'),
    path('rbte_stationary_institute_info/', views.rbte_stationary_institute_info, name='rbte_stationary_institute_info'),
    path('rbte_cancel_stationery_report_institute_info/', views.rbte_cancel_stationery_report_institute_info, name='rbte_cancel_stationery_report_institute_info'),
    path('rbte_cancelation_stationery_report/', views.rbte_cancelation_stationery_report, name='rbte_cancelation_stationery_report'),
    path('stationery_wise_reports/', views.stationery_wise_reports, name='stationery_wise_reports'),
    path('stationery_wise_32/', views.stationery_wise_32, name='stationery_wise_32'),
    path('stationery_wise_32_supliment/', views.stationery_wise_32_supliment, name='stationery_wise_32_supliment'),
    path('stationery_wise_drawing/', views.stationery_wise_drawing, name='stationery_wise_drawing'),
    path('stationery_wise_drawing_supliment/', views.stationery_wise_drawing_supliment, name='stationery_wise_drawing_supliment'),
    path('stationery_wise_32_barcode/', views.stationery_wise_32_barcode, name='stationery_wise_32_barcode'),
    path('stationery_wise_32_barcode_supliment/', views.stationery_wise_32_barcode_supliment, name='stationery_wise_32_barcode_supliment'),
    path('stationery_wise_32_qrcode/', views.stationery_wise_32_qrcode, name='stationery_wise_32_qrcode'),
    path('stationery_wise_32_qrcode_supliment/', views.stationery_wise_32_qrcode_supliment, name='stationery_wise_32_qrcode_supliment'),
]
